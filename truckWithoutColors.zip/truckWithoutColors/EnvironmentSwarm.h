#import "AgentModelSwarm.h"
#import "Cell.h"
#import "Node.h"
#import "stdio.h"
#import "boolean.h"

@interface EnvironmentSwarm  : Swarm
{
	id inputString;
	id lastInputString;
	id problemFile;

	int epochCount;
	id positionArray;
	id gridPositionArray;
	id resetList;

        id agentModel;
        double reward;
	double bumpPenalty;
        int effectorAction;
        id <Grid2d> grid;			     // objects representing 
        int cellCount;
        id cellArray;
        int gridXSize, gridYSize;
        int correctCount, predictionCount, incorrectCount;

        FILE *problemfp, *outputfp;

	boolean write;
	boolean display;
        int agentXpos;
        int agentYpos;
	int lastRule;

        int rewardXpos;
        int rewardYpos;
	int relocatePosition;
	boolean enumerative;  
	int agentPosition;
	int on;

	id nydConstants, nydSm;
}

+createBegin: (id) aZone;
-setAgent: (id) anAgent;
-setString: (char *) aString;
-createEnd;
-buildActions;
-getNydConstants;
-setUpDisplay;
-activateIn: (id) swarmContext;
-getGrid;
-getCellArray;
-step;
-update;
-answer;
-executeRules;
-(void) convertFrom: (int) anInt to: (id) aString length: (int) length;
-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length;
-getString;
-(float) getPredictiveAccuracy;
-printOn;
-lookUpInputName: (int) nodeNumber;
-lookUpEffectorName: (int) number;
-resetAgentPosition;
-setProblem: (char *) fileName epochs: (int) epochCount;
-timeOut;
-(boolean)getDisplay;
-setDisplay: (boolean) aBool;
-(boolean) isOn: (int) position;
-setWrite: (boolean)  aBool;
-(boolean) getWrite;
-(int) getEpochCount;
@end






