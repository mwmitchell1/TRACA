// Agent application. Copyright (C) 1996 Matthew Mitchell.


// The agentModelSwarm is contained in the EnvironmentSwarm (among others).
// However, it has very little knowledge about its environment.  All this 
// is controlled by the EnvironmentSwarm.  All the agentModel knows about is
// the raster it displays itself on, its color (or later pixmap) and its x
// and y co-ordinates (Xpos, Ypos).

#include <stdio.h>
#import "AgentModelSwarm.h"
#import "Sorter.h"
#import "AgentObserverSwarm.h"
#import "AgentBatchSwarm.h"
#import "Trend.h"

@implementation AgentModelSwarm

// the nodeList contains all unary and nary nodes - not detector nodes

// The *move* step must be preceeded by a SetDetectorInput message sent to 
// the agentModelSwarm by the environment

-move
{
   int count=0, times=0, index=0;
   id tempList;

   //   printf("\n current time: %ld", getCurrentTime());

   // BE CAREFUL OF COUNTER BELOW
   
   if (learning) {
     if (getCurrentTime() == 2000)
       randomEffectorRate = 2;
     if (getCurrentTime() == 4000)
       randomEffectorRate = 3;
     if (getCurrentTime() == 6000)
       randomEffectorRate = 4;
     if (getCurrentTime() == 8000)
       randomEffectorRate = 5;
     if (getCurrentTime() == 9000) {
       //  randomEffectorRate = 6;
     //  if (getCurrentTime() == 15000) {
      randomEffectorRate = 0;   
    
       learning = False;
     }
   }
  

   [self detectorMatch];     // Match input to fired nodes

   // Jan 18 2001 - top temporal groups of final chains
   // need to tell their inputs to remove any unfinalised chains which
   // predict them.
   tempList = [groupList copy: [self getZone]];
   [tempList forEach: M(removeInputChains)];
   [tempList forEach: M(checkForMatchReset)];
   [tempList drop];

  // Temporal node groups need to update their activation counts.
   [groupList forEach: M(checkActivationCount)];
      
   if ([observer getMaze]
	&& (([self getReward] > 0)
	    || [[observer getEnvironment] getEndOfTrial])) {
	   // March 29 2001 added following line for monks 
     if (debug)
       printf("\n End of Trial");

     [self setEndOfTrial: 1];  
     counter = getCurrentTime() + 1000;
   }
 
   // BE CAREFUL OF THIS !!!!!!!!!!!!!!!!!!!!!!!!!!!!1
   // ||||||||||||||||||||||||||||||||||||||||||||||||
   /*  
   if (getCurrentTime() == counter) {
     [self setEndOfTrial: 1];  
     counter = getCurrentTime() + 1000;
   }
   */
   // Active supression prevents nodes sending support
   // and updating values.  Does not affect creating new connections etc.

   [terminalGroupList forEach: M(checkActiveTemporalSupress)];

   // July 16 2002 - don't supress under temporal nodes
   //   [groupList forEach: M(checkActiveTemporalSupress)];

   [groupList forEach: M(checkActiveSupress)];

   // May 7 2002 - to prevent subordinates sending support for actions
   // supported by terminal groups when temporal chains are matched

   // Nov 23 2000 - added following
   [groupList forEach: M(checkCreateTemporalOk)];

 // Nov 17 2000 - added following line, need to copy list
   // as groups are removed from it while it is traversed. 		 
   // Nov 20 - moved the following code here from just after deactivate.
   //          needs to be before temporalExtend
   tempList = [groupList copy: [self getZone]];
   [tempList forEach: M(checkTemporalRemove)];
   [tempList drop];
   // Nov 28 2000 - added following
   // May 30 2001 - removed following - doesn't seem to do anything
   tempList = [terminalGroupList copy: [self getZone]];
   [tempList forEach: M(checkTemporalRemove)];
   [tempList drop];

   // initalise nodes and groups for lookahead

   // Copy temporal nodes for alternative actions
   // This was removed Feb 10 2000. Trying to eliminate unneccesary nodes
   // May 30 2001 - I am not sure if this should still be here???
   // [groupList forEach:M(copyNode)];

   [groupList forEach:M(addToConnectList)];
   // For copying nodes for other predictions
   //   [terminalGroupList forEach:M(addToTemporalConnectList)];

   if (debug) {
       printf("\n =========== predictorList size: %d", 
                     [predictorList getCount]);
   }
   [self connectPredictorList];    

   // reset effectors
   // May 20 2002 - moved from setDetector
   [effectorArray forEach: M(reset)];

  // Extend code:
   [extendList removeAll];

   // Note that only groups which fired last cycle will be in the 
   // predictor lists
   [predictorList forEach: M(constructExtendList:) : (id) extendList];
   
   // June 11 2002 - use normal list above
  //[temporalPredictorList forEach: M(constructExtendList:) :(id) extendList];

   if (useTemporal)
     [groupList forEach: M(temporalExtend)];

   [self clearPredictorList];  // clear the list of predictor nodes
   //  CAREFUL, connections are made before payments in matchC and as
   //  it stands, these make a difference

   if (debug)
     fprintf(stdout,"\n AgentModel reward: %f", reward);

   // We should always call payPredictors, so rewardStrength averages 
   // are calculated correctly.  Only nodes which actually sent support
   // will use the sent values. Matched nodes send reward, unmatched send 0.


   // July 2 2002 - changed following to get reward 
   // based on matched rather than fired.  See also change below.
   [groupList forEach: M(setReward)];
   [terminalGroupList forEach: M(setReward)];

   // Commented for now and replaced by direct get in PredictorNode
   // need to redo it this way for lookahead though.

   // July 2 - removed following - reward is obtained directly 
   // in updateValueEstimate
   //   [groupList forEach: M(payPredictors)];

   // This could be eliminated for nodes, the group could just call its
   // own getDependentReturn method. Nodes send values to group

   Qreturn = 0;
   [nodeList forEach: M(sendPredictorsReturn)];
   [temporalNodeList forEach: M(sendPredictorsReturn)];

  // Nov 17 2000 - now calculate your average return over time
   // Dec 12 2000 - only do this when matched or FIMN
   [groupList forEach: M(updateAverageReturn)];

   // Now send the max you received from your nodes to your predictors 
   [groupList forEach: M(sendPredictorsReturn)];

   // July 16 2002 - allow terminal groups to be predicted:
   // [terminalGroupList forEach: M(sendPredictorsReturn)];

   // Send nodes prior to you in the chain a return
   [temporalNodeList forEach: M(sendPreviousReturn)];
   [terminalNodeList forEach: M(sendPreviousReturn)];

   [terminalGroupList forEach: M(sendPreviousReturn)];
   [groupList forEach: M(sendPreviousReturn)]; // This only applies to 
                                               // temporal groups

   // Terminal nodes and temporal nodes have a separate channel
   // for passing back returns from terminal group.
   // Need to do this again. 

   [temporalNodeList forEach: M(sendTemporalReturn)];
   // For terminal nodes this is as above
   [terminalNodeList forEach: M(sendTemporalReturn)];
   //[terminalGroupList forEach: M(sendTemporalReturn)]; // for terminal groups

   [groupList forEach: M(sendTemporalReturn)]; //for temporal groups

   // For temporal nodes, this needs to be called
   // after fired and again when matched.
   [nodeList forEach: M(updateValueEstimate)];
   // temporal nodes have their own updateValueEstimate 
   // for discountedTerminalValues
   [temporalNodeList forEach: M(updateValueEstimate)]; 
   [terminalNodeList forEach: M(updateValueEstimate)];

   // Oct 12 2000 - prevent groups creating multiple chains 
   [terminalGroupList forEach: M(preventTemporalConnect)];

   // copy predictors and create new temporal chains

   [self connect];           // match string to detectors who then notify
			     // correct and incorrect nodes of predictions

  if (useTemporal) {
    [lastExtendList drop];
    // May 15 2000 - remove nodes which were supressed in connect but already
    // added to extendList. Need to do this as these nodes are 2 time steps
    // removed from connect where they are used so cannot just check
    // lastSupressed as for Nary nodes
    lastExtendList = [List create: [self getZone]];
    count = [extendList getCount];
    for (index = 0; index < count; index++) {
      if (debug)
	printf("\n adding node to extend list: %ld, supressed: %d",
	       [[extendList atOffset: index] getNodeNumber],
	       [[extendList atOffset: index] getSupressed]);
      //  if (![[extendList atOffset: index] getSupressed])
	// April 22 2002 - removed following line,
	// changing it so that nodes are activeTS, only whne first
	// groups action is selected.
	// This is now checked when doing selecting nodes for extending 
	// if (![[extendList atOffset: index] getActiveTemporallySupressed])
	[lastExtendList addLast: [extendList atOffset: index]];
    }
  }

   while (times < lookaheadTimes)
   {
      times++; 
      if (lookaheadDistance > 0)
      {
         [temporalNodeList forEach: M(hypReset)];    
         [terminalNodeList forEach: M(hypReset)];    
         [nodeList forEach: M(hypReset)];    
         [groupList forEach: M(hypReset)];    
         [nodeList forEach: M(lookahead)];
      }
   // perform lookahead steps
      count = 0;
      while (count < lookaheadDistance) 
      {
        count++;
        [self lookahead];
      }
   }

   [self deActivate];
   createTemporalOk = True;	

   [groupList forEach: M(incrementLifetimeCount)];
 
// While the matched flag is used to determine which inputs were activated
// they are reset by deactivate, the realactive flag of nodes is then
// set by a similar process to match:.  The purpose of this is that the
// matched flag is now available to be used with the next set of inputs.
// Alternatively, it would have to be reset after fire. (which may be ok)
// i.e it may be possibleto replace the reactivate flagand step and
// use the matched flag instead, reseting it after fire. 

   if (endOfTrial)
   {
       [self reset];
       createTemporalOk = True;	
       endOfTrial = 0;
       return self;       
    }       

   [self preFire];   

   // June 18 2002 - This used to prevent duplicate joins now
   // use narySupress instead of supress:
   // [groupList forEach: M(checkSupress)];

   // Nodes which are supressed cannot be used to create new temporal nodes
   // this prevents identical duplicates:- 

   // June 14 2002 - removed following line:
   //   [terminalGroupList forEach: M(checkSupress)];

   // July 13 added following line (needs to be after activeSupress)

   [groupList forEach: M(checkNarySupress)];
   [terminalGroupList forEach: M(checkNarySupress)];

   // June 18 2002 - terminal groups do not prevent joins until final
   // which they do by using activeTemporalSupress 
   // [terminalGroupList forEach: M(checkNarySupress)];

   // April 11 2001
   [groupList forEach: M(checkExclude)];
  
   [self selectEffector];    // Support is collected and an effector selected
   [self resetActiveSupress];

   // If a temporal chain is complete, it must updateSupress
   // its input so that the independent value is correct, however,
   // for temporal nodes, this can be done only once the action is deteremined
   // if a temporal chain's action is not followed, it cannot updateSupress
   // otherwise, it must directly set the updateTemporalSupressed flag since
   // this is being done after deactivate. updateTemporalSupress is similar
   // to activeSupress and only affects updateValueEstimate 
   // and correct/incorrect.

   // June 14 2002 - removed following line:
   // [groupList forEach: M(checkUpdateTemporalSupress)];

   [self fire];              // Nodes notify detectors of their predictions

   return self;
}

-reset
{

   [detectorArray forEach:M(reset)];
   [groupList forEach:M(reset)];
   [nodeList forEach:M(reset)];
   [temporalNodeList forEach:M(reset)];
   [terminalNodeList forEach:M(reset)];
   [observer resetAgentPosition];
   [extendList removeAll];
   [lastExtendList removeAll];

   return self;       
} 


-lookahead
{
   // the True means nothing.  Also this is not sent to detector nodes
   [nodeList forEach: M(hypMatch:) : (void *) True];
   [groupList forEach: M(checkHypMatchSupress)];
   [groupList forEach: M(checkHypActiveSupress)];
   // removethese functions later if there are no problems
   //   [groupList forEach: M(hypPayPredictors)];
   // [nodeList forEach: M(hypPayPredictors)];
   [nodeList forEach: M(hypSendPredictorsReturn)];
   [groupList forEach: M(hypSendPredictorsReturn)];
   [nodeList forEach: M(hypUpdateValueEstimate)];

   [self hypDeActivate];        
   [self hypPreFire];   
   [self hypResetActiveSupress];
   [self hypFire];              // Nodes notify detectors of their predictions
   return self;
}


-setDetectorInput: (id) aString Reward: (double) aReward
{

  // Before replacing the detector input, backup the previous detector input
  // into the oldInputList
 
   inputString = aString;
   if ([aString getCount] < detectorCount)
      printf("\n Error: Detector String too short. length is: %d", 
                                                              detectorCount);
   reward = aReward;  
   if (debug)
      printf("\n ***** Agent model reward: %f", reward);
   [oldInputList drop];
   oldInputList = [newInputList copy: [self getZone]];
  // reset the effectors 
   // May 20 2002 - moved to move();
   // [effectorArray forEach: M(reset)];

   return self;
}

-detectorMatch
{

   id testList;

   // detectorMatch: match string to detectors.  This is done by passing 
   // the *match* Message to ALL detectors.  Detectors that receive
   // this message with the argument True, will increase the strength 
   // of nodes in the predictorList, while those with False will decrease
   // the strength of predicting nodes.
   // The connect method is also called to identify where new Nary nodes and 
   // connections are neccessary.  
   // Nodes will reset their realActive atribute depending on this 
   // message being True or False. 

   if (removeSuspended)
   {
      testList = [nodeList copy: [self getZone]]; 
      [testList forEach: M(removeSuspended)];
      [testList drop];
     testList = [temporalNodeList copy: [self getZone]]; 
      [testList forEach: M(removeSuspended)];
      [testList drop];
   }

// Note: that during match, rewards are collected from the system by 
// detectors and passed up the hierarchy.

   [self match];

   // After matching, nodes have been updated with the new reward strength
   // Therefore they can pay the nodes which predicted them and contributed
   // to their activation.

   return self;
}

-connectPredictorList
{


// Instead of passing up predictors, maintain a list of nodes which just
// fired (active and suspended predictors only) .  For each of these nodes,
// pass the list of nodes which are now matched and not matchSupressed.  
// If a node in the original list does not predict a node in the matched list
// then copy it so it does. (Note: similar to unaryCreate).

   id workList = [groupList copy: [self getZone]];
   [workList forEach: M(connectPredictorList:) : (id) predictorList];
   // This flag is set once a temporal chain is created to restrict 
   // creations to only one per timestep

   // June 11 2002 - use normal list above
//   [workList forEach: M(connectPredictorList:) : (id) temporalPredictorList];
   [workList drop];

   return self;
}

-connect
{

   id workList;
   int index;
   id tempGroup;
  
   // Once matching is complete nodes can create new nodes to predict them
   // based on their current state and the nodes which predicted them. 
   // The new nodes will be nary nodes made from combinations of the previous
   // predicting nodes

// For each Unary and Nary node if it has fired and has fired owners, pass up
// the nodes which predict it and have reached steadystate.  These nodes are 
// then copied and allow nodes to make predictions further up the hierarchy. 

// Note; this must come before connect, as it grabs nodes that are active only
// which may have owners added after connect.

   // Oct 5 2000 - prevent new temporal chains being created
   // when an unfinished existing one has just fired and was correct
   // Oct 12 - removed following
   //   [terminalGroupList forEach:M(setTerminalFired)]; 
   
   workList = [groupList copy: [self getZone]];   

   while ([workList getCount] > 0) 
   {
      index  = [uniformIntRand getIntegerWithMin: 0 
				   withMax: ([workList getCount] - 1)];

      tempGroup = [workList atOffset: index]; 
      if (useNary)
	[tempGroup connect];
      if (useTemporal)
	[tempGroup temporalConnect];
      [workList remove: tempGroup];
   }

   [workList drop]; 

   [activeList removeAll];   
   [passivePredictorList removeAll];

   if (debug)
      printf("\n Connect %ld", getCurrentTime());

   return self;
}


-deActivate
{
   id tempList, index, dropNode;
    
   // Once detector matching and subsequent connecting has been completed
   // all detector nodes are sent the message realDeactivate.  
   // This is passed up to owner nodes and will reset their activation 
   // levels to zero.  Note: an alternative approach would be send a message
   // to all non-detector nodes reseting the activation level, but this 
   // approach is consistent with both setting and resetting. 
   // For detector nodes the method will reset the predictors lists   
   // Reset Active Nodes and Selected Effector 

   [detectorArray forEach:M(realDeactivate)];

   [nodeList forEach: M(setLastCorrect)];
   [temporalNodeList forEach: M(setLastCorrect)];
   [terminalNodeList forEach: M(setLastCorrect)];

   // Oct 16 2000 - could make following more efficient (not copying lists)
   // if nodes remove themselve from list just before drop rather
   // then when setting removed flag.

   if (debug)
     fprintf(stdout,"\n Sending nodes groups deactivate");

   tempList = [groupList copy: [self getZone]];   
   [tempList forEach: M(realDeactivate)];
   [tempList drop];

   // Nodes can rewmove themselves if PS < 1 - threshold ,so we need
   // a templist as they are removed from the nodeList while traversing it.

  if (debug)
     fprintf(stdout,"\n Sending nodes deactivate count: %d",
	     [nodeList getCount]);

   tempList = [nodeList copy: [self getZone]];   
   [tempList forEach: M(realDeactivate)];
   [tempList drop];

   tempList = [temporalNodeList copy: [self getZone]];   
   [tempList forEach: M(realDeactivate)];
   [tempList drop];

   // Terminal nodes need to be deactivated after groups, as they
   // receive their matched message from TemporalGroups when they
   // are deactivated.

   tempList = [terminalNodeList copy: [self getZone]];   
   [tempList forEach: M(realDeactivate)];
   [tempList drop];

   // Now check if any nodes need to be removed

   tempList = [nodeList copy: [self getZone]];
   [tempList forEach: M(checkInputs)];
   [tempList drop];

   tempList = [nodeList copy: [self getZone]];
   [tempList forEach: M(checkRemove)];
   [tempList drop];

   tempList = [temporalNodeList copy: [self getZone]];
   [tempList forEach: M(checkInputs)];
   [tempList drop];

   tempList = [terminalNodeList copy: [self getZone]];
   [tempList forEach: M(checkInputs)];
   [tempList drop];

   tempList = [terminalNodeList copy: [self getZone]];
   [tempList forEach: M(checkRemove)];
   [tempList drop];

// Note: the dropList will contain nodes and any nodeGroups which have been
// removed. 

   index = [dropList begin: [self getZone]] ;
   while ((dropNode = [index next])) 
   {
     [dropNode die];
     [index remove]; 
     [dropNode drop];
   }

   [index drop];

   [nodeList forEach: M(setFired:) :(void *) False];
   [temporalNodeList forEach: M(setFired:) :(void *) False];
   [terminalNodeList forEach: M(setFired:) :(void *) False];
   [effectorArray forEach: M(setSelected:) :(void *) False]; 
 
   [temporalNodeList forEach: M(resetTemporallyFired)];

   if (debug)
     printf("\n Deactivate %ld", getCurrentTime());

   return self;
}

-hypDeActivate
{
   [detectorArray forEach:M(hypDeactivate)];
   [groupList forEach: M(hypDeactivate)];
   [nodeList forEach: M(setHypFired:) :(void *) False];
   if (debug)
      printf("\n HypDeactivate %ld", getCurrentTime());

   return self;
}

-resetActiveSupress
{
  // Nov 15 2000 - setActiveTemporallySupressed is called twice to reset
  // last activeTemporallySupressed to False.

   [detectorArray forEach:M(resetActiveSupressed:) : (void *) False];
   [detectorArray forEach:M(resetActiveTemporallySupressed:) : (void *) False];
   [groupList forEach:M(resetActiveSupressed:) : (void *) False];
   [groupList forEach:M(resetActiveTemporallySupressed:) : (void *) False];
   [nodeList forEach:M(resetActiveSupressed:) : (void *) False];
   [nodeList forEach:M(resetActiveTemporallySupressed:) : (void *) False];
   [temporalNodeList forEach:M(resetActiveSupressed:) : (void *) False];
   [temporalNodeList forEach:M(resetActiveTemporallySupressed:) : (void *) False];
   [terminalNodeList forEach:M(resetActiveSupressed:) : (void *) False];
   [terminalNodeList forEach:M(resetActiveTemporallySupressed:) : (void *) False];

   return self;
}


-hypResetActiveSupress
{
   [detectorArray forEach:M(setHypActiveSupressed:) : (void *) False];
   [groupList forEach:M(setHypActiveSupressed:) : (void *) False];
   [nodeList forEach:M(setHypActiveSupressed:) : (void *) False];
   return self;
}


-clearPredictorList
{
     [predictorList removeAll];
     [temporalPredictorList removeAll];
     return self;
}


-selectEffector
{
   unsigned int index;
   double max = -10000;
   id sorter;
   id effectorList;   

   someEffectorSupported=False; 
   index = 0;  

   random = 0;  // (1 if not support, 2 if due to rate)  

   if (debug) {
     printf("\nselecting effector: ");
     fflush(stdout);
   }

   if (selectedEffector != nil)
     previousAction = [((Effector *) selectedEffector) getPosition];

   // ask all active (level 1) nodes to send their support to their 
   // associated effector

   [effectorArray forEach: M(reset)];

   // April 11 2002 - when not doing hyp lookahead - select
   // node with most experience to send support

   [nodeList forEach: M(sendFrequency)];
   [temporalNodeList forEach: M(sendFrequency)];
   [terminalNodeList forEach: M(sendFrequency)];

   [nodeList forEach: M(sendActivePredictiveSupport)];
   [temporalNodeList forEach: M(sendActivePredictiveSupport)];
   [terminalNodeList forEach: M(sendActivePredictiveSupport)];

// If we want to stop exploring and just use the effector with the highest
// support. do the following: (otherwise use a probability)

   if (follow) {
     [[observer getEnvironment] executeRules];
   } else {
 // not following handwritten policy
     if (!useStrength)
       {
         index  = [uniformIntRand getIntegerWithMin: 0 
				  withMax: ([effectorArray getCount] - 1)];

         if (debug)
	   printf("\n * Effector selected = %d", index); 
	 
	 selectedEffector = [effectorArray atOffset: index];
	 [self setEffector: selectedEffector];
       }
     else
       if (deterministicSelect) {
	 if (someEffectorSupported)
	   {
	     index = 0;
	     if (randomEffectorRate > 0) {
	       
	       index  = [uniformIntRand getIntegerWithMin: 1 
					withMax: randomEffectorRate];
	     }
	     if (index == 1) {
	       index  = [uniformIntRand getIntegerWithMin: 0 
					withMax: ([effectorArray getCount] - 1)];

	       if (debug)
		 printf("\n * Explore: random effector selected = %d", index); 
	       
	       random = 1;
	       selectedEffector = [effectorArray atOffset: index];
	       [self setEffector: selectedEffector];
	     }
	     else {
	       [effectorArray forEach: M(calculateEffectiveSupport)];

	       [effectorArray forEach: M(selectBestPredictiveEffector:max:)
			      :(id) selectedEffector :(void *) &max];  
	       //  [self setEffector: selectedEffector];
	     }
	   }
	 else
	   // if no effector has support, select randomly from the effectors
	   {
	     index  = [uniformIntRand getIntegerWithMin: 0 
				      withMax: ([effectorArray getCount] - 1)];

	     if (debug)
	       printf("\n * No effector supported random effector selected = %d", index); 
	     random = 2;
	     
	     selectedEffector = [effectorArray atOffset: index];
	     [self setEffector: selectedEffector];
	   }
       }
       else
	 {
	   if (someEffectorSupported) 
	     {
	       // non deterministic select - here the randomEffectorRate
	       // acts like a temperature - a lower rate reduces exploration
	       // (100 for close to deterministic selection 
	       // or zero to always select probabilistically)
	       //  NOTE: that this is the reverse of the above.
	       // otherwise acts as roulette wheel among supported actions. 
	   
	       index = 1;
	       if (randomEffectorRate > 0) {	   
		 index  = [uniformIntRand getIntegerWithMin: 1 
					  withMax: randomEffectorRate];
	       }
	       // July 3 2002 - changed this for ring mazes:

	       if (index != randomEffectorRate) {
		 if (debug) {
		   printf("\nselectBest");
		   fflush(stdout);
		 }
		 [effectorArray forEach: M(calculateEffectiveSupport)];
		 
		 [effectorArray forEach: M(selectBestPredictiveEffector:max:)
				:(id) selectedEffector :(void *) &max];
	       } else {
		 supportSum = 0;
		 selectionNumber = [randomGenerator getDoubleSample];
		 
		 if (debug) {   
		   printf("\n Selecting effector random number: %f, totalSupport %f", 
			  selectionNumber, supportSum);
		   fflush(stdout);
		 }
		 
		 // Get the effector whose cumulative support corresponds to the 
		 // the number selected. Note that each effector asks the model
		 // for the supportSum to convert its cumulativeSupport to between
		 // 0-1.  
		 
		 selectedEffector = nil;
		 [self setPositiveSupport: False];
		 [effectorArray forEach: M(calculateEffectiveSupport)];
		 
		 // May 6 2002 - moved following
		 effectorList = [effectorArray copy: [self getZone]];

		 sorter = [Sorter createBegin: [self getZone]];
		 sorter = [sorter createEnd];
		 [sorter sort: effectorList]; 
		 [sorter drop];

		 if (!positiveSupport) {
		   // This is more complex - we want to calculate the inverse
		   // of the strengths. So we add them up to get a total
		   // (stored for now in supportSum) then divide each by the 
		   // total to give a proportion. Then divide the proportion
		   // by 1 to give an inverse strength. 
		   [effectorList forEach: M(calculateSum:)
				 : (void *) &supportSum];
		   [effectorList forEach: M(calculateProportion:)
				 : (void *) &supportSum];
		   supportSum = 0;
		 }

		 [effectorList forEach: M(setCumulativeSupport:)
			       : (void *) &supportSum];
		 
		 if (positiveSupport)
		   random = 3;
		 else
		   random = 4;
		 
		 [self setEffector: nil];
		 [effectorList forEach: M(checkCumulativeSupport)];

		 // SOMETHING FUNNY IS HAPPENING HERE - PERHAPS
		 // DUE TO VERY LOW VALUES?
		 if (selectedEffector == nil) {
		   printf("WARNING - SELECTED EFFECTOR NIL");
		   printf("WARNING - SELECTING AT RANDOM: TIME: %ld", 
			  getCurrentTime());
		   index  = [uniformIntRand getIntegerWithMin: 0 
			       withMax: ([effectorArray getCount] - 1)];
		   random = 2;
		   
		   selectedEffector = [effectorArray atOffset: index];
		   [self setEffector: selectedEffector];
		 }

		 [effectorList drop]; 
	       }
	     } else {
      // if no effector has support, select randomly from the effectors
	       index  = [uniformIntRand getIntegerWithMin: 0 
			       withMax: ([effectorArray getCount] - 1)];

	       if (debug)
	         printf("\n * No effector supported random selection: %d",
			index); 
	       random = 2;
	       selectedEffector = [effectorArray atOffset: index];
	       [self setEffector: selectedEffector];
	     }
	 }
   }
     //  total that support and select a winning effector
 
   if (trackActions)
   {
      printf("\n TRACKING EFFECTOR SELECTION:");
      [effectorArray forEach: M(printTrack)];
      printf("\n");
      fflush(stdout);
   }
  
   [selectedEffector setSelected: True];

   if (debug)
   {
      printf("\n  EFFECTORS +++++++++++++++++++++++++++++++++++++++++++");
      [effectorArray forEach: M(printOn)];
      printf("\n select Effector %ld", getCurrentTime());
   }

 if (debug) {
     printf("\nfinished selecting effector: ");
     fflush(stdout);
   }

   return self;
}


-(int) getRandom 
{
  return random;
}


-(int) getEffectorCount {

  return [effectorArray getCount];
}

-(id) getEffectorArray {
  return effectorArray;
}

-getEffector 
{
  return selectedEffector;
}

-setEffector: (id) anEffector
{
  
// used by checkCumulativeSupport, passing it as a parameter in the 
// forEach didn't seem to work

    selectedEffector = anEffector;    
    return self;
}

-preFire
{
  [nodeList forEach: M(preFire)];
  [temporalNodeList forEach: M(preFire)];
  [terminalNodeList forEach: M(preFire)];

  return self;
}

-hypPreFire
{
  [nodeList forEach: M(hypPreFire)];
  [groupList forEach: M(checkHypSupress)];

  return self;
}

-fire
{
   //  Nodes that nominated the winning effector can fire (activation level 2)
   //  that is they notify their prediction that they expect them to fire and
   //  make payments accordingly.  

   [nodeList forEach: M(fire)];
   [temporalNodeList forEach: M(fire)];
   [terminalNodeList forEach: M(fire)];

   // During fire, nodes pay the nodes which predicted them. 
   // detector nodes make no payment, as their predictors will recieve
   // payment directly if rewards are received, otherwise they receive no 
   // payment 
   if (debug)
       printf("\n Fire %ld", getCurrentTime());
   return self;
}

-hypFire
{

   [nodeList forEach: M(hypFire)];

   if (debug)
       printf("\n Hyp Fire %ld", getCurrentTime());
   return self;
}

-(double) getSupportSum
{  
  return supportSum;
}

-(double) getSelectionNumber
{
   return selectionNumber;
}

-getNodeList
{
  return nodeList;
}

-getTemporalNodeList
{
  return temporalNodeList;
}

-getTerminalNodeList
{
  return terminalNodeList;
}

-(int) getUnsuspendedGroups {

  int unsuspended = 0;
  int count = 0;

  while (count < [groupList getCount]) {
    if (([(NodeGroup *) [groupList atOffset: count] getNodeCount] > 0)
        && ([[groupList atOffset: count] getSuspended] == False)
	&& ([[groupList atOffset: count] getRemoved] == False))
      unsuspended++;
    count++;
  }
  return unsuspended;

}

-(int) getGroupCount {

  int groups = 0;
  int count = 0;

  while (count < [groupList getCount]) {
    if ([(NodeGroup *) [groupList atOffset: count] getNodeCount] > 0)
      groups++;
    count++;
  }
  return groups;

}

-getGroupList
{
   return groupList;
}

-setEffectorCount: (int) aCount
{
   effectorCount = aCount;
   return self;
}

-setDetectorCount: (int) aCount
{
  detectorCount = aCount;
  return self;
}

-getDetectorArray
{
	return detectorArray;
}

-match
{
   // detectors are matched here.  Each detector passes the message matched
   // up to its owner's higher in the hierarchy who will also record that they
   // are matched.  In the case of Nary Nodes, both inputs must be checked to 
   // determine a match.  

   // Nodes that are matched will notify nodes which predicted them 
   // (who fired - that is the effector they sugggested was 
   // selected) who will then get the reward from the agentModel to update
   // their reward strength.


   int index, count;
   id member;

   [newInputList removeAll];
   count = [detectorArray getCount];

   // the number of active detectors is used to calculate how many 
   // detector nodes to share the reward between
 
   numberDetectorsActive = 0;
   for(index= 0; index < count; index++)
        if (([inputString getC][index]) == '1')
            numberDetectorsActive++; 

   if (debug)
   {
       printf("\n Detector Array count: %d number active %d", count,
             numberDetectorsActive );
        printf("\n inputstring into agentmodel: %s",[inputString getC]);
   }

   for(index = 0; index < count;index++)
   {
      member = [detectorArray atOffset: index];
      if (member == nil)  
      {
         printf("\nWarning: AgentModelSwarm: activateDetector: detector nil");
         return self;
      }
      if ([inputString getC][index] == '1')
      {
         [member match: True];
         [newInputList addLast: member];
      }
      else     
         [member match: False]; 
   }

   // This is a dodgy way of making up for the fact that nary nodes 
   // require two messages each timestep, but may only receive one if
   // terminal nodes are not matched.
   [groupList forEach: M(checkMatched)];

   if (debug)
   {
      printf("\n Detector Match %ld", getCurrentTime());
   }
   return self;
}


-(double) getReward
{
     return reward;
}


-calculateRewardShare
{
   int count;
   id tempGroup;
   int shareNumber=0;

   count = [groupList getCount];
   while (count > 0)
   {
        count--;
        tempGroup = [groupList atOffset: count];
        if ([tempGroup getMatched] && ![tempGroup getActiveSupressed])
            shareNumber++;
   }

   if (shareNumber > 0)
       reward = reward / shareNumber;
   else
      printf("\n Warning: AgentModel: no groups active");

  return self;
}

-getSelectedEffector
{
  return selectedEffector;
}

// Mar 20 2002 - added following

-(int) getPreviousAction 
{
  return previousAction;
}

-(int) getLastAction
{
  return [((Effector *) selectedEffector) getPosition];
}

-getGrid {
  return grid;
}

-addNode: (id) node {

  if ([node respondsTo: M(isGroup)])
  {
     [groupList addLast: node]; 
  }
  else
     if ([node respondsTo: M(isTerminal)]) 
         [terminalNodeList addLast: node];
     else
         if ([node respondsTo: M(isTemporal)]) 
            [temporalNodeList addLast: node];
         else
            [nodeList addLast: node];

  return self;
}

// createBegin: here we set up the default simulation parameters.nd
+createBegin: (id) aZone {
  AgentModelSwarm * obj;
  id <ProbeMap> probeMap;

  // First, call our superclass createBegin - the return value is the
  // allocated AgentModelSwarm object.
  obj = [super createBegin: aZone];

  // Now fill in various simulation parameters with default values.
  obj->gridXSize = 50;
  obj->gridYSize = 50;
  obj->counter=1000;
  
  obj->interest=0;
  obj->positiveSupport=False;
  // initialize number of nodes 
  
  obj->tempCount=0;

  obj->debug=0;
  obj->follow=0;

  obj->removalFactor=3.5;  // 1.5 changed from 2 for MMaze 
                        // This indicates number of temporal activations 
                        // required before a temporal node is removed
                        // if not extended in this time 
  obj->temporalActive=0;
  obj->terminalActive=0;
  obj->naryActive=0;
  obj->activeGroupCount=0;
  obj->removedGroups=0;

  obj->narySupressionRate=20; // changed from 20 for MMaze
  obj->maxPredictorCount=1000; // Determines the number of suspended predictors
  obj->performanceFactor=0.05; // changed from 20 for MMaze
  // Added this Apr 04 2001 - if zero works as always did
  obj->initialQvalue=0.0; // changed from 20 for MMaze
  obj->createTemporalOk=True;

  obj->noiseTolerance=0.0000;
  obj->coxStuartSignificance=0.05;

  // Must be >= activationThreshold  
  obj->coxStuartCaseCount=20; // normally 20
  obj->temporalCoxStuartCaseCount=20; // normally 20

  obj->test=0;
  obj->learning=1; // turn off for random results
  obj->nodeCount = 0;
  obj->randomEffectorRate=1;
  obj->storedRate=0; // Nov 16 2000 - random rate will be reset
                     // to stored rate if this changes
                     // (this should be used in place of randomEffector
                     //  rate which effectively just becomes a display
                     // of the stored rate.      
  obj->activationThreshold=20; // NOTE: should always be >= coxStuartCaseCount
                               // normally 40
  obj->temporalActivationThreshold=20; // This is used also to remove
                                       // groups which have not been extended. 


  obj->finiteProblem=False;

  obj->extendThreshold = 0.05; //0.02; // restricts the length of chains
  obj->negativeExtendThreshold = -3.0;
  obj->discountRate=0.9;
  obj->temporalExtendAccuracy=0.05;
  obj->threshold=1.0;

  obj->useAverageForReward = 0;
  obj->useAverageForAccuracy = 0;
  obj->temporalCreated=0;
  obj->temporalNodeCount=0;
  obj->terminalCreated=0;
  obj->terminalNodeCount=0;
  obj->unaryCreated=0;
  obj->groupsCreated=0;
  obj->naryCreated=0;
  obj->suspendLastCorrect=True;  // leave this as true unless 
   //  NodeGroup:inhibitInputNodes does not have matched in condition
  obj->copyValues = 0; // if using average turn off
 
  obj->improvementFactor= 0.01; // This may be reduced by independentAccuracy.
  obj->temporalImprovementFactor= 0.01; // for corridor chains 

  obj->variance=0.0001;
  obj->unaryNodeCount=0;
  obj->naryNodeCount=0;
  
  obj->useNegative=1;
  obj->stableNaryNodeCount=0;
  obj->nodeGroupCount=0;
  obj->nextNodeNumber=0;
  obj->useStrength=1;
  obj->useTemporal=0; // 2022 - turned off for now.
  obj->unusedChainRemoval=999;
  obj->useNary=1; // 2022 - use just temporal nodes
  obj->endOfTrial=0;
  obj->activeCount=0;
  obj->explore=False;
  obj->subordinatedCount=0;
  obj->someEffectorSupported=False;
  obj->removeSuspended=0;
  obj->selectBest=0; // Changed Feb 9 2022
  obj->trackActions = 0;
  obj->trackRules = 0;

  // Set to 0 to use probabilistic select from positive actions.
  // if only negative selects probabilistically from -ve. 
  // ONLY USE ONCE exploreNegativeValue is set

  obj->deterministicSelect=1; // if zero randomEffectorRate should be 0.
  obj->exploreNegativeValue = 0.5; // don't make this high!!

  obj->passPredictors = 0;
  obj->lookaheadDistance = 0;
  obj->lookaheadTimes = 0;
  obj->learningRate=0.1; // Changed from 0.2 for MMaze

  // And build a customized probe map. Without a probe map, the default
  // is to show all variables and messages. Here we choose to
  // customize the appearance of the probe, give a nicer interface.
 
  probeMap = [EmptyProbeMap createBegin: aZone];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameter


  [probeMap addProbe: [probeLibrary getProbeForVariable: "useStrength"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "test"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "learning"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "debug"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "follow"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "trackActions"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "trackRules"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "deterministicSelect"
				    inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: "activationThreshold"
				    inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: "temporalActivationThreshold"
				    inClass: [self class]]]; 
  //[probeMap addProbe: [probeLibrary getProbeForVariable: "lookaheadDistance"
  //			    inClass: [self class]]]; 
  //[probeMap addProbe: [probeLibrary getProbeForVariable: "lookaheadTimes"
  //			    inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: "learningRate"
				    inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: "useTemporal"
				    inClass: [self class]]];
 [probeMap addProbe: [probeLibrary getProbeForVariable: "useNary"
				    inClass: [self class]]]; 
 // [probeMap addProbe: [probeLibrary getProbeForVariable: 
 // "useAverageForAccuracy"
 //			    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "randomEffectorRate"
				    inClass: [self class]]]; 
 // [probeMap addProbe: [probeLibrary getProbeForVariable: "storedRate"
 //			    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "extendThreshold"
				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "negativeExtendThreshold"
 			    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "temporalExtendAccuracy"
				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "threshold"
				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "discountRate"
				    inClass: [self class]]];
 [probeMap addProbe: [probeLibrary getProbeForVariable: "improvementFactor"
				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "temporalImprovementFactor"
				    inClass: [self class]]]; 
 //[probeMap addProbe: [probeLibrary getProbeForVariable: "copyValues"
 //				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "removalFactor"
				    inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "narySupressionRate"
				  inClass: [self class]]];
 [probeMap addProbe: [probeLibrary getProbeForVariable: "maxPredictorCount"
				  inClass: [self class]]];
 [probeMap addProbe: [probeLibrary getProbeForVariable: "interest"
 			  inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "variance"
 				  inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "performanceFactor"
				  inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "exploreNegativeValue"
				  inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: "noiseTolerance"
				  inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "coxStuartSignificance"
				   inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "coxStuartCaseCount"
				   inClass: [self class]]]; 
 [probeMap addProbe: [probeLibrary getProbeForVariable: "temporalCoxStuartCaseCount"
				   inClass: [self class]]]; 
  // And one method, the "printOn" method.
  [probeMap addProbe: [[probeLibrary getProbeForMessage: "printOn"
			     inClass: [self class]]
			setHideResult: 1]];

  // And another method, the "printAsRule" method.
  [probeMap addProbe: [[probeLibrary getProbeForMessage: "printAsRule"
			     inClass: [self class]]
			setHideResult: 1]];

 [probeMap addProbe: [probeLibrary getProbeForVariable: "objectToProbe"
				   inClass: [self class]]]; 
 // And another method, the "probeGroup" method.
  [probeMap addProbe: [[probeLibrary getProbeForMessage: "probeGroup"
			     inClass: [self class]]
			setHideResult: 1]];

 // And another method, the "probeNode" method.
  [probeMap addProbe: [[probeLibrary getProbeForMessage: "probeNode"
			     inClass: [self class]]
			setHideResult: 1]];

  // Now install our custom probeMap into the probeLibrary.
  [probeLibrary setProbeMap: probeMap For: [self class]];
  
  return obj;
}

-createEnd {
  return [super createEnd];
}

-buildObjects {
  int i;

  // allow our parent class to build anything.
  [super buildObjects];

  // Set index - temp test var

  // Now set up the grid used to represent agent position
  grid = [Grid2d createBegin: [self getZone]];
  [grid setSizeX: gridXSize Y: gridYSize];
  grid = [grid createEnd];

  // Create a list to keep track of the Nodes in the model.
  nodeList = [List create: [self getZone]];
  terminalNodeList = [List create: [self getZone]];
  temporalNodeList = [List create: [self getZone]];
  groupList = [List create: [self getZone]];
  effectorArray = [Array create: [self getZone] setCount: effectorCount];
  detectorArray = [Array create: [self getZone] setCount: detectorCount];

  dropList = [List create: [self getZone]];              

  // temporary lists used to create detector connections

  newInputList = [List create: [self getZone]];              
  oldInputList = [List create: [self getZone]];              
  newConnectionsList = [List create: [self getZone]];              
  activeList = [List create: [self getZone]];              
  predictorList = [List create: [self getZone]];              
  extendList = [List create: [self getZone]];              
  lastExtendList = [List create: [self getZone]];              
  temporalPredictorList = [List create: [self getZone]];              
  terminalGroupList = [List create: [self getZone]];              
  passivePredictorList = [List create: [self getZone]];              

  // Create  detector nodess.

  [grid setOverwriteWarnings: 0];

  // Now a loop to create detectorCount detector nodes.

  for (i = 0; i < detectorCount; i++) {
    DetectorNode * node;
    
    // Create the node, set the creation time variables
    node = [DetectorNode createBegin: [self getZone]];
    [node setGrid: grid];
    [node setX: 0 Y: i];
    [node setColor: 4];
    [node setModel: self];
    [node setFamily: (i + 1)];
    [node setNodeNumber: [self getNextNodeNumber: node]];
    node = [node createEnd];

    [node buildObjects];

    // Add the node to the end of the list.
    [detectorArray atOffset: i put: node];

    // Now initialize the rest of the node's state.
  }

 // Create groups for each detector node

   [detectorArray forEach: M(createGroup)];

// Create Effectors 

  for (i = 0; i < effectorCount; i++) {
    Effector * effector;

    // Create the effector, set the creation time variables
    effector = [Effector createBegin: [self getZone]];
    [effector setGrid: grid];
    [effector setX: ([grid getSizeX] - 1) Y: i];
    //    [effector setColor: 2];
    [effector setPosition: i];
    [effector setAgentModel: self];
    effector = [effector createEnd];

    [effector buildObjects];

    // Add the effector to the end of the list.
    [effectorArray atOffset: i put: effector];
 
    // Now initialize the rest of the node's state.
  }
 
  [grid setOverwriteWarnings: 1];		  // ok, done cheating.

  return self;
}


-buildActions {

  [super buildActions];
  
  return self;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  return [self getSwarmActivity];
}

-(int) getNextTreeNumber
{
    return ++nextTreeNumber;
}

-(int) getTreeCount
{
    return nextTreeNumber;
}

-(long) getNextNodeNumber: (id) aNode
{
  // Proxy nodes are not included in counts, as thye are assigned the 
  // same node number as their groups, without calling this method.
  // Nary proxy nodes are not added to the nodelist.
  // Terminal groups have two proxy nodes, both these use the group 
  // node number, so are not included in this count.
  // The number for the terminal node is used for the terminal group,
  // this is never called to create a terminal group number.

  if ([aNode respondsTo: M(isUnary)])
  {
      unaryNodeCount++;
      unaryCreated++;
  }  
  else
      if ([aNode respondsTo: M(isNary)])
      {
         if ([aNode respondsTo: M(isTemporal)])
         {
	   if (debug)
	     printf("\n incrementing temporalNodeCount");

            temporalNodeCount++;
            temporalCreated++;
         }
         else
         {
	    if ([aNode respondsTo: M(isTerminal)])
            {
                terminalNodeCount++;
                terminalCreated++;
            }
            else
            {
                naryCreated++;
                naryNodeCount++;
            }
	 }
      }
      

  if ([aNode respondsTo: M(isGroup)]) {
    groupsCreated++;
    nodeGroupCount++;
  }
  else
  {
    nodeCount++;     
  }

  nextNodeNumber++;

  return nextNodeNumber;
}

-addNodeGroup
{
  // this is used by nodeGroup when its method setNodeNumber is called
  // (some groups receive a nodeNumber from other nodes rather than
  //  the agentModel).
  nodeGroupCount++;
  return self;
}  


// Note: Nary proxy nodes are not added to the nodelist.
// Nor is removeNode called for proxy Nary nodes.
-(void) removeNode: (id) aNode
{
  if ([lastExtendList contains: aNode])
    [lastExtendList remove: aNode];

  if ([aNode respondsTo: M(isUnary)]) {
      unaryNodeCount--;
      if ([nodeList contains: aNode])
	[nodeList remove: aNode];
  }
  else {
    if ([aNode respondsTo: M(isGroup)])
      {
	nodeGroupCount--;
	if ([groupList contains: aNode]) {
	  [groupList remove: aNode];
	}
      }
    else {    
      if ([nodeList contains: aNode])
	[nodeList remove: aNode];
      if ([aNode getSuspended] == False) 
	[self removeActive: aNode];
      nodeCount--;
      if ([aNode respondsTo: M(isTemporal)]) {
	// May 23 2002 - changed following:
	if ([temporalNodeList contains: aNode]) {
	  temporalNodeCount--;
	  [temporalNodeList remove: aNode];
	}
      }
      else {
	if ([aNode respondsTo: M(isTerminal)]) {
	  if ([terminalNodeList contains: aNode])
	    [terminalNodeList remove: aNode];
	  terminalNodeCount--;
	}
	else {
	  naryNodeCount--;
	}
      }
    }
  } 
}


-addTerminalGroup: (id) aGroup
{
  if (![terminalGroupList contains: aGroup])
    [terminalGroupList addLast: aGroup];
  return self;
}

-removeTerminalGroup: (id) aGroup
{
  if ([terminalGroupList contains: aGroup])
     [terminalGroupList remove: aGroup];
  if ([groupList contains: aGroup])
     [groupList remove: aGroup];
  return self; 
}

-removeFromList: (id) aNode
{

   if ([aNode respondsTo: M(isTerminal)])
   {
       if ([terminalNodeList contains: aNode])
           [terminalNodeList remove: aNode];
   }
   else
      if ([aNode respondsTo: M(isTemporal)])
      {
         if ([temporalNodeList contains: aNode])
             [temporalNodeList remove: aNode];
      }
      else
         if ([nodeList contains: aNode])
            [nodeList remove: aNode];

   return self;
}


-(long) getTemporalCreated
{
   return temporalCreated;
}

-(long) getTemporalNodeCount
{
   return temporalNodeCount;
}

-(long) getTerminalCreated
{
   return terminalCreated;
}

-(long) getTerminalNodeCount
{
   return terminalNodeCount;
}

-(long) getNaryCreatedCount
{
   return naryCreated;
}
 
-(long) getNodeCount
{
  // total of all nodes including detectors 
   return nodeCount;
}

-addActive: (id) aNode
{
  if ([aNode respondsTo: M(isTemporal)])
       temporalActive++;
  else 
    if ([aNode respondsTo: M(isTerminal)]) {
	terminalActive++;
    }
    else
      if (![aNode respondsTo: M(isUnary)])
	naryActive++;

   activeCount++;
   return self;
}

-addActiveGroup {
  addedActiveGroups++;
  activeGroupCount++;
  return self;	
}

-removeGroup {
  removedGroups++;
  activeGroupCount--;
  return self;
}
	
-removeActive: (id) aNode
{
  if ([aNode respondsTo: M(isTemporal)])
    temporalActive--;
  else 
    if ([aNode respondsTo: M(isTerminal)]) {
      terminalActive--;
    }
    else
      if (![aNode respondsTo: M(isUnary)])
	naryActive--;
  
  activeCount--;
  return self;
}

-(int) getTerminalActive
{
   return terminalActive;
}

-(int) getTemporalActive
{
   return temporalActive;
}

-(int) getActiveGroupCount {
   return activeGroupCount;
}

-(int) getAddedActiveGroups {
	return addedActiveGroups;
}

-(int) getRemovedGroups {
  return removedGroups;
}

-(int) getNaryActive
{
   return naryActive;
}

-(int) getActiveCount
{
   return activeCount;
}

-getNewInputList
{
   return newInputList;
}

-setRemoveSuspended: (boolean) aBoolean
{
   removeSuspended = aBoolean;
   return self;
}

-(double) getRemovalFactor
{
  return removalFactor;
}

-(long) getUnaryCreatedCount
{
   return unaryCreated;
}

-(long) getUnaryNodeCount
{
  return unaryNodeCount;
}

-(long) getNaryNodeCount;
{
  return naryNodeCount;
}

-(long) getNodeGroupCount
{
   return nodeGroupCount;
}

-(long) getGroupsCreated
{
   return groupsCreated;
}

-(boolean) getExplore
{
   return explore;
}


-(float) getInitialQvalue
{
   return initialQvalue;
}


-(boolean) getTest
{
  return test;
}

-setTest: (boolean) aBoolean
{
   test = aBoolean;
   return self;
}

-(boolean) getUseStrength
{
   return useStrength;
}

-(int) getUnusedChainRemoval
{
   return unusedChainRemoval;
}

-(boolean) getLearning
{
    return learning;
}

-(double) getLearningRate
{
    return learningRate;
}

-(float) getPerformanceFactor
{
    return performanceFactor;
}

-removeSubordinated
{
    subordinatedCount--;
    return self;
}

-addSubordinated
{
    subordinatedCount++;
    return self;
}

-(int) getSubordinatedCount
{
    return subordinatedCount;
}

-setUseStrength: (boolean) aBoolean
{
    useStrength = aBoolean;
    return self;
}

-setDeterministicSelect: (boolean) aBoolean
{
  deterministicSelect = aBoolean;
  return self;
}

-setEndOfTrial: (boolean) aBoolean
{
   if (debug)
     fprintf(stdout, "\n In agentModel set end oftrial: %d", aBoolean);

  endOfTrial = aBoolean;
  return self;
}

-(boolean) getEndOfTrial
{
  return endOfTrial;
}


-(boolean) getUseAverageForReward
{
  return useAverageForReward;
}


-(boolean) getUseAverageForAccuracy
{
  return useAverageForAccuracy;
}

-(boolean) getDeterministicSelect
{
    return deterministicSelect;
}

-setSomeEffectorSupported: (boolean) aBoolean
{
   someEffectorSupported=aBoolean;
   return self;
}

-(boolean) getPositiveSupport {
  return positiveSupport;
}

-setPositiveSupport: (boolean) aBoolean
{
     positiveSupport = aBoolean;
     return self;
}

-getPredictorList
{
    return predictorList;
}

-setRandomEffectorRate: (int) anInt
{
  randomEffectorRate = anInt;
  return self;
}

-getExtendList
{
    return extendList;
}

-getLastExtendList
{
    return lastExtendList;
}

-(boolean) getFiniteProblem
{
    return finiteProblem;
}

-(double) getExtendThreshold
{
    return extendThreshold;
}

-(double) getNegativeExtendThreshold
{
    return negativeExtendThreshold;
}

-setVariance: (double) aFloat {
  variance = aFloat;
  return self;
}

-(double) getVariance
{
  return variance;
}

-(double) getDiscountRate
{
    return discountRate;
}

-(boolean) getCopyValues 
{
  return copyValues;
}

-(double) getTemporalExtendAccuracy
{
    return temporalExtendAccuracy;
}

-(float) getCoxStuartSignificance
{
  return coxStuartSignificance;
}

-(int) getCoxStuartCaseCount
{
  return coxStuartCaseCount;
}

-(int) getTemporalCoxStuartCaseCount
{
  return temporalCoxStuartCaseCount;
}

-(double) getThreshold
{
    return threshold;
}
-(double) getTemporalImprovementFactor
{
  return temporalImprovementFactor;
}

-(double) getImprovementFactor
{
  return improvementFactor;
}

-(int) getNarySupressionRate
{
    return narySupressionRate;
}

-(int) getMaxPredictorCount
{
    return maxPredictorCount;
}

-getTemporalPredictorList
{
    return temporalPredictorList;
}

-(boolean) getSuspendLastCorrect
{
    return suspendLastCorrect;
}

-setLearning: (boolean) aBoolean
{
   learning = aBoolean;
   return self; 
}

-(float) getNoiseTolerance
{
  return noiseTolerance;
}

-(boolean) getSelectBest
{
    return selectBest;
}

-setSelectBest: (boolean) aBoolean
{
    selectBest = aBoolean; 
    return self;
}

-(int) getActivationThreshold
{
    return activationThreshold;
}   

-setExploreNegativeValue: (double) value {
  exploreNegativeValue = value;
  return self;
}

-(double) getExploreNegativeValue {
  return exploreNegativeValue;
}

-(int) getTemporalActivationThreshold
{
  return temporalActivationThreshold;
}

-getDropList
{
   return dropList;
}


// Create temporal ok is usedto prevent more than one temporal node being
// created in a cycle. It is also set when a terminal node of an un-finalised
// chain fires to prevent duplicates forming. May 1 2000.

-(boolean) getCreateTemporalOk
{
  return createTemporalOk;
}

-setObjectToProbe: (int) toProbe {
  objectToProbe = toProbe;
  return self;
}

-(int) getObjectToProbe {
  return objectToProbe;
}

-setCreateTemporalOk: (boolean) aBoolean
{
  createTemporalOk = aBoolean;
  return self;
}

-(boolean) getDebug
{
     return debug;
}

-(boolean) getTrackActions
{
     return trackActions;
}

-(boolean) getTrackRules
{
     return trackRules;
}

-setTrackRules: (boolean) aBool 
{
  trackRules = aBool;
  return self;
}

-setDebug: (boolean) aBool 
{
  debug = aBool;
  return self;
}

-setTrackActions: (boolean) aBool 
{
  trackActions = aBool;
  return self;
}

-setFollow: (boolean) aBool {
  follow = aBool;
  return self;
}

-(boolean) getFollow {
  return follow;
}

-(boolean) getClassify;
{
  return [observer getClassify];
}

-(boolean) getUseNegative {
  return useNegative;
}


-setObserver: (id) anObserver
{
    observer = anObserver;
    return self; 
}

-(id) getObserver {
  return observer;
}

-stop
{
   [observer stop];
   return self;
}

-printOn
{
   [detectorArray forEach: M(printOn)];
   //  [nodeList forEach: M(printOn)];
   [groupList forEach: M(printOn)];
   fflush(stdout);
   return self;
}

-(id) lookUpInputName: (int) nodeNumber {
  return [[observer getEnvironment] lookUpInputName: nodeNumber];
}


-(id) lookUpEffectorName: (int) effector {
  return [[observer getEnvironment] lookUpEffectorName: effector];
}

-printAsRule {
  [groupList forEach: M(printAsRule)];
  return self;
}

-setInterest: (float) aFloat {
  interest = aFloat;
  return self;
}

-(float) getInterest {
  return interest;
}

-probeNode {

  [groupList forEach: M(probeNode:) : (void *) objectToProbe];
  return self;
}

-probeGroup {

 [groupList forEach: M(probeSelf:) : (void *) objectToProbe];
 return self;
}

-setReturnStrength: (double *) aReturn
{
  // Just in case you receive a negative value.

  if ((*aReturn < 0) && (Qreturn == 0))
     Qreturn = -10000;

  if (*aReturn > Qreturn) {
    if ([self getDebug])
      fprintf(stdout,"\n  setting return strength: %f", *aReturn);
    Qreturn = *aReturn;
  }
     return self;
}

-(float) getQreturn {
  return Qreturn;
}

@end







