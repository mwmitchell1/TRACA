// this is a swarm port of McCallum's NYC driving task.

#import "EnvironmentSwarm.h"
#import "Cell.h"
#import <collections.h>
#define __USE_FIXED_PROTOTYPES__   // for gcc headers
#include <stdio.h>
#include <strings.h>
#import "NYDConstants.h"
#import "Nyd_sm.h"

// #define STRLENGTH 27 // if !enumerative 24 is enough
// Changed Fed 10 2022 - from 20 to 21 - added space for last action
#define STRLENGTH 21 // we lose 2 inputs if not using gazebackwards
                     // (only one truck speed too)
 
@implementation EnvironmentSwarm

+createBegin: (id) aZone
{
   EnvironmentSwarm * obj;
   id <ProbeMap> probeMap;
 
   obj = [super createBegin: aZone];
   obj->reward=0;
   obj->bumpPenalty = 0;
   obj->enumerative = 1;

   obj->gridXSize=5;
   obj->gridYSize=5;

   obj->on=1;
   obj->correctCount=0;
   obj->incorrectCount=0;
   obj->predictionCount=0;
   obj->inputString = [String create: aZone];
   obj->lastInputString = [String create: aZone];
 
   obj->agentXpos=0;
   obj->agentYpos=0; 
   obj->rewardXpos=0;
   obj->rewardYpos=0;
   obj->display=1;
   obj->write=0;
   obj->epochCount=10000;  // CAREFUL - THIS IS OVERRIDDEN IN truckJob by parameter to setProblem

   // My policy
   obj->lastRule = 0;
   
   obj->problemFile = [String create: aZone];

   probeMap = [EmptyProbeMap createBegin: aZone];
   [probeMap setProbedClass: [self class]];
   probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameter
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridXSize"
         			     inClass: [self class]]];
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridYSize"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentXpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentYpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "display"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "write"
 				     inClass: [self class]]];  
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "printOn"
	 		     inClass: [self class]]
			setHideResult: 1]];
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "resetAgentPosition"
			     inClass: [self class]]
			setHideResult: 1]];
   [probeLibrary setProbeMap: probeMap For: [self class]];

   return obj;
}

-setString: (char *) aString
{
   [inputString setC: aString];
   return self;
}

-setAgent: (id) anAgent
{
   agentModel = anAgent;
   return self;
}

-createEnd
{
   return [super createEnd];
}

-buildObjects {

  [super buildObjects];

  
  // [self loadFile];
  gridXSize = 5;
  gridYSize = 5;

  grid = [Grid2d createBegin: [self getZone]];
  [grid setSizeX: gridXSize Y: gridYSize];
  grid = [grid createEnd];

  [self setUpDisplay];

  // Now build NTD world, then agent sensory model.

  nydConstants = [NYDConstants createBegin: [self getZone]];
  [nydConstants  loadConstantsFromFile: "constants.dat"];
  [nydConstants updateCalculatedValues];
  nydConstants = [nydConstants createEnd];

  nydSm = [Nyd_sm createBegin: [self getZone]];
  [nydSm nyd_sm_init: nydConstants];
  nydSm = [nydSm createEnd];
  [nydSm setAgentModel: agentModel];
  [nydSm setEnvironment: self];

  if (write)
    [nydSm writeDescription]; // initial call

  return self;
}

-getNydConstants {
  return nydConstants;
}

-setUpDisplay 
{

  int x, y;

  cellCount =  (gridXSize * gridYSize);

  //  printf("\n cell count: %d", cellCount);
  cellArray = [Array create: [self getZone] setCount: cellCount];
  
  for (x = 0; x < gridXSize; x++) 
    for (y = 0; y < gridYSize; y++)
      { 
	Cell * cell;
	
	// Create the cell, set the creation time variables
	cell = [Cell createBegin: [self getZone]];
	[cell setGrid: grid];
	[cell setX: x Y: y];
	[cell setModel: self];
	cell = [cell createEnd];
	
	[cell buildObjects];
	
	[cellArray atOffset: (y + x * gridYSize) put: cell];
	//	printf("\n creating cell x: %d y: %d location: %d", x, y,
	//       (y + x * gridYSize));
      }
  
  outputfp = fopen("agent.out","w");
  if (outputfp == NULL)
    printf("\n WARNING:  output file not opened");   
  fflush(stdout);
  
  return self;
}


-buildActions {

  [super buildActions];

  return self;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  return [self getSwarmActivity];
}


-getCellArray
{
   return cellArray;
}

-update
{ 
 //  must get the position of the selected action from the agent, then update
 //  environment accordingly.   A new input string is then passed 
 //  to the agent along with the reward from the last action.

   int vector[100];
   int x=0;
   int y = 0;
   char* inputs;
   FILE* out;

   [inputString setC: ""];

   // the position of a particular dimension's value in the percept
   // vector is given by the dimension of that percept.
   // Some percepts may be disabled.
 
   // Even though there may be 2 color dimensions (road + truck)
   // these share the same vector position (i.e are treated as one).

   // The highest value any dimension can have is 3, so all 
   // dimensions allowed values from 0 to 3.
   // Some dimensions may be excluded based on selections in
   // constants file.  Working out which dimension is which
   // requires manual investigation for the default values we have
   // the following:
   // 1. distanceDimension
   // 2. distanceTwoDimensions Took this out Jan 2022
   // 3. sideDimension 
   // 4. objectDimension
   // 5. directionDimension
   // 6. speedDimension
   // 7. hearHorn
   // 8. canSeeColor 

   // Order of dimensions (move up when dims excluded):
   // 1. truck/road/shoulder color (6 bits)
   // 2. refined distance (2 bits)
   // 3. distance dimension
   // 4. speed  (2)
   // 5. gaze direction (2)
   // 6. gazeSide (3)
   // 7. gazeObject (3)
   // 8. hearHorn (2)

   [nydSm nyd_sm_get_percept_vector:  vector];

   //   epochCount++;

   if (display)
     out = stderr;
   else
     out = stdout;

   reward = [nydSm nyd_sm_reward];

   if (write) 
     fprintf(out, "Percepts: ");
     
     // Add in 2 bits for reward
   if (reward < 0) {
     // [self convertEnumFrom: 0 to: inputString length: 2];
     [self convertEnumFrom: 1 to: inputString length: 2];
     if (write) 
       fprintf(out, "%d ", 0);
   }
   else {
     // [self convertEnumFrom: 0 to: inputString length: 2];
     [self convertEnumFrom: 2 to: inputString length: 2];
     if (write) 
       printf("%d ", 1);
   }
   if (write)
     fprintf(out,"Nbr Perceptual Dims: %d ", [nydConstants getNumberPerceptualDimensions]);
   if (write) {
      for (x = 0; x < [nydConstants getNumberPerceptualDimensions]; x++) {
	// for (x = 2; x < [nydConstants getNumberPerceptualDimensions]; x++) {
       fprintf(out, "%d ", vector[x]);
     }
     fprintf(out, "\n");
   }

   // if enumerative 1st parameter is 6 bits, remainder all 2 or more
   if (enumerative) {
      [self convertEnumFrom: (vector[0] + 1) 
	    //                             [self convertEnumFrom: 0 
	    to: inputString length: 6];
     for (x = 1; x < [nydConstants getNumberPerceptualDimensions]; x++) {

       // removed refined distance
       // if (x==1 || x == 2 || x == 14 || x == 9)
	 /*
    { 
	 [self convertEnumFrom: 0
	       to: inputString length: 3];
       } else
       */     
	 [self convertEnumFrom: (vector[x] + 1) 
	       to: inputString length: 3];  
	 /* else
	  [self convertEnumFrom: 0
	       to: inputString length: 3];
	 */
     }
   }
   else {
     for (x = 1; x < [nydConstants getNumberPerceptualDimensions]; x++) {
       [self convertFrom: (vector[x] + 1)
	     to: inputString length: 3];
     }	
   }

  
 

   // Added Feb 10 - add last action to input
   if (getCurrentTime() > 1)
     [self convertFrom: [agentModel getLastAction]
		  to: inputString length: 4];
   else
     [self convertFrom: 0
		  to: inputString length: 4];

     inputs = (char *) [inputString getC];

   // Added Jan 2022 - to pad out input string to 20 chars
    x = strlen(inputs);
   if (x < 21) {
     [self convertFrom: 0
		to: inputString length: 20 - x];
     inputs = (char *) [inputString getC];
   }
	
     
   if (write) {
     fprintf(out, "Percepts: ");
     fprintf(out, "%c", inputs[0]);
     fprintf(out, "%c", inputs[1]);
     fprintf(out, " ");
     for (x=2; x < 8; x++)
       fprintf(out, "%c", inputs[x]);
     fprintf(out, " ");
     for (y =8; y < 21; y++) {
       fprintf(out, "%c", inputs[y]);
       if (y == 10 || y == 13 || y == 16)
	 fprintf(out, " ");
     }
     fprintf(out, "\n");
   }

   if (getCurrentTime() == epochCount){ // (epochCount)) {
     [agentModel setLearning: False];
     [agentModel setRandomEffectorRate: 0];
     fprintf(stdout, "\nFinished %d training steps. ", epochCount);
     fflush(stdout);
   }

   if (getCurrentTime() == (epochCount + 5000))
     {
       fprintf(stdout, "  Collisions over 5000 ts after %d training steps:, %d,", 
	       epochCount, [nydSm getCollisionCount]);
       fprintf(stdout, "final: groups:, %d, temporal nodes:, %d, terminal nodes:, %d, naryNodes:, %d,", [agentModel getUnsuspendedGroups], [agentModel getTemporalActive], [agentModel getTerminalActive], [agentModel getNaryActive]);
     fprintf(stdout, "\n UNfinal: groups:, %d, temporal nodes:, %d, terminal nodes:, %d, naryNodes:, %d", [agentModel getNodeGroupCount], [agentModel getTemporalNodeCount], [agentModel getTerminalNodeCount], [agentModel getNaryNodeCount]);
       fflush(stdout);
       [(AgentModelSwarm *) agentModel stop];
     }     

   return self;

}

-step
{
   if (on == 1)  // first input
   {
       on = 0;
       reward = 0;
       [self update];
   }
   else
       [self answer];
   if ([agentModel getDebug]) {
     printf("\n--------------------------------------------------------");
     printf("\n ENVIRONMENT: Input String is :%s", [inputString getC]);     
   }

   [agentModel setDetectorInput: inputString Reward: reward];
   [lastInputString setC: [inputString getC]];
   return self;    
}

-answer
{

   effectorAction = [agentModel getLastAction]; 

   [nydSm nyd_sm_perform_action: effectorAction];

   reward = 0;    
   reward = [nydSm nyd_sm_reward];

   //   printf("\nAction is: %d reward is: %f\n", effectorAction, reward);
       
   if ([agentModel getUseStrength])
       predictionCount++;
 
   if ([agentModel getDebug])
     printf("\n\t\t ENVIRONMENT: Action Selected received reward %f", reward);
   
   if (reward > 0)
   {
      if ([agentModel getUseStrength])
         correctCount++;
      if ([agentModel getDebug])
	printf("\n\t\t              Goal achieved");
      if ([agentModel getTest])
          reward = 0;
   }
   else
   {
      incorrectCount++;
      if ([agentModel getDebug])
	printf("\n\t\t ENVIRONMENT: No Goal Achieved");
   }

  [self update];

  [agentModel setDetectorInput: inputString Reward: reward];

  if (![agentModel getExplore])
    {
      if ([agentModel getDebug])
	fprintf(outputfp,"Total moves: %d, Times goal achieved: %d", 
		predictionCount, correctCount);
    }

  if (write)
    [nydSm writeDescription];

  return self;
}


// Coverts directly to binary representation

-(void) convertFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "000000000000000"; 
    char temp1[STRLENGTH] = "";

    if (anInt >= 128)
    {
        temp[7] = '1';
        anInt = anInt - 128;
    }

    if (anInt >= 64)
    {
        temp[6] = '1';
        anInt = anInt - 64;
    }  

    if (anInt >= 32)
    {
        temp[5] = '1';
        anInt = anInt - 32;
    }
    
    if (anInt >= 16)
    {
        temp[4] = '1';
        anInt = anInt - 16;
    }

    if (anInt >= 8)
    {
        temp[3] = '1';
        anInt = anInt - 8;
    }

    if (anInt >= 4)
    {
        temp[2] = '1';
        anInt = anInt - 4;
    }

    if (anInt >= 2)
    {
        temp[1] = '1';
        anInt = anInt - 2;
    }
     
    if (anInt == 1)
    {
        temp[0] = '1';
    }
    else
      if (anInt > 0)    
	printf("\nWarning -  EnvironmentSwarm::convertInt unable to convert integer");
    
    strncat(temp1,temp,length);
    [aString catC: temp1];
}    


// Converts to enumerative representation

-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "000000000000000"; 
    char temp1[STRLENGTH] = "";

    temp[anInt - 1] = '1';

    strncat(temp1,temp,length);
    [aString catC: temp1];
}    

-getGrid
{
  return grid;
}

-getString
{
   return inputString;
}

-(float) getPredictiveAccuracy
{
  float tempPredictionCount=0;
  float tempCorrectCount = 0;
  float accuracy=0;

  if (predictionCount > 0)
  {
     tempPredictionCount = predictionCount;
     tempCorrectCount = correctCount; 
     accuracy = ((100.0/tempPredictionCount) * tempCorrectCount);
  }
  if ([agentModel getDebug])
    printf("\n predictionCount, %d, correctCount, %d, accuracy: %f",
                   predictionCount, correctCount, accuracy);
  return accuracy;
}

-(int) getIncorrectCount
{
   return incorrectCount;
}

-printOn
{
   printf("\n Environment String: %s", [inputString getC]);
   return self;
}


-resetAgentPosition
{

  /*
  int x = 0;

  [[positionArray atOffset: agentPosition] setOccupied: False];

  if (relocatePosition == 0) {
    agentPosition = [uniformIntRand getIntegerWithMin: 0 
				    withMax: ([resetList getCount] - 1)];
    temp = [resetList atOffset: agentPosition];
    x = 0;
    for(x = 0; [positionArray atOffset: x] != temp; x++)
	  ;
    agentPosition = x;
  }
  else
    agentPosition =  (relocatePosition - 1);

  [[positionArray atOffset: agentPosition] setOccupied: True];

  on = 1;
  */
  return self;
}

-setProblem: (char *) fileName epochs: (int) epochs
{
  [problemFile setC: fileName];
  epochCount = epochs;
  return self;
}


-lookUpInputName: (int) nodeNumber {
  id name = [String create: [self getZone]];

  switch (nodeNumber) {
  case 1:
    [name setC: "Bumped"];
    break;
  case 2:
    [name setC: "Smooth"];
    break;
  case 3:
    [name setC: "SeeRed"];
    break;
  case 4:
    [name setC: "SeeGrey"];
    break;
  case 5:
    [name setC: "SeeBlue"];
    break;
  case 6:
    [name setC: "SeeWhite"];
    break;
  case 7:
    [name setC: "SeeYellow"];
    break;
  case 8:
    [name setC: "SeeEmerald"];
    break;
  case 9:
    [name setC: "WithinAtFar"];
    break;
  case 10:
    [name setC: "WithinAtNear"];
    break;
  case 11:
    [name setC: "Nothing"];
    break; 
  case 12:
    [name setC: "GazingAtNose"];
    break; 
  case 13:
    [name setC: "GazingNear"];
    break;
  case 14:
    [name setC: "GazingFar"];
    break;
  case 15:
    [name setC: "LookingLeft"];
    break;
  case 16:
    [name setC: "LookingCenter"];
    break;
  case 17:
    [name setC: "LookingRight"];
    break;
  case 18:
    [name setC: "SeeRoad"];
    break;
  case 19:
    [name setC: "SeeTruck"];
    break;
  case 20:
    [name setC: "SeeShoulder"];
    break;
  default:
    [name setC: "Unknown Percept"];
    printf("\n WARNING: Unknown percept bit position: %d", nodeNumber);
    break;
  }

  return name;
}

-lookUpEffectorName: (int) number {

  id name = [String create: [self getZone]];

  switch (number) {
  case 0:
    [name setC: "ShiftGazeLeft"];
    break;
  case 1:
    [name setC: "ShiftGazeCenter"];
    break;
  case 2:
    [name setC: "ShiftGazeRight"];
    break;
  case 3:
    [name setC: "MoveToGazeLane"];
    break;
  case 4:
    [name setC: "ShiftGazeBackwards"];
    break;
  default:
    [name setC: "Unknown Action"];
    break;
  }

  return name;

}

-executeRules
{
  int action = 0;

  // by default shift gaze center

  //  printf("\n lastRule: %d", lastRule);

  if (lastRule == 0) {
    action = 3;
  }
       
  if (lastRule == 4) {  // if we gazed left
    if ([self isOn: 20]) {  // if seeShoulder
      action = 2;           // gazeRight
      lastRule = 5;
    } else {
      lastRule = 0;
      action = 1;           // gazeCenter
    }
  }


 // if lookingCenter and gazingFar (ADDED gazingFar)

  if ((lastRule == 0) && [self isOn: 16] && [self isOn: 14]
      && ![self isOn: 19]){
    action = 0;       //gazeLeft
    lastRule = 4;  
  }


  // seeNear and farWithin and gazeCenter
  /*
  printf("\n self is on 14: %d", [self isOn: 14]);
  printf("\n self is on 11: %d", [self isOn: 11]);
  printf("\n self is on 7: %d", [self isOn: 7]);
  */

  if (lastRule == 2) {   
    lastRule = 0;
    action = 3;             // move (either stays where is or shifts right
  }

  if (lastRule == 1) {
    if ([self isOn: 14]) {  // if seeFar
      action = 3;           //  move
    } else {
      action = 2;            // gazeRight
    }
    lastRule = 2;          
  }

  // if gazingCenter and seeNear and withinFar 
  if ((lastRule == 0) 
      && [self isOn: 16] && [self isOn: 13] && [self isOn: 9]) {
    action = 0;   // gazeLeft
    lastRule = 1;
  }

  if (lastRule == 5) {
    if ([self isOn: 14]) // if gazing far
      action = 3;            // move
    else
      action = 1;        // gazeCenter again
    lastRule = 0;
  }

  // truck is right in front move no matter what.

  // ADDED FOLLOWING THREE RULES 

  if (lastRule == 8) {
      action = 3;
      lastRule = 0;
  }

  if (lastRule == 7) {
    if ([self isOn: 20]) { // see shoulder
      action = 0; // look left
      lastRule = 8;
    } else {       // just move
      lastRule = 0;
      action = 3;
    }
  }

  // if a truck is right in front of you

  if (([self isOn: 16] && [self isOn: 12])
     || ([self isOn: 13] && [self isOn: 16] )) { // looking at nose and center
    lastRule = 7;
    action = 2;  // gaze right to move
  }

  if ([self isOn: 20] && action == 3) // if see shoulder and try to move
    action = 1;                       // look center 

  /*
  printf("\n inputs:");
  for (count = 1; count < 16; count++) {
    printf("%d", [self isOn: count]);
  }

  printf("\n Execute rules called action is: %d lastRule: %d", action, lastRule);
  */
    
  [agentModel setEffector: [[agentModel getEffectorArray] atOffset: action]];

  return self;
}


-(boolean) isOn: (int) position {

  char* inputs;

  inputs = (char *) [inputString getC];
  if (inputs[position - 1] == '1')
    return True;
  return False;
}

-(boolean) getDisplay {
  return display;
}

-setDisplay: (boolean) aBool {
  display = aBool;
  return self;
}

-setWrite: (boolean)  aBool
{
  write = aBool;
  return self;
}

-(boolean) getWrite
{
  return write;
}

-(int) getEpochCount {
  return epochCount;
}

-timeOut {
  // not required
  return self;
}

@end






















