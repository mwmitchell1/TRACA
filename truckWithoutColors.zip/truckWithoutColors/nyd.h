/* Interface to the New York Driving world for reinforcement learning.
   Andrew McCallum <mccallum@cs.rochester.edu> 1995
   */

#ifndef __nyd_h
#define __nyd_h 1

#define NYD_NUM_TRUCK_COLORS 6
#define GAZE_COLOR_MAX_TRUCK_COLOR (NYD_NUM_TRUCK_COLORS - 1)

#ifndef YES
#define YES 1
#endif
#ifndef NO
#define NO 0
#endif


/* Global variables for holding the state of the world. */
extern int nyd_num_lanes, nyd_num_positions;
extern int nyd_agent_lane, nyd_agent_position;
extern struct nyd_truck ***nyd_grid;
extern int nyd_last_action_illegal;

/* Global variables for setting parameters of the world's behavior. */
extern int nyd_max_truck_speed;
extern int nyd_min_truck_speed;
extern float nyd_new_truck_probability;
extern float nyd_double_truck_probability;
extern float nyd_fast_truck_probability;

/* Functions for manipulating the world. */

/* Initialize the world.  This function should be called before any
   other nyd_ functions. */
void nyd_init (int num_lanes, int num_positions);

/* Make a time tick happen.  Update the position of the trucks, and
   add new trucks if appropriate. */
void nyd_update ();

/* Functions for doing the agent's overt actions. */

void nyd_agent_right_action ();
void nyd_agent_left_action ();
void nyd_agent_straight_action ();

/* Trucks. */

struct nyd_truck
{
  int speed;
  int color;
};

/* Low-level functions for manipulating the world. */

int nyd_truck_in_lane (int lane);
void nyd_add_random_truck ();
void nyd_add_trucks ();
void nyd_update_trucks ();
void nyd_place_agent (int lane, int position);
int nyd_position_of_next_truck (int lane, int position);
int nyd_position_of_prev_truck (int lane, int position);
int nyd_horn_is_blowing ();
struct nyd_truck *nyd_truck_at_position (int lane, int position);

struct nyd_truck *nyd_truck_create (int speed, int color);
void nyd_truck_destroy (struct nyd_truck *t);
void nyd_add_truck (struct nyd_truck *t, int lane, int position);

#define NYD_ERROR(_STR) \
({ fprintf (stderr, _STR); abort(); })

#endif /* __nyd_h */








