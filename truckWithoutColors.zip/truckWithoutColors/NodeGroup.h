#import <objectbase/SwarmObject.h>
#import "Node.h"
#import "DetectorNode.h"
#import "NaryNode.h"
#import "boolean.h"


// a node group is a node which contains a collection of nodes
// That is, it implements the protocol of a node that can be predicted
// but in fact interfaces between one node and the group it contains.
// A group is created when a node is copied and the inputs to the 
// copy are identical, even if the prediction is different.
// This way any node which predicted the original node now predicts the copy 
// also, although this is transparent to it because its prediction has 
// actually been replaced by a node group, which forwards its messages  

// Its main purpose isto balance payments to predictors nodes, and copy the 
// predictors of one node to the copied node therefore preventing the
// need to rediscover its preceedor. 

@interface NodeGroup : SwarmObject 
{
        id terminalNode;
	id terminalGroup;

	boolean higherValue;
	boolean added;

        id proxyNode;
        id firstNode;

	id nodeList;  
        id rewardList;
	id primaryNode;

        id previousNodeList;

	id highestActionNode;
	int improvedNodeCount;
	id mostFrequentPositive[100];
	id mostFrequentNegative[100];

	float highestAction;
	float interest;
	boolean preventTemporalConnect;
	boolean temporallyActivated;
	boolean inputsRemoved;
	boolean lastInhibited;
        boolean inhibited;
        boolean topGroup;
        boolean finalGroup;
        boolean miss;
        boolean hypActivePredicted;
        boolean hypPassivePredicted;     
        boolean hypSuspendedPredicted;
        boolean hypSupressed;
        boolean hypActiveSupressed;
        boolean hypLastActiveSupressed;
        boolean hypMatched;
        boolean hypActive;
        double hypStrength;
        boolean hypFired;
        double hypReturn;

        double strength;
	double Qreturn;
        double averageReturn;
        double averageReward;
	double temporalQreturn;
	double hypQreturn;

	int resetCount;
        
        id activeOwnerList, suspendedOwnerList;
        boolean passivePredicted, activePredicted, suspendedPredicted;

// Even node groups have a node Number, but they are stored
// in a different list in the agentModel. 

	int temporalActivationCount;

        long nodeNumber;
        id agentModel;
        boolean supressed;
        boolean narySupressed;
        boolean temporallySupressed;
        boolean activeSupressed;
        boolean activeActionSupressed;
        boolean activeSuppressedAtStart;
        boolean activeTemporallySupressed;
        boolean lastActiveTemporallySupressed;
        boolean lastActiveSupressed;
        boolean updateTemporalSupressed;
        boolean fired;
        boolean preFired;
        boolean realActive;
        boolean lastRealActive;
        boolean previousRealActive;
	boolean predictedByFinalisedChain;
	int predictedByNonFinalisedChain;
	boolean lastPredictedByFinalisedChain;
	int lastPredictedByNonFinalisedChain;
	boolean accuratelyPredictedOk;
	boolean accuratelyTemporallyPredictedOk;

        boolean matched;
        boolean removed; 
        boolean suspended;
}

+createBegin: (id) aZone;
-setAgentModel: (id) aModel;
-(boolean) setNodeNumber: (long) aNumber;
-setNode: (id) aNode;
-createEnd;
-buildObjects;
-(boolean) getPredictedByFinalisedChain;
-(int) getPredictedByNonFinalisedChain;
-(boolean) getLastPredictedByFinalisedChain;
-(int) getLastPredictedByNonFinalisedChain;
-removeInputChains;
-checkForMatchReset;
-removeUnfinishedChains;
-setPredictedByFinalisedChain: (boolean) aBoolean;
-incrementPredictedByNonFinalisedChain;
-realDeactivate;
-checkActivationCount;
-addToConnectList;
-constructExtendList: (id) extendList;
-(boolean) getAdded;
-setAdded: (boolean) aBool;
-(double) getMaxDiscountedTerminalValue; 
-copyNode;
-connect;
-correct;
-incorrect;
-setCorrect: (boolean) aBoolean;
-removeOwners;
-create: (DetectorNode *) anInputDetector;
-createUnaryProxy: (id) aNode;
-createNaryProxy: (id) aNode;
-createTemporalProxy: (id) aNode;
-createTerminalProxy: (id) aNode;
-connectPredictorList: (id) aList;
-getPreviousGroup;
-passUpPredictors;
-(long) getNodeNumber;
-movePredictors: (id) aNode;
-addNode: (id) aNode;
-(boolean) addPredictor:  (id) aNode;
-setActivePredicted: (boolean) aBoolean;
-setPassivePredicted: (boolean) aBoolean;
-setSuspendedPredicted: (boolean) aBoolean;
-setSteadyState: (boolean) aBoolean;
-setSuspended: (boolean) aBoolean;
-setAllSuspended: (boolean) aBoolean;
-(boolean) getActivePredicted;
-(boolean) getPassivePredicted;
-(boolean) getSuspendedPredicted;
-payPredictors;
- (boolean) maxStrengthForEffector: (id) aNode;
-sendPredictorsReturn;
-sendPreviousReturn;
-hypPayReturn: (double *) paymentEach;
-payReturn: (double *) paymentEach;
-setReturnStrength: (double *) aReturn;
-(double) getQreturn;
-updateAverageReturn; 
-setTemporalReturnStrength: (double *) aReturn;
-hypSetReturnStrength: (double *) aReturn;
-pay: (double *) paymentEach;
-addActiveOwner: (id) anOwner;
-getFirstNode;
-setTerminalNode: (id) aNode;
-getTerminalNode;
-resetTemporallyActivated;
-removeSuspendedOwner: (id) aNode;
-removeActiveOwner: (id) aNode;
-remove;
-removeTemporal;
-removeSelf: (id) aNode;
-removeNode: (id) aNode;
-(boolean) removeOwner: (Node *) aNode;
-(boolean) getUpdateTemporalSupressed;
-addToRewardList: (id) aNode;
-clearRewardList;
-addOwnerShare: (double *) rewardPtr;
-moveSuspendedOwner: (id) anOwner;
-(boolean) setSupressed: (boolean) aBoolean;
-(boolean) setNarySupressed: (boolean) aBoolean;
-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean;
-(boolean) setSupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setNarySupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean  for: (id) anEffector;
-terminalNodeMatch: (boolean) aBoolean;
-terminalNodeSetMatched: (boolean) aBoolean;
-(boolean) setActiveSupressed: (boolean) aBoolean  for: (id) anEffector;
-(boolean) setActiveActionSupressed: (boolean) aBoolean  for: (id) anEffector;
-(boolean) setActiveTemporallySupressed: 
			(boolean) aBoolean for: (id) anEffector;
-(boolean) resetActiveTemporallySupressed: (boolean) aBoolean;
-(boolean) setActiveTemporallySupressed: (boolean) aBoolean;
-(boolean) getFired;
-(boolean) getPrimaryFired;
-(boolean) setMatched: (boolean) aBoolean;
-(boolean) resetMatched: (boolean) aBoolean;
-(boolean) getMatched;
-(boolean) setTemporallySupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setTemporallySupressed: (boolean) aBoolean;
-checkActiveSupress;
-checkActiveActionSupress;
-checkSupress;
-checkNarySupress;
-checkExclude;
-checkActiveTemporalSupress;
-checkTemporalSupress;
-setTopGroup: (boolean) aBoolean;
-setFinalGroup: (boolean) aBoolean;
-(boolean) isTopGroup;
-getTerminalGroup;
-setTerminalGroup: (id) aGroup;
-(boolean) getActiveSuppressedAtStart;
-setActiveSuppressedAtStart: (boolean) aBool;
-getTopGroup;
-(double) getDependentReturn;
-(double) getActualDependentReturn;
-(double) getActualIndependentReturn;
-(double) getIndependentReturn;
-(long) getTemporalActivationCount;
-(double) getMaxTerminalValue; // discounted value
-(double) getIndependentAccuracy;
-(boolean) getFinalGroup;
-(boolean) getMatchedNow;
-(boolean) setMatched: (boolean) aBoolean;
-(boolean) resetActiveSupressed: (boolean) aBoolean;
-(boolean) resetActiveActionSupressed: (boolean) aBoolean;
-(boolean) getRealActive;
-(boolean) getLastRealActive;
-(boolean) setRealActive: (boolean) aBoolean;
-addSuspendedOwner: (id) anOwner;
-addActiveOwners: (id) aList;
-addSuspendedOwners: (id) aList;
-getPredictorList;
-getActivePredictorList;
-getSuspendedPredictorList;
-getPassivePredictorList;
-(boolean) getSuspended;
-(boolean) activePredictedBy: (id) aNode;
-(boolean) passivePredictedBy: (id) aNode;
-(boolean) suspendedPredictedBy: (id) aNode;
-getActiveOwnerList;
-getSuspendedOwnerList;
-(boolean) getTemporallyActivated;
-getNodeList;
-getProxyNode;
-findSimilarTerminalNode: (id) aNode;
-findSimilarTemporalNode: (id) aNode;
-setPreventTemporalConnect: (boolean) aBoolean;
-(boolean) getPreventTemporalConnect;
-temporalConnect; 
-checkMatched;
-(double) getAverageReturn;
-(double) getAbsAverageReturn;
-(double) getAverageReinforcement; 
-(double) getAbsAverageReinforcement; 
-(double) getAverageReward;
-setReward;
-setPrimaryNode: (id) aNode;
-getPrimaryNode;
-chainCorrect: (boolean) aBoolean;
-(void) die;
-checkCreateTemporalOk;
-checkTemporalRemove;
-ownerRemoved;
-incrementLifetimeCount;
-checkUpdateTemporalSupress;
-isGroup;
-(boolean) reset;
-drawSelfOn: (id <Raster>) aRaster;

// Temporal stuff
-payPreviousReturn: (double *) paymentEach;
-payTemporalPreviousReturn: (double *) paymentEach;
-sendTemporalReturn;
-getPreviousNodeList;
-addPreviousNode: (id) aNode;
-(boolean) getTemporallySuspended;
-setNodesSuspended;
-(int) getImprovedNodeCount;
-(boolean) getHigherValue;
-setHigherValue: (boolean) aBoolean;
-incrementImprovedNodeCount;
-decrementImprovedNodeCount;
-inhibitNodes: (boolean) aBoolean;
-incrementResetCount;
-(int) getResetCount;
// This next stuff should be in temporal group when it is used
-setAcceptingMessages: (boolean) aBoolean;
-(int) getNodeCount;
-setWaitingOnFirstInput: (boolean) aBoolean;
-setWaitingOnSecondInput: (boolean) aBoolean;
-setSecondInputMatchedNow: (boolean) aBoolean;
-setFirstInputMatchedNow: (boolean) aBoolean;
-setFired: (boolean) aBoolean;
-setPreFired: (boolean) aBoolean;
-setFrequencyFrom: (PredictorNode *) aNode;
-getMostFrequentPositive: (id) aNode;
-setMostFrequentPositive: (id) aNode to: (id) node;
-getMostFrequentNegative: (id) aNode;
-setMostFrequentNegative: (id) aNode to: (id) node;
-setAccuratelyPredictedOk: (boolean) aBool;
-(float) getInterest;
-(boolean) getAccuratelyPredictedOk;
-setAccuratelyTemporallyPredictedOk: (boolean) aBool;
-(boolean) getAccuratelyTemporallyPredictedOk;
-printOn;
-printAsRule;
-probeNode: (int) number;
-probeSelf: (int) number;
-printEffectorTotals;
-(int) getHighestAction;
-setHighestAction: (int) anInt node: aNode;

-hypPayPredictors;
-hypSendPredictorsReturn;
-hypPay: (double *) paymentEach;
-(boolean) hypActivePredictedBy: (id) aNode;
-(boolean) hypPassivePredictedBy: (id) aNode;
-(boolean) hypSuspendedPredictedBy: (id) aNode;
-checkHypActiveSupress;
-checkHypSupress;
-(boolean) setHypSupressed: (boolean) aBoolean;
-(boolean) setHypSupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setHypActiveSupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setHypFired: (boolean) aBoolean;
-(boolean) getHypFired;
-(boolean) getHypMatched;
-(boolean) setHypMatched: (boolean) aBoolean;
-(boolean) setHypActiveSupressed: (boolean) aBoolean;
-(boolean) getHypActive;
-(boolean) setHypActive: (boolean) aBoolean;
-getHypActivePredictorList;
-getHypSuspendedPredictorList;
-getHypPassivePredictorList;
-(boolean) getHypActivePredicted;
-(boolean) getHypPassivePredicted;
-(boolean) getHypSuspendedPredicted;
-setHypActivePredicted: (boolean) aBoolean;
-setHypPassivePredicted: (boolean) aBoolean;
-setHypSuspendedPredicted: (boolean) aBoolean;
-setHypStrength: (float *) aStrength;
-(boolean) getHypActiveSupressed;
-(boolean) getRemoved;
-getHighestActionNode;
-summaryOn;
-hypDeactivate;
-hypReset;
@end



