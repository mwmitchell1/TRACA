#import "NYDConstants.h"

@implementation NYDConstants

+createBegin: aZone;
{
  NYDConstants* obj;
  id <ProbeMap> probeMap;
 
  obj = [super createBegin: aZone];
  
  // Note: these are set in constants.dat!!!!!!!!!

  obj->gazeForwardLeft = 0;
  obj->gazeForwardCenter = 1;
  obj->gazeForwardRight = 2;
  obj->continueOn = 3;  // CONTINUE
  obj->gazeBackwards = 4;
  obj->canSeeShoulder = 1;

  obj->usingGazeBackwards = 0; // SET TO TRUE if using 5 actions

  obj->numberTruckColors = 6;

  // perif crash
  obj->perifNoCrashImminent = 0;
  obj->perifCrashImminent = 1;

 // Gaze 2 truck

   obj->gazeToTruckNo = 0;
   obj->gazeToTruckYes = 1;
   obj->numberOfGazeToTruckDimensions = 2;

   // Gaze distance to

   obj->gazeDistanceToFarHalf = 0;
   obj->gazeDistanceToCloseHalf = 1;
   obj->numberOfGazeDistanceToDimensions = 2;

   // Gaze distance 

   obj->gazeDistanceNose = 0;
   obj->gazeDistanceNear = 1;
   obj->gazeDistanceFar = 2;
   obj->numberOfGazeDistanceDimensions = 3;

   // Gaze Direction

   obj->gazeDirectionFront = 0;
   obj->gazeDirectionBack = 1;
   obj->numberOfGazeDirectionDimensions = 2;

   // Hear horn

   obj->hearHornYes = 0;
   obj->hearHornNo = 1;
   obj->numberOfHearHornDimensions = 2;

   // Gaze size - order of these significant

   obj->gazeLeftSide = 0;
   obj->gazeCenter = 1;
   obj->gazeRightSide = 2;
   obj->numberOfGazeSideDimensions = 3;

   // Gaze Object

   obj->gazeAtRoad = 0;
   obj->gazeAtTruck = 1;
   obj->gazeAtShoulder = 2;
   obj->numberOfGazeAtDimensions = 3;

   // default rewards

   obj->crashReward = -5.0f;
   obj->hornReward = -1.0f;
   obj->noCrashReward = 0.1f;
  
   // Gaze Speed Dimensions
   
   obj->gazeSpeedLooming = 0;
   obj->gazeSpeedReceeding = 1;
   obj->numberOfGazeSpeedDimensions = 2;

   probeMap = [EmptyProbeMap createBegin: aZone];
   [probeMap setProbedClass: [self class]];
   probeMap = [probeMap createEnd];
   
   // Add in a bunch of variables, one per simulation parameter
   [probeMap addProbe: [probeLibrary getProbeForVariable: "canSeeShoulder"
				     inClass: [self class]]];
   [probeMap addProbe: [probeLibrary getProbeForVariable: "usingGazeBackwards"
				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "canSeeColor"
				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "usingTwoTruckView"
				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "canHearHorn"
				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "usingPerifCrashDimension"
				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "perifCrashDistance"
				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "crashReward"
				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "hornReward"
				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "noCrashReward"
				     inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: 
				      "numberPerceptualDimensions"
				     inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: 
				      "numberOfColorDimensions"
				     inClass: [self class]]]; 
  [probeMap addProbe: [probeLibrary getProbeForVariable: 
				      "numberOfPerifCrashDimensions"
				     inClass: [self class]]]; 

   [probeMap addProbe: [[probeLibrary getProbeForMessage: "updateCalculatedValues"
				      inClass: [self class]]
			 setHideResult: 1]];
   
   [probeLibrary setProbeMap: probeMap For: [self class]];
   
   return obj;
}

-createEnd
{
  return [super createEnd];
}


// Read in values from file in format method<space>value.
// Method should start with an uppercase letter.
// Reads floats if first character is f ints otherwise.

-loadConstantsFromFile: (char *) aFile  {

  SEL methodId;
  int end = 0; 
  char method[100], c, type;
  char bytes[256];
  int value = 0;
  float floatValue = 0;
  FILE * inputfp;
  id methodName = [String create: [self getZone]]; 

  inputfp = fopen(aFile ,"r");
  if (inputfp == NULL) {
    printf("\nUnable to open constants file %s - exiting", aFile);
    exit(1);
  }

  [self init: method with: bytes];

  end = (int) fgets(bytes, 256, inputfp);
  end = sscanf(bytes,"%c%c",&type,&c);
  if (type == 'f')
      end = sscanf(bytes,"%c%c%s%c%f",&c, &c, method, &c, &floatValue);
  else
      end = sscanf(bytes,"%c%c%s%c%d", &c, &c, method, &c, &value);

  while(end != EOF) {
    [methodName setC: "set"];
    [methodName catC: method];
    if (type == 'f') { 
      [methodName catC: "Obj:"];  
      methodId = sel_get_uid([methodName getC]);
     // Had some problems parameter passing here. I'm too lazy to
      // define a Float object class (how I wish this was Java)
      // I have to create an Obj version of methods which take
      // float parameters and callback to get the parameter value.
      tempFloat = floatValue;
      [self perform: methodId with: self];
      //t = (char *) &floatValue;
      //objc_msg_sendv(self, methodId, t);
    //	[self perform:@selector(methodId:) withObject: floatValue];
    }
    else {
      [methodName catC: ":"];  
      methodId = sel_get_uid([methodName getC]);
      [self perform: methodId with: (id) value];
      //objc_msg_sendv(self, methodId, t);
      //	[self perform:@selector(methodId:) withObject: valueRead];
    }
    [self init: method with: bytes];
    end = (int) fgets(bytes, 256, inputfp);
    end = sscanf(bytes,"%c%c",&type,&c);
    if (type == 'f')
      end = sscanf(bytes,"%c%c%s%c%f", &c, &c, method, &c, &floatValue);
    else
      end = sscanf(bytes,"%c%c%s%c%d", &c, &c, method, &c, &value);
  }
  return self;
}

-(float) getTempFloat {
  return tempFloat;
}

-init: (char *) method with: (char *) value {
  int x;
  for (x=0;x < 100;x++) {
    method[x] = (char) NULL;
    value[x] = (char) NULL;
  }
  return self;
}

// This should be called to initialise values based on other values.
// If a value is changed using the GUI, this should be called afteerwards.

-updateCalculatedValues {

  int count = 0;

  // I am not sure about the following, I don't think it was ever used.
  if (canSeeShoulder == False)
    numberRoadColors = 3;
  else
    numberRoadColors = 1;
 
  // numberOfActions will be four if not usingGazeBackwards and five otherwise
  if (usingGazeBackwards == True) {
    numberOfActions = 5; // this will be five if usingGazeBackwards > 0 
  }
  else                      // and 4 otherwise. 
    numberOfActions = 4; 

  // perceptual dimensions

  count = 0;
  if (canSeeColor)
    colorDimension = count++;
  if (usingTwoTruckView)
    twoTruckDimension = count++;
  // distanceTwoDimension = count++; Took out Jan 2022
  distanceDimension = count++;
  if (usingGazeBackwards) {
    speedDimension = count++;
    directionDimension = count++;  
  }  
  sideDimension = count++;
  objectDimension = count++;
  if (canHearHorn) 
    hearHornDimension = count++;   
  if (usingPerifCrashDimension) 
    perifCrashDimension = count++;
 
  numberPerceptualDimensions = count; 
  // Gaze color 
  
  maxTruckColor = 6 - 1; // 6 is numberTruckColors defined in nyd.c

  // Trucks always have one of 6 different colors if using the color dimension
  // Roads may have one color or may use 3 colors.
  // Can see shoulder means you have one color for roadAndShoulder.
  // It appears that in McCallum's code the road color may also
  // be used by trucks.
  // If using separate road colors he uses the highest 3 truck colors
  // as road colors.
  
  if (canSeeShoulder) {
    // Road and shoulder have one fixed color
    roadAndShoulderColor = 1;
  }
  else {
    // Roads can have different colors
    numberOfColorDimensions = 2;
    // see Nyd-sm for number of road colors
  }
  
  // perif crash
  if (perifCrashDistance == 2) {
    perifCrashImminentInTwo = 2;  // if using perifCrashDistance == 2
    numberOfPerifCrashDimensions = 3;
  }
  else
    numberOfPerifCrashDimensions = 2;

 
  return self;
}

-(float) getCrashReward {
  return crashReward;
}

-(float) getHornReward {
  return hornReward;
}

-(float) getNoCrashReward {
  return noCrashReward;
}

-(int) getMaxTruckSpeed {
  return maxTruckSpeed;
}

-(int) getMinTruckSpeed {
   return minTruckSpeed;
}

-(float) getFastTruckProbability {
   return fastTruckProbability;
}

-(float) getNewTruckProbability {
   return newTruckProbability;
}

-(float) getDoubleTruckProbability {
   return doubleTruckProbability;
}

-(int) getNumberTruckColors {
   return numberTruckColors;
}

-(int) getNumberLanes {
   return numberLanes;
}

-(int) getNumberPositionsInLane {
   return numberPositionsInLane;
}
   
-(boolean) getUsingTwoTruckView {
   return usingTwoTruckView;
}

-(boolean) getUsingPerifCrashDimension {
   return usingPerifCrashDimension;
}

-(int) getPerifCrashDistance {
   return perifCrashDistance; // can be 1 or 2
}

-(boolean) getUsingGazeBackwards {
   return usingGazeBackwards;
}

-(boolean) getCanHearHorn {
   return canHearHorn;
}

-(boolean) getCanSeeColor {
   return canSeeColor;
}

-(boolean) getCanSeeShoulder {
   return canSeeShoulder;
}

-(int) getNumberRoadColors {
   // The following fields should not be defined, but provided  by methods.
   return numberRoadColors;  // This will be zero if canSeeShoulder
                          // is 0 or 3 otherwise
}

-(int) getNumberOfActions {
   return numberOfActions; // this will be five if usingGaxeBackwards > 0 
                        // and 4 otherwise. 
}

-(int) getGazeForwardLeft {
  return gazeForwardLeft;
}

-(int) getGazeForwardCenter {
  return gazeForwardCenter;
}

-(int) getGazeForwardRight {
  return gazeForwardRight;
}

-(int) getGazeBackwards {
  return gazeBackwards;
}

-(int) getContinueOn {
  return continueOn;
}


   // Perceptual dimensions From nyd-sm.h
   // These are all calculated and gaze except for horn and crash perception  

-(int) getColorDimension {
   return colorDimension;
}

-(int) getTwoTruckDimension {
   return twoTruckDimension;
}

-(int) getDistanceTwoDimension {
   return distanceTwoDimension;
}

-(int) getDistanceDimension {
   return distanceDimension;
}

-(int) getSpeedDimension {
   return speedDimension;
}

-(int) getDirectionDimension {
   return directionDimension;
}

-(int) getSideDimension {
   return sideDimension;
}

-(int) getObjectDimension {
   return objectDimension;
}

-(int) getHearHornDimension {
   return hearHornDimension;
}

-(int) getPerifCrashDimension {
   return perifCrashDimension;
}

-(int) getNumberPerceptualDimensions {
   return numberPerceptualDimensions;
}
   
-(int) getMaxTruckColor {
   // Gaze color 
   return maxTruckColor; // numberTruckColors - 1
}

-(int) getRoadAndShoulderColor {
   return roadAndShoulderColor;
}

-(int) getNumberOfColorDimensions {
   return numberOfColorDimensions;
}

   // Perif crash

-(int) getPerifNoCrashImminent {
   return perifNoCrashImminent;
}

-(int) getPerifCrashImminent {
   return perifCrashImminent;
}

-(int) getPerifCrashImminentInTwo {
   return perifCrashImminentInTwo;  // if using perifCrashDistance == 2
}

-(int) getNumberOfPerifCrashDimensions {
   return numberOfPerifCrashDimensions;
}

   // Gaze 2 truck

-(int) getGazeToTruckNo {
   return gazeToTruckNo;
}

-(int) getGazeToTruckYes {
   return gazeToTruckYes;
}

-(int) getNumberOfGazeToTruckDimensions { 
  return numberOfGazeToTruckDimensions;
}

   // Gaze distance to

-(int) getGazeDistanceToFarHalf {
   return gazeDistanceToFarHalf;
}

-(int) getGazeDistanceToCloseHalf {
   return gazeDistanceToCloseHalf;
}

-(int) getNumberOfGazeDistanceToDimensions {
   return numberOfGazeDistanceToDimensions;
}

   // Gaze distance 

-(int) getGazeDistanceNose {
   return gazeDistanceNose;
}

-(int) getGazeDistanceNear {
   return gazeDistanceNear;
}

-(int) getGazeDistanceFar {
   return gazeDistanceFar;
}

-(int) getNumberOfGazeDistanceDimensions {
   return numberOfGazeDistanceDimensions;
}

-(int) getGazeDirectionFront {
   return gazeDirectionFront;
}

-(int) getGazeDirectionBack {
   return gazeDirectionBack;
}

-(int) getNumberOfGazeDirectionDimensions {
   return numberOfGazeDirectionDimensions;
}

   // Hear horn
-(int) getHearHornYes {
   return hearHornYes;
}

-(int) getHearHornNo {
   return hearHornNo;
}

-(int) getNumberOfHearHornDimensions {
   return numberOfHearHornDimensions;
}

   // Gaze size - order of these significant

-(int) getGazeLeftSide {
   return gazeLeftSide;
}

-(int) getGazeCenter {
   return gazeCenter;
}

-(int) getGazeRightSide {
   return gazeRightSide;
}

-(int) getNumberOfGazeSideDimensions {
   return numberOfGazeSideDimensions;
}

   // Gaze Object

-(int) getGazeAtRoad {
   return gazeAtRoad;
}

-(int) getGazeAtTruck {
   return gazeAtTruck;
}

-(int) getGazeAtShoulder {
   return gazeAtShoulder;
}

-(int) getNumberOfGazeAtDimensions {
   return numberOfGazeAtDimensions;
}

   // Gaze Speed Dimensions
   
-(int) getGazeSpeedLooming {
   return gazeSpeedLooming;
}

-(int) getGazeSpeedReceeding {
   return gazeSpeedReceeding;
}

-(int) getNumberOfGazeSpeedDimensions {
   return numberOfGazeSpeedDimensions;
}

-setCrashReward: (float) aFloat {
  crashReward = aFloat;
  return self;
}

-setHornReward: (float) aFloat {
  hornReward = aFloat;
  return self;
}

-setNoCrashReward: (float) aFloat {
  noCrashReward = aFloat;
  return self;
}


-setCrashRewardObj: (id) object {
  crashReward = [object getTempFloat];
  return self;
}

-setHornRewardObj: (id) object {
  hornReward = [object getTempFloat];
  return self;
}

-setNoCrashRewardObj: (id) object {
  noCrashReward = [object getTempFloat];
  return self;
}
    
-setMaxTruckSpeed: (int) anInt{
  maxTruckSpeed = anInt;
  return self;
}

-setMinTruckSpeed: (int) anInt {
  minTruckSpeed = anInt;
  return self;
}
 
-setFastTruckProbability: (float) aFloat {
  fastTruckProbability = aFloat;
  return self;
}

-setNewTruckProbability: (float) aFloat { 
  newTruckProbability = aFloat;
  return self;
}

-setDoubleTruckProbability: (float) aFloat {
  doubleTruckProbability = aFloat;
  return self;
}

-setNumberTruckColors: (id) anInt {
  numberTruckColors = (int) anInt;
  return self;
}

-setNumberLanes: (int) anInt {
  numberLanes = anInt;
  return self;
}

-setNumberPositionsInLane: (int) anInt {
  numberPositionsInLane = anInt;
  return self;
}

-setUsingTwoTruckView: (boolean) aBoolean {
  usingTwoTruckView = aBoolean;
  return self;
}

-setUsingPerifCrashDimension: (boolean) aBoolean {
  usingPerifCrashDimension = aBoolean;
  return self;
}

-setUsingGazeBackwards: (boolean) aBoolean {
  usingGazeBackwards = aBoolean;
  return self;
}

-setPerifCrashDistance: (int) anInt { 
  perifCrashDistance = anInt;
  return self;
}
-setCanHearHorn: (boolean) aBoolean { 
  canHearHorn = aBoolean;
  return self;
}

-setCanSeeColor: (boolean) aBoolean {
  canSeeColor = aBoolean;
  return self;
}

-setCanSeeShoulder: (boolean) aBoolean { 
  canSeeShoulder = aBoolean;
  return self;
}

-setNumberRoadColors: (int) anInt {
  numberRoadColors = anInt;
  return self;
}

-setNumberOfActions: (int) anInt {
  numberOfActions = anInt;
  return self;
}

-setGazeForwardLeft: (int) anInt {
  gazeForwardLeft = anInt;
  return self;
}

-setGazeForwardCenter: (int) anInt {
  gazeForwardCenter = anInt;
  return self;
}

-setGazeForwardRight: (int) anInt {
  gazeForwardRight = anInt;
  return self;
}

-setGazeBackwards: (int) anInt {
  gazeBackwards = anInt;
  return self;
}

-setContinueOn: (int) anInt {
  continueOn = anInt;
  return self;
}

-setColorDimension: (int) anInt {
  colorDimension = anInt;
  return self;
}

-setTwoTruckDimension: (int) anInt {
  twoTruckDimension = anInt;
  return self;
}

-setDistanceTwoDimension: (int) anInt {
  distanceTwoDimension = anInt;
  return self;
}

-setDistanceDimension: (int) anInt {
  distanceDimension = anInt;
  return self;
}

-setSpeedDimension: (int) anInt {
  speedDimension = anInt;
  return self;
}

-setDirectionDimension: (int) anInt {
  directionDimension = anInt;
  return self;
}

-setSideDimension: (int) anInt {
  sideDimension = anInt;
  return self;
}

-setObjectDimension: (int) anInt {
  objectDimension = anInt;
  return self;
}

-setHearHornDimension: (int) anInt {
  hearHornDimension = anInt;
  return self;
}

-setPerifCrashDimension: (int) anInt {
  perifCrashDimension = anInt;
  return self;
}

-setNumberPerceptualDimensions: (int) anInt {
  numberPerceptualDimensions = anInt;
  return self;
}

-setMaxTruckColor: (int) anInt {
  maxTruckColor = anInt;
  return self;
}

-setRoadAndShoulderColor: (int) anInt { 
  roadAndShoulderColor = anInt;
  return self;
}

-setNumberOfColorDimensions: (int) anInt {
  numberOfColorDimensions = anInt;
  return self;
}

-setPerifNoCrashImminent: (int) anInt {
  perifNoCrashImminent = anInt;
  return self;
}

-setPerifCrashImminent: (int) anInt { 
  perifCrashImminent = anInt;
  return self;
}

-setPerifCrashImminentInTwo: (int) anInt {
  perifCrashImminentInTwo = anInt;
  return self;
}

-setNumberOfPerifCrashDimensions: (int) anInt {
  numberOfPerifCrashDimensions = anInt;
  return self;
}

-setGazeToTruckNo: (int) anInt {
  gazeToTruckNo = anInt;
  return self;
}

-setGazeToTruckYes: (int) anInt {
  gazeToTruckYes = anInt;
  return self;
}

-setNumberOfGazeToTruckDimensions: (int) anInt {
  numberOfGazeToTruckDimensions = anInt;
  return self;
}

-setGazeDistanceToFarHalf: (int) anInt {
  gazeDistanceToFarHalf = anInt;
  return self;
}

-setGazeDistanceToCloseHalf: (int) anInt {
  gazeDistanceToCloseHalf = anInt;
  return self;
}

-setNumberOfGazeDistanceToDimensions: (int) anInt {
  numberOfGazeDistanceToDimensions = anInt;
  return self;
} 

-setGazeDistanceNose: (int) anInt {
  gazeDistanceNose = anInt;
  return self;
}

-setGazeDistanceNear: (int) anInt {
  gazeDistanceNear = anInt;
  return self;
}

-setGazeDistanceFar: (int) anInt {
  gazeDistanceFar = anInt;
  return self;
}

-setNumberOfGazeDistanceDimensions: (int) anInt {
  numberOfGazeDistanceDimensions = anInt;
  return self;
}

-setGazeDirectionFront: (int) anInt {
  gazeDirectionFront = anInt;
  return self;
}

-setGazeDirectionBack: (int) anInt { 
  gazeDirectionBack = anInt;
  return self;
}


-setNumberOfGazeDirectionDimensions: (int) anInt {
  numberOfGazeDirectionDimensions = anInt;
  return self;
}

-setHearHornYes: (int) anInt {
  hearHornYes = anInt;
  return self;
}

-setHearHornNo: (int) anInt {
  hearHornNo = anInt;
  return self;
}

-setNumberOfHearHornDimensions: (int) anInt {
  numberOfHearHornDimensions = anInt;
  return self;
}

-setGazeLeftSide: (int) anInt {
  gazeLeftSide = anInt;
  return self;
}

-setGazeCenter: (int) anInt { 
  gazeCenter = anInt;
  return self;
}

-setGazeRightSide: (int) anInt {
  gazeRightSide = anInt;
  return self;
}

-setNumberOfGazeSideDimensions: (int) anInt {
  numberOfGazeSideDimensions = anInt;
  return self;
}

-setGazeAtRoad: (int) anInt {
  gazeAtRoad = anInt;
  return self;
}

-setGazeAtTruck: (int) anInt {
  gazeAtTruck = anInt;
  return self;
}

-setGazeAtShoulder: (int) anInt {
  gazeAtShoulder = anInt;
  return self;
}

-setNumberOfGazeAtDimensions: (int) anInt {
  numberOfGazeAtDimensions = anInt;
  return self;
}

-setGazeSpeedLooming: (int) anInt {
  gazeSpeedLooming = anInt;
  return self;
}

-setGazeSpeedReceeding: (int) anInt {
  gazeSpeedReceeding = anInt;
  return self;
}

-setNumberOfGazeSpeedDimensions: (int) anInt {
  numberOfGazeSpeedDimensions = anInt;
  return self;
}


-buildObjects
{
  
  //  [super buildObjects];

  return self;
}

@end


