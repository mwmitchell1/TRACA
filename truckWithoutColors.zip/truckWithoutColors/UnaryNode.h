#import <collections.h>
#import "PredictorNode.h"
#import "DetectorNode.h"
#import "NaryNode.h"
#import "AgentModelSwarm.h"
#import "boolean.h"

@interface UnaryNode : NaryNode 
{
	DetectorNode * inputDetector; 
}

+createBegin: (id) aZone;
-(boolean) setFamily: (int) aFamily;
-createEnd;
-buildObjects;
-realDeactivate;
-match: (boolean) aBoolean;
-(boolean) addInput: (DetectorNode *) anInput;
-(boolean) removeInput: (DetectorNode *) anInput;
-removeSelf: (id) aNode;
-isUnary;
-supress;
-narySupress;
-temporalSupress;
-activeSupress;
-copy: (id) aZone;
-(void) die;
-getInputDetector;
-drawSelfOn: (id <Raster>) aRaster;
-printOn;

-hypMatch: (boolean) aBoolean;
-hypSupress;
-hypActiveSupress;
-(boolean) hypDeactivate;
-(boolean) getActivated;
@end


