#import "Node.h"
#import "PredictorNode.h"
#import "Input.h"
#import "boolean.h"

@interface NaryNode : PredictorNode
{
	id inputList;
        int type;
        int matchCount;
        int activeCount;

	boolean activated;
	boolean isImproved;

        int hypMatchCount;
        boolean hypTestMatch;

// Subordinated means the node is kept as an AND node, until
// there are no other active AND nodes when it fires

        boolean subordinated;
        boolean testActive;
        boolean testMatch;
// moved is just a flag which tells you your inputs have moved
// you from a suspended owner to an active owner
   
        boolean inputsMoved;

        double firstInputCorrectCount;
        double firstInputCount;
	double secondInputCorrectCount;
        double secondInputCount;
     
}

+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-(boolean) addInput: (Node *) aNode AsOn: (boolean) aBoolean;
-(boolean) removeInputs;
-connectPredictorList: (id) aList;
-copyPredictor: (id) aNode;
-removeSelf: (id) aNode;
-temporalRemoveSelf: (id) aNode;
-realDeactivate;
-checkInputs;
-(boolean) compareInputs;
-(double) getCompareValue;
-(boolean) checkSuspended;
-checkPerformance;
-checkRemove;
-checkMatched;
-(void) checkSuspendedInputs;
-(double) getImprovementFactor;
-removeOwners;
-match: (boolean) aBoolean by: (Node *) aNode;
-(boolean) thisInputOn: (id) anInputNode;
-checkTemporalSupress; 
-checkNarySupress;
-requestExclusion: (id) node; 
-requestDenied; 
-exclude;
-narySupressInputs;
-narySupressOneInput;
-narySupress; 
-(boolean) setNarySupressed: (boolean) aBoolean;
-(boolean) getNarySupressed;
-checkActiveTemporalSupress; 
-activeTemporalSupress; 
-temporalSupressInputs;
-temporalActiveSupressInputs;
-temporalSupress;
-isNary;
-correct;
-incorrect;
-supress;
-updateTemporalSupress;
-checkActiveSupress;
-activeSupress;
-activeActionSupress: (id) anEffector;
-checkSupress; 
-supressInputs;
-updateTemporalSupressInputs;
-activeSupressInputs;
-setType: (int) aType;
-(int) getType;
-getNodeGroup;
-(boolean) resetMatched: (boolean) aBoolean;
-(boolean) setMatched: (boolean) aBoolean;
-(boolean) getMatched;
-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean;
-(boolean) getUpdateTemporalSupressed;
-(boolean) setSupressed: (boolean) aBoolean;
-(boolean) getSupressed;
-(boolean) setRealActive: (boolean) aBoolean;
-(boolean) setLastRealActive: (boolean) aBoolean;
-(boolean) getRealActive;
-(boolean) getSuspended;
-setSuspended: (boolean) aBoolean;
-(boolean) setTemporallySupressed: (boolean) aBoolean;
-(boolean) getTemporallySupressed;
-getInputList;
-getSuspendedOwnerList;
-getActiveOwnerList;
-setInputsMoved: (boolean) aBoolean;
-(boolean) getSubordinated;
-setSubordinated: (boolean) aBoolean;
-copy: (id) aZone;
-createGroup;
-copyNew: (id) aZone;
-setCorrectCount: (int) anInt;
-(double) getFirstInputRatio;
-(double) getSecondInputRatio;
-(double) getHighestSimilarInputValue;
-getFirstSimilarInput;
-getSecondSimilarInput;
-getInputFor: (id) aNode;
-(void) die;
-drawSelfOn: (Raster *) aRastor;
-printPredictors;
-printId;
-printOn;
-summaryOn;
-printAsRule;

-hypMatch: (boolean) aBoolean;
-hypSupress;
-hypActiveSupress;
-hypSupressInputs;
-hypActiveSupressInputs;
-(boolean) setHypMatched: (boolean) aBoolean;
-(boolean) getHypMatched;
-(boolean) setHypSupressed: (boolean) aBoolean;
-(boolean) getHypSupressed;
-(boolean) setHypActive: (boolean) aBoolean;
-(boolean) getHypActive;
-hypActivate;
-hypDeactivate;
-(boolean) getImproved;
-(boolean) getActivated;
-getHighestAction: (float) highestValue;
-(boolean) getReadyForRemoval;
@end




