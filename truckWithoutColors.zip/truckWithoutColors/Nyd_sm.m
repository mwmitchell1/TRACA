#import <collections.h>
#import <random.h>
#import "Nyd_sm.h"
#import "nyd.h"
#import <malloc.h>
#import <stdio.h>
#import "AgentObserverSwarm.h"

// A number of DEFINEd values are contained in nyd.h.
// which are used in this file.

#ifndef ABS
#define ABS(x) (((x) < 0) ? -(x) : (x))
#endif

extern int numberPerceptualDimensions; // This is defined in nyd.c instead of
// NYDConstants because it needs to be known at compile time.  
// If the code is changed to use object arrays the NYDConstants version 
// can be used instead. 

@implementation Nyd_sm

+createBegin: aZone;
{
   // Gaze Speed Dimensions

  Nyd_sm * obj;
 
  obj = [super createBegin: aZone];

  obj->nyd_sm_gaze_lane = 0;
  obj->nyd_sm_gaze_position = 0;
  obj->nyd_sm_last_action_illegal = 0;
  obj->nyd_sm_last_action_overt = 0;
  obj->nyd_sm_collision_count = 0;
  obj->nyd_sm_reward_noise_range = 0.0f;
  obj->nyd_last_action = 0;
  //  obj->pd = [Array create: [self getZone] setCount: 
  //             [Constants getNumberPerceptualDimensions]];

  obj->done = 0;

  return obj;
}

-createEnd
{
  return [super createEnd];
}

// This needs to be called after the constants object is created.

-nyd_sm_init: (NYDConstants *) aConstants;
{

  /* xxx Something smarter here? */
  
  Constants = aConstants;

  pd = (int *) malloc(sizeof(int) * [Constants getNumberPerceptualDimensions]);

  nyd_sm_gaze_lane = nyd_sm_gaze_position = 0;
  nyd_sm_last_action_illegal = False;
  nyd_sm_last_action_overt = False;
  // must be called before doing anything
  nyd_init([Constants getNumberLanes], [Constants getNumberPositionsInLane]);

  return self;
}

-(char *) nyd_sm_name_for_action: (int) a
{
  if([Constants getGazeForwardCenter] == a)
    return "Gaze forward center";
  if ([Constants getGazeForwardRight] == a)
    return "Gaze forward right";
  if ([Constants getGazeForwardLeft] == a)
    return "Gaze forward left";
  if ([Constants getGazeBackwards] == a)
    return "Gaze backward";
  if ([Constants getContinueOn] == a)
    return "Goto gaze-lane";
  
  return "Bad action index";
}

// The array in here should really be made an instance variable.
// However, then need to create an object Integer type and use this.

-(int *) nyd_sm_perception_dimensions 
{
  //  static int pd[numberPerceptualDimensions];

  if (!done)
    {
      if ([Constants getColorDimension])
	pd[[Constants getColorDimension]] = 
	  [Constants getNumberOfColorDimensions];
      if ([Constants getUsingTwoTruckView])
	pd[[Constants getTwoTruckDimension]] =
	  [Constants getNumberOfGazeToTruckDimensions];
      pd[[Constants getDistanceTwoDimension]] =  
	[Constants getNumberOfGazeDistanceToDimensions];
      pd[[Constants getDistanceDimension]] =
	[Constants getNumberOfGazeDistanceDimensions];
      if ([Constants getUsingGazeBackwards]) {
	pd[[Constants getSpeedDimension]] = 
	  [Constants getNumberOfGazeSpeedDimensions];
	pd[[Constants getDirectionDimension]] =  
	    [Constants getNumberOfGazeDirectionDimensions];
      }
      if ([Constants getCanHearHorn]) 
	pd[[Constants getHearHornDimension]] = 
	  [Constants getNumberOfHearHornDimensions];
      if ([Constants getUsingPerifCrashDimension])
	pd[[Constants getPerifCrashDimension]] = 
	  [Constants getNumberOfPerifCrashDimensions];
      pd[[Constants getSideDimension]] = 
	[Constants getNumberOfGazeDirectionDimensions];
      pd[[Constants getObjectDimension]] =  
	[Constants getNumberOfGazeAtDimensions];
      done = 1;
    }

  return pd;
}

-(char *) nyd_sm_name_for_perception_dimension: (int) dimIndex
{
 
  return "Bad perception dimension index";
}

-(char *) nyd_sm_name_for_perception: (int) perception index: (int) dimIndex
{

  return "Bad perception dimension index";
}

-(float) nyd_sm_max_reward
{
  return [Constants getNoCrashReward];
}

-(float) nyd_sm_min_reward
{
  return [Constants getCrashReward];
}

-nyd_sm_get_percept_vector: (int *) vector
{
  struct nyd_truck ***grid;
  int num_lanes, num_positions;
  int agent_lane, agent_position;
  int gaze_distance;
  int gaze_direction;

  grid = nyd_grid;
  //  assert (grid);
  num_lanes = nyd_num_lanes;
  num_positions = nyd_num_positions;
  agent_lane = nyd_agent_lane;
  agent_position = nyd_agent_position;

  /* First-time initialization of gaze_lane and gaze_position.
   */
  if (!nyd_sm_gaze_lane && !nyd_sm_gaze_position)
    {
      /* This is just like executing GAZE_FORWARD_CENTER */
      nyd_sm_gaze_lane = agent_lane;
      nyd_sm_gaze_position = 
	nyd_position_of_next_truck (nyd_sm_gaze_lane, agent_position);
    }

  gaze_distance = ABS(nyd_sm_gaze_position - agent_position);
  gaze_direction = (nyd_sm_gaze_position - agent_position > 0) ? 0 : 1;

  /* GAZE_DISTANCE_DIM */
  vector[[Constants getDistanceDimension]] 
    = [self nyd_sm_discretize: gaze_distance];

  /* GAZE_DISTANCE2_DIM */
  /* Take this out 2022 - Jan
  if ([self nyd_sm_discretize: (gaze_distance - 1)]
      != vector[[Constants getDistanceDimension]]
      || gaze_distance <= 1)
    vector[[Constants getDistanceTwoDimension]] 
      = [Constants getGazeDistanceToCloseHalf];
  else
    vector[[Constants getDistanceTwoDimension]] 
      = [Constants getGazeDistanceToFarHalf];
  */


  /* GAZE_SIDE_DIM */
  /* CAREFUL: This depends on the order of the #define's of GAZE_SIDE. */
  vector[[Constants getSideDimension]] = 1 + nyd_sm_gaze_lane - agent_lane;

  /* GAZE_OBJECT_DIM */
  if (nyd_sm_gaze_lane <= 0 || nyd_sm_gaze_lane >= num_lanes-1)
    vector[[Constants getObjectDimension]] = [Constants getGazeAtShoulder];
  else if (grid[nyd_sm_gaze_lane][nyd_sm_gaze_position])
    vector[[Constants getObjectDimension]] = [Constants getGazeAtTruck];
  else
    vector[[Constants getObjectDimension]] = [Constants getGazeAtRoad];

  if ([Constants getUsingTwoTruckView]) {
    /* GAZE_2TRUCK_DIM */
    /* Test for a truck in front of the truck you are looking at */
    if (vector[[Constants getObjectDimension]] == [Constants getGazeAtTruck])
      {
	int truck2_position;
	/* xxx Note, this does not actually indicate that there is *no* truck
	   there; there could be a truck at last position */
	truck2_position = nyd_position_of_next_truck (nyd_sm_gaze_lane, 
						      nyd_sm_gaze_position+1);
	if (truck2_position != num_lanes-1
	    && grid[nyd_sm_gaze_lane][truck2_position]->speed < 0)
	  vector[[Constants getTwoTruckDimension]] = 1;
	else
	  vector[[Constants getTwoTruckDimension]] = 0;
      }
    else
      vector[[Constants getTwoTruckDimension]] = 0;
  }

  if ([Constants getUsingGazeBackwards]) {
    /* GAZE_SPEED_DIM */
    /* First we assume we're looking forward, then we swap things if 
       we're looking backward. */
    if (vector[[Constants getObjectDimension]] == [Constants getGazeAtTruck])
      vector[[Constants getSpeedDimension]] = 
	(grid[nyd_sm_gaze_lane][nyd_sm_gaze_position]->speed < 0) ? 
	[Constants getGazeSpeedLooming] : [Constants getGazeSpeedReceeding];
    else
      vector[[Constants getSpeedDimension]] = [Constants getGazeSpeedLooming];

    if (gaze_direction == [Constants getGazeDirectionBack])
      vector[[Constants getSpeedDimension]] = !(vector[[Constants getSpeedDimension]]);
    
    /* GAZE_DIRECTION_DIM */
    vector[[Constants getDirectionDimension]] = gaze_direction;
  }

  if ([Constants getCanHearHorn]) {
    /* HEAR_HORN_DIM */
    /* If there is a faster truck right behind you, they are blowing their horn. */

    vector[[Constants getHearHornDimension]] =
      ((grid[agent_lane][agent_position-1]
	&& grid[agent_lane][agent_position-1]->speed > 0)
       ?
       1 : 0);
  }

  if ([Constants getUsingPerifCrashDimension]) { 
    /* PERIF_CRASH_DIM */
    if (grid[agent_lane][agent_position+1]->speed < 0)
      vector[[Constants getPerifCrashDimension]] = [Constants getPerifCrashImminent];
    else {
      if ([Constants getPerifCrashDistance] == 2) {
	if (grid[agent_lane][agent_position+2]->speed < 0)
	  vector[[Constants getPerifCrashDimension]] 
	    = [Constants getPerifCrashImminentInTwo];
	else
	  vector[[Constants getPerifCrashDimension]] 
	    = [Constants getPerifNoCrashImminent];
      }
      else
	vector[[Constants getPerifCrashDimension]] 
	  = [Constants getPerifNoCrashImminent];
    }
  }

  // Trucks always have one of 6 different colors if using the color dimension
  // Roads may have one color or may use 3 colors.
  // Can see shoulder means you have one color for roadAndShoulder.
  // It appears that in McCallum's code the road color may also
  // be used by trucks.
  // If using separate road colors he uses the highest 3 truck colors
  // as road colors.
  // Even though there may be 2 color dimensions (road + truck)
  // these share the same vector position (i.e are treated as one).

  
  if ([Constants getCanSeeColor]) {
    // if looking at a truck, we see the color of the truck
    if (grid[nyd_sm_gaze_lane][nyd_sm_gaze_position])
      vector[[Constants getColorDimension]] = 
	nyd_grid[nyd_sm_gaze_lane][nyd_sm_gaze_position]->color;
    else
      {
	if ([Constants getCanSeeShoulder]) {
	  // use only one color for road and shoulder 
	  vector[[Constants getColorDimension]] = 
	    [Constants getRoadAndShoulderColor];
	}
	else
	  // randomly choose a road color from last NUM_ROAD_COLORS colors 
	  
	  vector[[Constants getColorDimension]] =
	    [uniformIntRand getIntegerWithMin: 
		(NYD_NUM_TRUCK_COLORS - 1 - [Constants getNumberRoadColors])
	    withMax: (NYD_NUM_TRUCK_COLORS - 1)];
	// maxTruckColor (in NTDConstants) is num_truck_colors - 1.
      }
  }
  
 
  return self;
}

-(int) nyd_sm_discretize: (int) dist
{
  return ((dist <= 2) ? [Constants getGazeDistanceNose]
   : ((dist <= 4) ? [Constants getGazeDistanceNear]
      : [Constants getGazeDistanceFar]));
}

-nyd_sm_perform_action: (int) action
{
  struct nyd_truck ***grid;
  int num_lanes, num_positions;
  int agent_lane, agent_position;
  int forward_shoulder_gaze_position;
  int backward_shoulder_gaze_position;

  nyd_update ();		/* Update rest of trucks */

  nyd_sm_last_action_illegal = False;
  nyd_last_action_illegal = False;
  nyd_sm_last_action_overt = False;
  grid = nyd_grid;
  num_lanes = nyd_num_lanes;
  num_positions = nyd_num_positions;
  agent_lane = nyd_agent_lane;
  agent_position = nyd_agent_position;
  nyd_last_action = action;

  forward_shoulder_gaze_position = num_positions-1;
  backward_shoulder_gaze_position = 0;

  
  {
    void gaze_forward_center ()
      {
	nyd_sm_gaze_lane = agent_lane;
	nyd_sm_gaze_position = 
	  nyd_position_of_next_truck (nyd_sm_gaze_lane, 
				      agent_position+1);
      }

    if ([Constants getGazeForwardCenter] == action) {
      gaze_forward_center ();
      nyd_agent_straight_action ();
    }
    else
      if ([Constants getGazeForwardRight] == action) { 
	nyd_sm_gaze_lane = agent_lane + 1;
	if (nyd_sm_gaze_lane >= num_lanes-1)	 /* shoulder */
	  nyd_sm_gaze_position = forward_shoulder_gaze_position;
	else
	  nyd_sm_gaze_position = 
	    nyd_position_of_next_truck (nyd_sm_gaze_lane,
					agent_position+1);
	nyd_agent_straight_action ();
      } 
      else
	if ([Constants getGazeForwardLeft] == action) {
	  nyd_sm_gaze_lane = agent_lane - 1;
	  if (nyd_sm_gaze_lane <= 0)	         /* shoulder */
	    nyd_sm_gaze_position = forward_shoulder_gaze_position;
	  else
	    nyd_sm_gaze_position = 
	      nyd_position_of_next_truck (nyd_sm_gaze_lane,
					  agent_position+1);
	  nyd_agent_straight_action ();
	}
	else
	  if ([Constants getContinueOn] == action) {
	    nyd_sm_last_action_overt = YES;
	    {
	      int side = agent_lane - nyd_sm_gaze_lane;
	      if (side < 0)
		nyd_agent_right_action ();
	      else if (side == 0)
		nyd_agent_straight_action ();
	      else
		nyd_agent_left_action ();
	      /* Do a "gaze forward center" after moving */
	      agent_lane = nyd_agent_lane;
	      agent_position = nyd_agent_position;
	      gaze_forward_center ();
	    }
	  }
	  else 
	    if ([Constants getGazeBackwards] == action) { // may not be used
	      /* ...on whichever lane we're looking at now. */
	      if (![Constants getUsingGazeBackwards])
		NYD_ERROR ("action index out of bounds");
	      
	      if (nyd_sm_gaze_lane >= num_lanes-1)	 /* shoulder */
		nyd_sm_gaze_position = backward_shoulder_gaze_position;
	      else
		nyd_sm_gaze_position = 
		  nyd_position_of_prev_truck (nyd_sm_gaze_lane,
					      agent_position-1);
	      nyd_agent_straight_action ();
	    }
	    else
	      NYD_ERROR ("action index out of bounds");
  }

  {
    float r = [self nyd_sm_reward];

   if (getCurrentTime() == [environment getEpochCount])
      nyd_sm_collision_count = 0;

    if (r < 0)
      nyd_sm_collision_count++;
  }

  return self;
}

-(float) nyd_sm_reward
{
  float ret;

  // Mar 11 2002 - Commenting this out as it seems to make 
  // the problem much more difficult than it should be. 
  if (nyd_sm_last_action_illegal || nyd_last_action_illegal)
    ret = [Constants getCrashReward];
  else 
    if ([Constants getCanHearHorn] && nyd_horn_is_blowing ())
      ret = [Constants getHornReward];
    else
      ret = [Constants getNoCrashReward];

  //  ret += (float) random_double(-(nyd_sm_reward_noise_range/2),
  //		       nyd_sm_reward_noise_range/2);

  return ret;
}

// defined in nyd.m:

extern int nyd_num_lanes, nyd_num_positions;
extern int nyd_agent_lane, nyd_agent_position;

-writeDescription
{
  int l, p;
  int tick = 0;
  static int time = 0;
  struct nyd_truck* truck;
  char truck_color;
  //const char *truck_color = 'e';
  FILE* out;

  int display = [[(AgentObserverSwarm *) [agentModel getObserver] 
					 getEnvironment] getDisplay];
  if (display)
    out = stderr;
  else
    out = stdout;

  time++;

  fprintf(out, "   ");
  for (l = 0; l < nyd_num_lanes; l++)
    fprintf(out, "%d ", l);
  fprintf(out, "\n");
  for (p = nyd_num_positions-1; p >= 0; p--) {
    fprintf(out, "%2d ", p);
    for (l = 0; l < nyd_num_lanes; l++) {
      if (l == nyd_agent_lane && p == nyd_agent_position)
	{
	  if (nyd_truck_at_position(l,p))
	    fprintf(out, "@"); // Collision 
	  else
	    fprintf(out, "O");
	}
      else if (nyd_truck_at_position(l,p) != NULL)
	{
	  truck = nyd_truck_at_position(l,p);

	  truck_color = [self nameForPerception: truck->color];

	  // Upper case for slow trucks; lower case for fast trucks. 
	  if (truck->speed < 0)
	    fprintf(out, "%c", truck_color);
	  else
	    fprintf(out, "%c", tolower(truck_color));
	}
      else if (l <= 0 || l >= nyd_num_lanes-1)
	{
	  static char shoulder_chars[] = {'|', ';', '\''};
	  fprintf(out, "%c",shoulder_chars[(tick+p)%3]);
	}
      else if (0 && ((tick + p) % 3) == 0) // disabled for now 
	fprintf(out, ".");
      else
	fprintf(out, " ");
      if (l == nyd_sm_gaze_lane && p == nyd_sm_gaze_position)
	fprintf(out, "<");
      else
	fprintf(out, " ");
    }
    fprintf(out, "\n");
  }
  {
    static int last_trial_collision_sum = 0;
    if (tick == 0)
      {
	float r;
	last_trial_collision_sum = nyd_sm_collision_count;
      // If first step of this trial was a collision, deal with it. 
	r = [self nyd_sm_reward];
	if (r < 0) last_trial_collision_sum--;
      }
    fprintf(out, "\nLast action: %d", nyd_last_action);
    switch([agentModel getRandom]) {
    case 1: 
      fprintf(out, "  RANDOM - rate\n");
      break;
    case 2:
      fprintf(out, "  RANDOM - no support\n");
      break;
    case 3:
      fprintf(out, "  Roulette positive\n");
      break;
    case 4:
      fprintf(out, "  Roulette negative\n");
      break;
    default:
      fprintf(out, "\n");
    }

    // FOR SLOW TRUCK PROBLEM

    if (time == [environment getEpochCount])
      nyd_sm_collision_count = 0;

    fprintf(out, "\nCollision count: %d\nTrial Collision count: %d timestep: %d\n",
	    nyd_sm_collision_count, 
	   nyd_sm_collision_count - last_trial_collision_sum,
	   time);
  }

  return self;
}

- (char) nameForPerception: (int) percept
{

  switch (percept) {
  case 0:
    return 'R';
  case 1:
    return 'G';
  case 2:
    return 'B';
  case 3:
    return 'M';
  case 4:
    return 'W';
  case 5:
    return 'Y';
  case 6:
    return 'E';
  default:
    return 'U';
  }
}

-buildObjects
{
  return self;
}

-setAgentModel: (id) aModel 
{
  agentModel = aModel;
  return self;
}

-(int) getCollisionCount {
  return nyd_sm_collision_count;
}

-setEnvironment: (id) anEnv 
{
  environment = anEnv;
  return self;
}

@end






