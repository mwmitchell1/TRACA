// Agent application. Copyright (C) 1996 Matthew Mitchell.
#include <strings.h>

#import <objectbase.h>
#import <analysis.h>
#import "AgentBatchSwarm.h"

// Constants that can be loaded from file or used with default values 

// include the agent model
#import "AgentModelSwarm.h"
#import "EnvironmentSwarm.h"

@implementation AgentBatchSwarm

// createBegin: here we set up the default observation parameters.

+createBegin: (id) aZone {
  AgentBatchSwarm * obj;
  
  // Superclass createBegin to allocate ourselves.
  obj = [super createBegin: aZone];

  // Fill in the relevant parameters (only one, in this case).

  obj->effectorCount=4;  // using gaze back
  obj->detectorCount=20;
  obj->timeSeedRandom=0;
  obj->classify = 0;
  obj->maze = 0;
  obj->epochCount = 0;
  obj->reset = False;
  obj->runCount = [String create: aZone];
  
  // Also, build a customized probe map. Without a probe map, the default
  // is to show all variables and messages. Here we choose to
  // customize the appearance of the probe, give a nicer interface.

  return obj;
}


-createEnd {
  return [super createEnd];
}


-buildObjects {
  id <Zone> modelZone;					  // zone for model.
  id <Zone> worldZone;

  [super buildObjects];

  // First, we create the model that we're actually observing. The
  // model is a subswarm of the observer. We also create the model in
  // its own zone, so storage is segregated.

  modelZone = [Zone create: [self getZone]];
  agentModelSwarm = [AgentModelSwarm create: modelZone];
  [agentModelSwarm setDetectorCount: detectorCount];
  [agentModelSwarm setEffectorCount: effectorCount];
  [agentModelSwarm setObserver: self];

  worldZone = [Zone create: [self getZone]];

  environmentSwarm = [EnvironmentSwarm create: worldZone];
  [environmentSwarm setString: "1111100000"];
  [environmentSwarm setAgent: agentModelSwarm];

  [agentModelSwarm setDetectorCount: detectorCount];
  [agentModelSwarm setEffectorCount: effectorCount];

  // First, let the model swarm build its objects.
  [agentModelSwarm buildObjects];

  [(EnvironmentSwarm *) 
    environmentSwarm setProblem: problemFileName epochs: epochCount];

  [environmentSwarm buildObjects];

// Seed the random generator, if this is False, seed from the following,
// otherwise, seed from time.

   if (timeSeedRandom == False)
   {
      printf(",\n Random Seed:, %d:", (seed + 1));
     [randomGenerator setStateFromSeed: (seed + 1)];               
   }

  fflush(stdout);

  return self;
}

-setProblem: (char *) problemString epochs: (char *) epochString run: (char *) runString seed: (char *) seedString
{
     problemFileName = problemString;
     //     fprintf(stderr, "\n Problem: %s", problemString); 
     // fprintf(stderr, "\n Epoch: %s", epochString); 
     epochCount = atoi(epochString);

     seed = atoi(seedString);
     // fprintf(stderr,"random seed: %d", seed); 

     [runCount setC: runString];
     // printf(stderr, "\n Run: %s", runString); 
     // fflush(stderr);  
     return self;
}

-buildActions {
 [super buildActions];
  
  [agentModelSwarm buildActions];
  
   modelActions = [ActionGroup create: [self getZone]];

  if (classify)
  { 
    printf("\n Classifying---");

//    [modelActions createActionTo: self              message: M(checkToStop)];
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
  } 
  else
  {
    //    [modelActions createActionTo: self              message: M(checkToStop)];
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
  }

  // And the display schedule. 

  modelSchedule = [Schedule createBegin: [self getZone]];
  [modelSchedule setRepeatInterval: 1]; 
  modelSchedule = [modelSchedule createEnd];
  [modelSchedule at: 0 createAction: modelActions];

  
  return self;
}  


-resetAgentPosition
{
   reset = False;
   [environmentSwarm resetAgentPosition];
   return self;
}

-timeOut
{
    [environmentSwarm timeOut];
    [self stop];
    return self;
}

-setReset: (boolean) aBoolean
{
     reset = aBoolean;
     return self;
}

-(boolean) getClassify
{
  return classify;
}

-(boolean) getMaze
{
  return maze;
}

-(boolean) getReset
{
      return reset;
}


-go 
{
//  printf("Running in batch.\n");
  [[self getActivity] run];
  return [[self getActivity] getStatus];
}

-stop 
{

  [getTopLevelActivity() terminate];
   return self;
}

// activateIn: - activate the schedules so they're ready to run.

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  [modelSchedule activateIn: self];
  
  return [self getSwarmActivity];
}
@end




