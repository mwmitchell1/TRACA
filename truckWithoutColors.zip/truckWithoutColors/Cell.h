#import "EnvironmentSwarm.h"
#import <objectbase/SwarmObject.h>

@interface Cell : SwarmObject
{
   int color, previousColor;
   id <Grid2d> grid;
   int x, y;
   id worldModel;
   id <Raster> raster;
}

+createBegin: aZone;
-setGrid: (id) aGrid;
-setX: (int) newX Y: (int) newY;
-setCellColor: (int) aColor;
-(void)resetColor;
-setModel: (id) aModel;
-setRaster: (id) aRaster;
-getRaster;
-createEnd;
-buildObjects;
-drawSelfOn: aRaster;
@end
