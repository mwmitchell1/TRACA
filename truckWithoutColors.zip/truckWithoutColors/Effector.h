#import <objectbase.h>				  // we inherit swarm objects
#import <objectbase/SwarmObject.h>
#import <space.h>				  // we use Space features
#import <gui.h>			  // special class for graphics
#import "Node.h"
#import "boolean.h"

@interface Effector : SwarmObject
{
	double support;
        double perfect;
        double effectiveSupport;

  // These are used in adjusting the support to allow for 
  // predictive strength of nodes. 
 
        double predictiveSupport;
        int predictiveSupporterCount;
         
  // This is temporary value used during the selection.

        double cumulativeSupport; 

	int negativeSupporterCount;
	int positiveSupporterCount;
	float negativeSupport;
	float positiveSupport;
	float proportion;
      
	boolean supported;
        id agentModel;
 	id supporterList;
	id <Grid2d> grid;
	int x, y, color, position;
        boolean selected;
	id highestSupporter;
	id highestNegativeSupporter;

}

+createBegin: (id) aZone;
-(boolean) setX: (int) newX Y: (int) newY;
-setGrid: (id) aGrid;
-setPosition: (int) aPosition;
-setAgentModel: (id) aModel;
-createEnd;
-buildObjects;
-reset;
-addStrengthSupport: (double) aNumber;
-addPredictiveSupport: (double) aNumber node: (id) aNode;
-calculateEffectiveSupport;
-(void) setSupport: (double) aNumber;
-setCumulativeSupport: (double *) supportSum;
-checkCumulativeSupport;
-selectBestPredictiveEffector: (id) anId max: (double *) max;
-selectBestRewardEffector: (id) anId max: (double *) max;
-(void) setSupported: (boolean) aBoolean;
-(int) getPosition;
-(void) setSelected: (boolean) aBoolean;
-(void) incrementSupport: (double) aNumber;
-(boolean) addSupporter: (Node *) aNode;
-(boolean) removeSupporter: (Node *) aNode;
-(double) getSupport;
-calculateSum: (double *) supportSum;
-calculateProportion: (double *) supportSum;
-(float) getEffectiveSupport;
-(double) getAbs: (double) aDouble;
-(boolean) getSupported;
-(boolean) getSelected;
-(id <Grid2d>) getGrid;
-drawSelfOn: (id <Raster>) aRaster;
-(float) getSortStrength;
-printOn;
-printTrack;
@end



