#import "PredictorNode.h"
#import "AgentModelSwarm.h"
#import "NodeGroup.h"
#import "NaryNode.h"
#import "Trend.h"

// variables included in Constants.h

@implementation PredictorNode

+createBegin: (id) aZone
{

// Predictive strength is used in bidding, it starts off high to allow nodes
// to get tested, however, predicitive history is used to determine how the
// node has been going so far, it starts at 0.  Suspended nodes keep testing
// this until they find their predictive strength is greater than one of their
// inputs, in this case they can start to create owners of their own.
// a Node which has a suspended owner will not accept any more owners until 
// it is active.  If the predicitive strength falls below the predicitive 
// strength of the owned node it is removed and deleted.

  PredictorNode * obj;
 
  obj =  [super createBegin: aZone];
  
  // This used to be until 21/8/99 - 0.2
  // Note: the following should NEVER be zero. 
  obj->dependentAccuracy=1.0;
  obj->independentAccuracy=1.0;
  obj->timeComparison = -1.0;
  obj->temporalTimeComparison = 0.0;

  obj->higherValue = False;

  obj->independentValue = 0.0;
  obj->dependentValue = 0.0;
  obj->hypDependentValue = 0.0;
  obj->incorrectOnce = False;
  obj->lastCorrect = False;
  obj->correct = False;
  obj->fired=False;
  obj->hypFired=False;
  obj->suspended=True;
  obj->nodeGroup=nil;
  obj->activationCount = 0;
  obj->receivedReward = 0;
  obj->ownActivationCount = 0;
  obj->lifetimeCount = 0;
  obj->firedCount=0;
  obj->predictionActiveCount = 0;
  obj->correctCount = 0;
  obj->ownCorrectCount = 0;
  obj->steadyState = False;        
  obj->lastPayment = 0;
  obj->sentSupport = False;
  obj->thresholdCount = 0;    
  obj->latestActivationCount = 0;
  obj->latestCorrectCount = 0;
  obj->totalCorrectCount = 0;
  obj->totalActivationCount = 0;
  obj->reward=0;
  obj->temporallySuspended = False;
  obj->inhibited = False;
  obj->lastInhibited = False;
  
// Family is not used except for unary nodes. It is here only to
  // be referenced for Unary nodes.
  
  obj->family = 0;

  return obj;
}

-createEnd
{
  return [super createEnd];
}

-buildObjects
{
  [super buildObjects];
  
  // June 4 2001 - added following

  trend = [Trend createBegin: [self getZone]];
  [trend setAgentModel: agentModel];

  // May 30 2002 changed temporal to terminal

  if ([self respondsTo: M(isTerminal)])
    [trend setMaxObservations: ([agentModel getTemporalCoxStuartCaseCount])];
  else
    [trend setMaxObservations: [agentModel getCoxStuartCaseCount]];

  [trend setSignificance: [agentModel getCoxStuartSignificance]];
  trend = [trend createEnd];
  [trend buildObjects];

  // Added Sep 19 2001 

  trendForThis = [Trend createBegin: [self getZone]];
  [trendForThis setAgentModel: agentModel];

  // May 30 2002 changed temporal to terminal

  // August 13 - replaced activationThreshold with coxStuartCaseCount
  if ([self respondsTo: M(isTerminal)])
    [trendForThis setMaxObservations: 
		    ([agentModel getTemporalCoxStuartCaseCount])];
  else
    [trendForThis setMaxObservations: 
		    ([agentModel getCoxStuartCaseCount])];

  [trendForThis setSignificance: [agentModel getCoxStuartSignificance]];
  trendForThis = [trendForThis createEnd];
  [trendForThis buildObjects];
  [trendForThis calculateMiddle]; 
  // [trendForThis printOn];
  return self;
}

-lookahead
{
  if ([agentModel getDebug])
    printf("\n Hyp lookahead for node: %ld", nodeNumber);
  
  if (matched && ![self getActiveSupressed])
    {
      [prediction hypActivePredictedBy: self];
    }
  return self;
}

-preFire
{

  if ([agentModel getDebug])
    printf("\n Node %ld Group: %ld received preFire - realActive: %d",
	   nodeNumber, [nodeGroup getNodeNumber], realActive);
  
  if ([self getRealActive])
    {
      
      // Tell the node group you are sending support so it knows whether
      // or not to check later that one node actually supported the chosen 
      // effector
      
      [nodeGroup setPreFired: True];
      
      // If you have fired,supress your on inputs so you can be identified 
      // as the highest node which has fired. The supress inputs message is 
      // is passed down to the level of unary nodes
      
      // If you don't want to supress nodes who have subordinated owners,
      // at least make them have a suspended prediction.
      // Note: that the fireUnlessOwnersActive flag is on. so they can make
      // active predictions

      if ([self getSuspended])  
	predictionType = suspendedType;  // defined in .def file
      else
	predictionType = activeType;     // defined in .def file
    }

  return self;
}

// while the above prevents predicted nodes making connections usign their 
// predictors, the following two affect which nodes are copied for the 
// initial predictors.  Note: that the above is done after an action
// has been selected while, these are done after matching is complete
 

-checkUpdateTemporalSupress
{
// does nothing, only temporal nodes connectTemporalSupress
  
   return self;
}
    
-addToExtendList: (id) extendList
{
  // This creates a list of nodes which were previous predictors
  // however, it excludes nodes which are not eligible
  // for use to extend or create temporal chains.  In particular
  // we only use nodes which made active predictions 
  // (i.e were not supressed at all when they fired).
  
  if ([agentModel getDebug])
    fprintf(stdout,"\n adding node %ld to extendlist group: %ld \npredicitonType: %d,\n suspended: %d, fired: %d, correct: %d, altAcc: %f",
	    nodeNumber, [[self getGroup] getNodeNumber], predictionType, 
	    suspended, fired, correct, independentValue);

	// Oct 14 2002 - removed this line - need to extend to terminal nodes!
	// since their inputs are activesuppressed and not included in 
	// extendList
	// ![self respondsTo: M(isTerminal)] &&
  if  (((nodeGroup != nil) 
       && fired
       && correct)
    || ([self respondsTo: M(isTerminal)]
	// Oct 24 2002 - changed to fired rather than group getFired:
	&& fired
	&& [[(TerminalNode *) self getTopGroup] getFinalGroup]
	  // OCt 24 2002 - changed following line to test if
	// first terminal node correct rather than first temporal node:  
	&& [[[(TerminalNode *) self getGroup] getFirstNode] getCorrect]))
    // Oct 2 2002 - removed to allow all nodes to be added:
    //  && ![nodeGroup getAdded]) 
    // This means we can only select one action
    // August 15 2002 - changed > to >=
    if (independentValue >= [agentModel getTemporalExtendAccuracy]) {
      if ([agentModel getDebug])
	fprintf(stdout, "\n added node %ld to extendList", nodeNumber);
      [extendList addLast: self];
    // Oct 2 2002 - removed to allow all nodes to be added:
    //  [nodeGroup setAdded: True]; // only add one node from each group
    }

  return self;
}

-fire
{
  // Actually fire.  In this case if nodes with active or suspended owners
  // are supressed, their active predictions are converted to passive
  // to prevent the possibility of recreating existing connections

  // Proxy nodes don't have an effector
  if (supported == nil)
    return self;

  if (([supported getSelected]) && ([self getRealActive]))
    {
      
      // Once a terminal node's action is selected, it must notify the other
      // groups (nodes) in the chain, so they can make predictions and be  
      // notified if they are correct or not. 
      
      firedCount++;
      [(NodeGroup *) nodeGroup setFired: True];
      if ([agentModel getDebug])
      //f ([[self getGroup] getNodeNumber] == 1291)
	{ 
	  printf("\n firing node: %ld time: %ld", nodeNumber, 
		 getCurrentTime());
	  printf("\nFiring node %ld, group: %ld, effector %d, realActive %d, \n prediction %ld, \n Suspended %d, sus own count: %d, temporallySuspended: %d", 
		 nodeNumber, [nodeGroup getNodeNumber],
		 [supported getPosition], [self getRealActive], 
		 [prediction getNodeNumber], [self getSuspended],
		 [[self getSuspendedOwnerList] getCount],
		 [self getTemporallySuspended]);
      }      
      fired = True;

      // Dec 19 2000 - notify prediction if predicted by finalised
      // chain.
      if ([self respondsTo: M(isTerminal)]) {
	if ([[[self getGroup] getTopGroup] getFinalGroup])
	  // ASSUMES THIS CAN ONLY HAPPEN ONCE PER CYCLE
	  [prediction setPredictedByFinalisedChain: True];
	else 
	  [prediction incrementPredictedByNonFinalisedChain];
      }
    }
    
  if (fired)
    {   
      // Apr 17 2001 - added suspended for Node:connectAnd
      // June 18 2002 - use narySupress instead of supress
      // suspendedpredictorlist includes suspended
      // because we use that list to copypredictors

      if (suspended)  
	predictionType = suspendedType;

      // if !narySupressed, allow to be used in 
      // new creates even if active supressed
      // nodes under temporal or terminal groups 
      // will always be narySupressed

      if ([self getNarySupressed]) {
	predictionType = suspendedType;
      }

      if (lastActiveSupressed) {
	predictionType = passiveType; 
	if ([agentModel getDebug])  
	  printf("\n node %ld active supressed", nodeNumber);
	}
      
      if ([agentModel getDebug])  
	switch (predictionType)
          {
	  case activeType:
	    printf("\t Active Prediction"); 
	    break;
	  case passiveType:
	    printf("\t Passive Prediction");               
	    break;
	  case suspendedType:
	    printf("\t Suspended prediction");  
	    break;
	  case connectType:
	    printf("\t Connect prediction");  
	    break;
	  case inhibitedType:
	    printf("\t Inhibited prediction");  
	    break;
	  }
      
      // Add suspended and active predictors to predictorList
      
      switch (predictionType)
	{
        case activeType:
	  [prediction activePredictedBy: self]; 
	  break;
        case suspendedType:
	  [prediction suspendedPredictedBy: self];      
	  break;
        case passiveType:
	  [prediction passivePredictedBy: self];            
	  break;
        case connectType:
	  [prediction suspendedPredictedBy: self];      
	  break;
        case inhibitedType:
	  [prediction suspendedPredictedBy: self];      
	  break;
        default:
	  printf("\n WARNING: No prediction type for node");
	}
    }

  // May 2 2002 - for efficiency to prevent groups creating join groups
  // when accurately predicted

  if (![self respondsTo: M(isTerminal)]
      && ![self respondsTo: M(isTemporal)]
      && (predictionType == activeType) 
      && [self getPerformingAtBest])
    [prediction setAccuratelyPredictedOk: True];

  if ([self respondsTo: M(isTerminal)]  
      && !(predictionType == passiveType) 
      && [self getPerformingAtBest])
    [prediction setAccuratelyTemporallyPredictedOk: True];

  return self;
}


// Add your payment received from what you predicted to your strength

-pay: (double *)  paymentPtr
{
   
  //  Note: if this node is part of a node group, the payments received
  //  are distributed across all nodes based on their predictive strength
  //  The payments are distributed becauseall the nodes have the same inputs
  //  and support the same effector, therefore they all contribute to the 
  //  subsequent state.  However, the predictive strength is included
  //  so that the strength of nodes reflects their accuracy. 
  
  // discount the amount you receive by your predictive strength
  
  if([agentModel getLearning]) {
    
    // Need to set a flag, as NodeGroups which are activeTemporallySupressed
    // may also send rewards, they shouldn't but its too hard to stop them
    // as they should unless they are active supressed by the finalGroup.
    if (receivedReward)
      return self;
    
    receivedReward = True;
    
    // May 3 2000 - Most rewards are sent by predictions, except
    // terminal nodes which are sent by temporal group. 
    // So we must check if the prediction was matched (ie. this node
    // is correct. If not leave the reward at zero.
    
    // Mar 14 2002 - removed following to allow updates
    // with rewards each timestep regardless of correctness,
    // I am not sure of the implications of this for terminal
    // nodes which are payed by higher temporal chains.

    // April 4 removed following lines
 
    //    if ([self respondsTo: M(isTerminal)] && ![self getCorrect])
    //  return self;

    if ([agentModel getDebug])
	fprintf(stdout,"\n in Predictor:-pay, for node: %ld, sentSupport: %d,\n effector selected: %d, correct: %d, isCorrect: %d",
		nodeNumber, sentSupport,
                ([agentModel getSelectedEffector] == supported),
		correct, [self respondsTo: M(isCorrect)]);
    
    
    if (sentSupport &&
	([agentModel getSelectedEffector] == supported))
      {
	if ([agentModel getDebug])
	 fprintf(stdout,"\n in Predictor:-pay, for node: %ld, sentSupport: %d",
		 nodeNumber, sentSupport);
      
	if (![agentModel getClassify]) {  
	  reward = *paymentPtr;
	  rewardStrength = reward;
	}
	else 
	  if ([agentModel getClassify]) {
	    //  printf("\n WARNING correctCount zero in PNode::pay");
	    reward = *paymentPtr;
	    // Dec 7 added following
	    rewardStrength = reward;
	    if ([agentModel getDebug])  
	      if (*paymentPtr != 0)
		if ([agentModel getDebug])
		  printf("\n node %ld setting averageStrength: to :%f, \n paymentPtr: %f correct count: %ld", 
			 nodeNumber, averageStrength, *paymentPtr, 
			 correctCount);
	  }	
      }
  }
  
  return self;
}


// Feb 28 2001 - Overridden in temporal node
// as temporal nodes may send support a long time before their
// terminal nodes pay them
   
-payReturn: (double *)  paymentPtr
{
   
  // Note: if this node is part of a node group, the payments received
  // are distributed across all nodes based on their predictive strength
  // The payments are distributed becauseall the nodes have the same inputs
  // and support the same effector, therefore they all contribute to the 
  // subsequent state.  However, the predictive strength is included
  // so that the strength of nodes reflects their accuracy. 
  
  // discount the amount you receive by your predictive strength
 
  if([agentModel getLearning])
    {
      if ([agentModel getDebug])
	printf("\n %ld sent support: %d", nodeNumber, sentSupport);
      if (sentSupport)
	{
	  Qreturn = *paymentPtr;
	  if ([agentModel getDebug])
            printf("\n Qreturn received by: %ld is: %f", nodeNumber, Qreturn);
	}
    }
  
  return self;
}


-hypPayReturn: (double *)  paymentPtr
{
   
  //  Note: if this node is part of a node group, the payments received
  //  are distributed across all nodes based on their predictive strength
  //  The payments are distributed becauseall the nodes have the same inputs
  //  and support the same effector, therefore they all contribute to the 
  //  subsequent state.  However, the predictive strength is included
  //  so that the strength of nodes reflects their accuracy. 
  
  // discount the amount you receive by your predictive strength
  
  if([agentModel getLearning])
    {
      // may want to allow hyp nodes to pay themselves
      if (([self getHypMatched] && !hypLastActiveSupressed))
	{
	  hypQreturn = *paymentPtr;
	}
    }
  
  return self;
}


-updateValueEstimate
{

  double tempReturn = 0;
  double newValue = 0;
  double temp = 0;
  double updateValue = 0;

  // Correct is slightly diff for temporal nodes, they are correct if the 
  // chain was followed to completion,(but must still be told this
  // and are when the next node in the chain has its input matched)
  // the fact that it might not is reflected in their ownActivationCount.
  // Temporal nodes won't be supressed.
  
  if ([agentModel getDebug]) 
      printf("\n Update value estimate for node: %ld, sentSuport: %d, selected: %d, correct: %d", 
	       nodeNumber, sentSupport,
	    ([agentModel getSelectedEffector] == supported), correct);

  // Aug 15 2002
  // Don't update estimates if you are matched again!!

  // Aug 15 2002 - don't update value estimate for 
  // nodes when they are matched after firing!
  // Possibly we could allow nodes which predict themselves tp
  // continue into update here:


  /* Aug 20 20002 - to prevent incorrect independent value
   */
  //  if (matched && (prediction != [self getGroup]))
  //  return self;

  if (sentSupport && 
      [agentModel getLearning] &&
      ([agentModel getSelectedEffector] == supported))
    {

     // Nov 23 2000 - if you are a terminal node and the first node in
     // your group, and your prediction is not matched, and you have
     // a higher level temporal node above you, use the same return 
     // received by the temporal node to update yourself.  This is
     // because, there is another chain extending you which you can never
     // predict and therefore never record the additional returns from 
     // ( for example: if a random action is taken while following 
     // this lower chain.

      // Apr 17 2001 
     if ([self respondsTo: M(isTerminal)] 
	 && ([[self getGroup] getFirstNode] == self)
	 && ((![prediction respondsTo: M(isTemporal)] 
	      && ![[self getPrediction] getMatched])
	     || ([prediction respondsTo: M(isTemporal)] 
		 && [[self getPrediction] getFirstInputMatchedNow])))
       {
	 tempReturn = [[self getGroup] getTemporalOwnerReturn];
	 if (tempReturn > Qreturn)
	   Qreturn = tempReturn;
       }
     /*
    if (nodeNumber == 1039)
	printf("\n Node 1039 updating value: %f with reward: %f q: %f time: %d", dependentValue, [agentModel getReward], Qreturn, getCurrentTime());
     */


     // April 10 2002 - always get return from agentModel
     // as some groups do not pay if active supressed.

     // April 15 2002 - changed following:

     // Dec 4 2002 - 


     // Feb 15 2003
     // 2019 - Something wrong here - value should not be zero
     Qreturn = [agentModel getQreturn];
      if ([agentModel getDebug])
       printf("Agent model Qreturn: %lf", Qreturn);

     // April 14 2002 - trying the following:
     //     if (!correct)
     //  Qreturn = 0;

     // May 24 2002 - this does not work for 
     // orientation tasks

     // Feb 15 2003
     if (prediction == [self getGroup])
       Qreturn = 0;

     // August 20 2002
     //     if (matched)
     // Nov 1 2002 - removed line above:
     //   Qreturn = 0;

     if ([agentModel getFiniteProblem] && [agentModel getEndOfTrial])
      	Qreturn = 0;

     //     if (correct)
       rewardStrength = [agentModel getReward];
       // else
       //  rewardStrength = 0;


      // July 13 2000 - The following are used to 
      // determine if the node is receiving
      // consistently, its max return, in which case it will not allow any 
      // owners to form.
      if ([self getAbs: Qreturn] > [self getAbs: maxQreturn])
	maxQreturn = Qreturn;

      //     if ([self getAbs: rewardStrength] > [self getAbs: maxReward])
      //maxReward = rewardStrength;

      maxReward = maxReward + [agentModel getLearningRate] *
	([agentModel getReward] - maxReward);

      if ([agentModel getDebug])
	printf("\n Group %ld Node %ld average reward: %f", 
	       [[self getGroup] getNodeNumber],
	       nodeNumber, maxReward);


      //if (([agentModel getDebug] && [self respondsTo: M(isTerminal)]))

      /*      
      if ([self getNodeNumber] == 1984)
	printf("\n Node %ld updating value with qReturn: %f to: %f, reward: %f time: %ld",
	       nodeNumber, Qreturn, dependentValue, rewardStrength, 
	       getCurrentTime());
      */

      // Feb 10 2000
      
      // Now, dependentValue is used to send predictive support and calculate
      // Q return to previous nodes. independentValue is used to compare 
      // higher nodes to lower nodes. independentValue is updated every time
      // the node is activated, dependentValue takes into account active
      // supressions
    
	if (!lastActiveSupressed 
	    && !lastActiveTemporallySupressed
	    && ![self getUpdateTemporalSupressed])
	  //	    && !Qreturn == -9999.0) // no group sent a return! 
	  {
	    dependentValue = // (1.0 - [self getAlpha]) *
	      dependentValue + 
	      [self getAlpha] *
	      ((rewardStrength + 
	       ([agentModel getDiscountRate] * Qreturn)) - dependentValue);
	    
	    if ([agentModel getDebug])
	      printf("\n Node: %ld, indepValue: %f, correctCount: %ld \ntempS: %f  rewardStrength: %f, Qreturn: %f, \n depAccuracy: %f",
		     nodeNumber, independentValue, correctCount, 
		     dependentValue,
		     rewardStrength, Qreturn, dependentAccuracy);
	  } 

      // May 9 2001 - The following code is the smoothing code

      if (correct)
	temp = 1.0;
      else
	temp = 0.0;
      updateValue = temp;
 
      //just comment out next bit if any problems
      // June 5 2001 - changed ownActivationCount to correctCount
      
      //      if ([(NaryNode *) self getImproved] 
      //	  || ([self respondsTo: M(isUnary)]
      //	      && (correctCount >= 20)))
      //		  // [agentModel getActivationThreshold])))    


      newValue = independentValue;

      /*
      //      if ([agentModel getUseAverageForReward]) 
      //	{
	  newValue = newValue + 
	    ((1.0 / (1.0 + (double) activationCount) *

     //	      ((rewardStrength + ([agentModel getDiscountRate] * Qreturn))
	      (temp - newValue)));
	  
	}
      else 
	{
      */
	  newValue = newValue + 
	    ([agentModel getLearningRate] *
	     (updateValue - newValue));
	  //	} 
	  

	// leave this here - there was a bug in swarm which resulted in
	// incorrect values.

      independentValue = newValue;
      
      // Sept 25 2000 - compare nbr times this has higher value
      // than inputs.
         if ([agentModel getDebug]) // || (nodeNumber == 460))
	printf("\n Node: %ld, indepValue: %f, ownActivationCount: %ld depV: %f\n rewardStrength: %f, Qreturn: %f, altAccurcy: %f",
	       nodeNumber, independentValue, ownActivationCount, dependentValue,
	       rewardStrength, Qreturn, dependentAccuracy);

      // Sep 19 2001 TrendForThis is always updated

      [trendForThis addObservation: independentValue];

      // Mar 5 2002 - only first node to reach higher value (with trend)
      // can be an improved node. 

      if ([self respondsTo: M(isNary)]
	  && ![(NaryNode *) self compareInputs])
	  //	  && [(NaryNode *) self getActivated])
	// && suspended)
	{
	  [nodeGroup setHigherValue: True];
	  higherValue = True;
	}

      // Oct 2 2002 - added following to prevent removal of terminal
      // (and other superior groups) once improved.  Since they
      // will drive behaviour, thier subordiante values will rise.
      // Therefore subordinates have to actually improve on their superiors
      // by a small amount to change that superior to not improved.
      // reuires isImproved method in NaryNode.m

      if (higherValue) {
	if (![self respondsTo: M(isTerminal)]) {
	  if (([(NaryNode *) self getFirstSimilarInput] != nil)
	      && ([(NaryNode *) self getSecondSimilarInput] != nil)) {

	    if ([(NaryNode *) self isImproved]) {
	      [trend addInputObservation: 
		       ([(NaryNode *) self getHighestSimilarInputValue])];
	      //	 [(NaryNode *) self getImprovementFactor])];
	      [trend addObservation: independentValue];
	    }
	    else {
	      [trend addInputObservation: 
		       [(NaryNode *) self getHighestSimilarInputValue]];
	      [trend addObservation: (independentValue 
		            * [(NaryNode *) self getImprovementFactor])]; 
	    }
	  }
	} else {
	  // June 12 2002 - added following:`
	  if ([(NaryNode *) self getFirstSimilarInput] != nil) {
	    if ([(NaryNode *) self isImproved]) {
	      [trend addInputObservation: 
		       ([[(NaryNode *) self getFirstSimilarInput] 
			  getCompareValue])];
	      // * [self getTerminalImprovementFactor])];
	      [trend addObservation: independentValue];
	    }
	    else {
	      [trend addInputObservation: 
		       [[(NaryNode *) self getFirstSimilarInput] 
			 getCompareValue]];
	      [trend addObservation: (independentValue 
				      * [self getTerminalImprovementFactor])]; 
	    }
	  }
	}
      }
      
      if ([agentModel getDebug]) {
	printf("\n finished update");
      }
      
    }

  rewardStrength = 0;
  Qreturn = 0;
  reward = 0;
  
  return self;
}

-(double) getTerminalImprovementFactor 
{
  return 1.0 - [agentModel getTerminalImprovementFactor];
}

-(double) getAlpha {
  return [agentModel getLearningRate];
  //  return (1.0 / (1.0 + (double) ownActivationCount));
}

// Place holder only - Overrriden in NaryNode and TerminalNode
-(boolean) compareInputs
{
  return False;
}


-(double) getQreturn 
{
  return Qreturn;
}

-(double) getAbs: (double) aDouble
{
  if (aDouble < 0)
    return aDouble * -1;
  return aDouble;
}

- (boolean) getPerformingAtBest
{

  /* Apr 17 2001 Here is where getPerformanceFactor should be called
   */   
  if (!suspended && (dependentValue == 1.0))
    return True;
   
  return False;
}


-hypUpdateValueEstimate
{
  // nothing yet.

  return self;
}


// April 11 2002 - same conditions as below, but now we just send
// the support of one node rather than all when not doing lookahead.

-sendFrequency {

  double adjustedPSupport = 0;

  if (removed)
    return self;

  if (supported == nil)
    return self;

  if ([agentModel getDebug])
    printf("\n Node sendFrequency: %ld, group: %ld realActive: %d", nodeNumber,
	   [[self getGroup] getNodeNumber], [self getRealActive]);

  if ([self respondsTo: M(isTerminal)]
      && (![[(TerminalGroup *) [self getGroup] getTopGroup] getFinalGroup]))
    return self;

  // Dec 4:

  //  if (activationCount < [agentModel getActivationThreshold])
  //  return self;

  if ([self getRealActive])
    {
       sentSupport = True;  

       adjustedPSupport = dependentValue;
   
       if ((suspended && ![self respondsTo: M(isUnary)])
	  || [self getActiveSupressed]
	  ||  [self getActiveTemporallySupressed])
	return self;  

       // Dec 4:
       //      if (adjustedPSupport != 0.0)
	{
	  if (![agentModel getSeekReward] && (adjustedPSupport > 0))
	    return self;
	  [nodeGroup setFrequencyFrom: self];  
	}
    }
   return self;
}

-sendActivePredictiveSupport
{
  
  double adjustedPSupport=0;

  // In this case the predictive strength is used to influence the systems
  // exploration rate.  This is determined by an exploration rate.  
  // A higher exploration rate will lead to more exploration over exploitation
  
  // All nodes which fired set the flag sentSupport, so they all
  // update their value estimates and counters after firing. For nodes
  // under temporal nodes this means they keep an accurate record
  // should the chain be removed, for general nodes it means
  // they reflect the general likelyhood of the subsequent return/state.
  // For supressed and temporallySuspended nodes though, they do not actually
  // send support to effectors.

  // NOTE: overridden in TemporalNode.m

  // May 6 2002 
  //  if (prediction == [self getGroup])
  //    return;

  if (supported == nil)
    return self;

  if ([self getRealActive])
    {
      sentSupport = True;  
       
      // May 8 2002 - if a terminal node in an unfinished chain
      // there will be only one node, this node
      // should use its predictions interest to modify its
      // support to ensure chain is followed. 
      
      if ([self respondsTo: M(isTerminal)]
        && (![[(TerminalGroup *) [self getGroup] getTopGroup] getFinalGroup]))
	return self;

      adjustedPSupport = dependentValue;

      if (![agentModel getSeekReward] && (adjustedPSupport > 0))
	return self;

      if ((suspended && ![self respondsTo: M(isUnary)])
	  || [self getActiveSupressed]
	  ||  [self getActiveTemporallySupressed])
	return self;  

      // June 6 2002 - dont' send support unless enough observations
      // *at least if temporal or terminal*

      /* June 12 2002 - remove
       
      if (ownActivationCount < [agentModel getActivationThreshold])
	return self;
      */

      //       if (adjustedPSupport != 0.0)
      //	 {
	   
	   // April 11 2002 - only one node sends support
	
	   //	   if ((dependentValue - [agentModel getVariance]) > 0) {
	   // Dec 4:
	   if ([nodeGroup getMostFrequentPositive: self] == self) {
	     if ([agentModel getDebug] || ([agentModel getTrackRules]
					   && [agentModel getTrackActions])){
	       if ([self respondsTo: M(isTerminal)])
		 printf("\n Terminal node number %ld Group: %ld Effector: %d\n \t sending support: %f, depVal: %f",
			nodeNumber, [nodeGroup getNodeNumber], 
			[supported getPosition], 
			adjustedPSupport, dependentValue);
	       
	       else
		 printf("\n Node number %ld Group: %ld Effector: %d\n \t sending support: %f, depVal: %f",
			nodeNumber, [nodeGroup getNodeNumber], 
			[supported getPosition], 
			adjustedPSupport, dependentValue);
	       }
	     
	     [supported addPredictiveSupport: adjustedPSupport node: self];
	     [nodeGroup setMostFrequentPositive: self to: nil];
	   } else
	     if ((dependentValue + [agentModel getVariance]) < 0) {
	       if ([nodeGroup getMostFrequentNegative: self] == self) {
		 if ([agentModel getDebug] 
		     || ([agentModel getTrackRules]
			 && [agentModel getTrackActions])) {
		   if ([self respondsTo: M(isTerminal)])
		     printf("\n Terminal node number %ld Group: %ld Effector: %d\n \t sending support: %f, depVal: %f",
			    nodeNumber, [nodeGroup getNodeNumber], 
			    [supported getPosition], 
			    adjustedPSupport, dependentValue);
		 
		   else
		     printf("\n Node number %ld Group: %ld Effector: %d\n\t sending support: %f, depVal: %f",
			    nodeNumber, [nodeGroup getNodeNumber], 
		    [supported getPosition], adjustedPSupport, dependentValue);
		 }

		 [supported addPredictiveSupport: 
			      adjustedPSupport node: self];
		 [nodeGroup setMostFrequentNegative: self to: nil];
	       } 
	     }
	  
	   // }
    }

   return self;
}


-active
{
  // this message is sent if the node's prediction was active.
  // if the node fired, it can ignore this message, otherwise
  // it should check that its effector was selected, to determine
  // its correlation to its prediction
  
  if (fired) 
    return self;
  predictionActiveCount++; 

  return self;
}


-correct
{
  // update predictive strength 

  if ([agentModel getLearning]) 
    { 
      // May 26 2000 - check if fired
      if (!fired || ([agentModel getSelectedEffector] != supported))
	return self;
   
      if ([self respondsTo: M(isTerminal)] && [agentModel getDebug])
	fprintf(stdout, "\n Terminal Node: %ld incrementing \n activation count in correct", nodeNumber);
      
      if (!lastActiveSupressed 
	  && !lastActiveTemporallySupressed
	  && ![self getUpdateTemporalSupressed]) 
	{
	  ownCorrectCount++;
	  ownActivationCount++;
	  if ([agentModel getLearningRate] == 0 || 
	      [agentModel getUseAverageForAccuracy])
	    dependentAccuracy =  dependentAccuracy + 
	      (((double) 1/((double) ownActivationCount + 1)) *
	       ((double) 1 - dependentAccuracy));
	  else
	    dependentAccuracy =  dependentAccuracy + 
	      ([agentModel getLearningRate] *
	       ((double) 1 - dependentAccuracy));
	}

      if ([agentModel getLearningRate] == 0 || 
	  [agentModel getUseAverageForAccuracy]) 
	independentAccuracy =  independentAccuracy + 
	  (((double) 1/((double) activationCount + 1)) *
	   ((double) 1 - independentAccuracy));
      else
	independentAccuracy =  independentAccuracy + 
	  ([agentModel getLearningRate] *
	   ((double) 1.0 - independentAccuracy));

      thresholdCount++;
      activationCount++;
      correctCount++;
      totalActivationCount++;
      totalCorrectCount++;

    }
  
  correct = True;
  
  if ([agentModel getLearning]) 
    {
      if ([self getDependentAccuracy] > [agentModel getThreshold])
	dependentAccuracy = 1;
    }
  
  return self;
}

-incorrect
{

  if ([agentModel getLearning]) 
  {
      
    if (!fired || ([agentModel getSelectedEffector] != supported)) {
      return self;
    }
      
    if (!lastActiveSupressed 
	&& !lastActiveTemporallySupressed
	&& ![self getUpdateTemporalSupressed]) 
	{
	  ownActivationCount++;
	  if ([agentModel getLearningRate] == 0 || 
	      [agentModel getUseAverageForAccuracy])
	    dependentAccuracy =  dependentAccuracy + 
	      (((double) 1/((double) ownActivationCount + 1)) *
	       ((double) 0 - dependentAccuracy));
	  else {
	    dependentAccuracy =  dependentAccuracy + ([agentModel getLearningRate] *
					  ((double) 0.0 - dependentAccuracy));
	  } 
	}

      if ([agentModel getLearningRate] == 0 || 
	  [agentModel getUseAverageForAccuracy])
	independentAccuracy =  independentAccuracy + 
	  (((double) 1/((double) activationCount + 1)) *
	   ((double) 0 - independentAccuracy));
      else
	independentAccuracy =  independentAccuracy + 
	  ([agentModel getLearningRate] *
	   ((double) 0 - independentAccuracy));
      
      thresholdCount++;
      activationCount++;
      totalActivationCount++;
      totalCorrectCount++;

    } 
  
  // update predictive strength
  
  correct = False;
  incorrectOnce = True;
  
  if ([agentModel getLearning])
    {
      if (dependentAccuracy < (1 - [agentModel getThreshold]))
	dependentAccuracy = 0;
    }
   
  return self;
}

-setLastCorrect
{
  lastCorrect = correct;
  return self;
}

-realDeactivate
{
  sentSupport = False;
  receivedReward = False;
  
  correct = False;
  lastInhibited = inhibited;
  inhibited = False;

  [super realDeactivate];

  return self;
}


-(boolean) setPrediction: (id) aNode
{
  if (aNode == nil)
    return False;
  prediction = aNode;
  
  return True;
}

-(boolean) containsTerminalNode
{
  
  if (([[self getGroup] getTerminalNode] != nil)
      && ![[[[[self getGroup] getTerminalNode] 
	      getGroup] getTopGroup] getFinalGroup])
    return True;
  
  return False;

}

-setInhibited: (boolean) aBoolean
{
  if ([agentModel getDebug]) 
    printf("\n setting inhibited to: %d for node: %ld", aBoolean, nodeNumber);
  inhibited = aBoolean;
  return self;
}

- (boolean) getInhibited
{
  return inhibited;
}

-getPrediction
{
  return prediction;
}

-(boolean) getLastCorrect
{
   return lastCorrect;
}

-addGroup: (id) aGroup
{
   if (nodeGroup != nil)
      printf("\n Warning - node group already allocated node: %ld",nodeNumber);

   nodeGroup = aGroup;
   return self; 
}

-(boolean) removePredictor: (id) aNode
{
   [super removePredictor: aNode];
   return True;	
}


-moveSuspendedOwner: (id) anOwner
{
// If the owner has not improved on this node's predictions, allow this
// node to participate in new connections.  Trick the node it predicts 
// (if detector) not to create a new predictive node, by making 
// suspended predictions

  // June 6 2001 - added following - proxyNodes also keep track of activeOwners
  if (nodeGroup != nil)
    [[nodeGroup getProxyNode] moveSuspendedOwner: anOwner];
							   
  if (![[self getActiveOwnerList] contains: anOwner])
    {
      if ([agentModel getDebug])
	printf("\n node %ld moving suspended owner", nodeNumber);

      [self addActiveOwner: anOwner];

      //      [[self getActiveOwnerList] addLast: anOwner];
    }

  if ([[self getSuspendedOwnerList] contains: anOwner])
    [[self getSuspendedOwnerList] remove: anOwner];
  
  return self;
}

-setSuspended: (boolean) aBoolean
{

// overridden in nary node
  if (nodeGroup != nil) 
    [nodeGroup setSuspended: aBoolean];
  suspended = aBoolean;
  return self;
}


-(boolean) setSupported: (id) aSupported
{
  if (aSupported == nil)
    return False;
  supported = aSupported;
  [supported addSupporter: self];
  return True;
}

-(id) getSupported
{
  return supported;
}

-(boolean) getCorrect
{
  return correct;
}

-(boolean) getGroupCorrect
{
  if (nodeGroup == nil)
    {
      printf("\nWARNING: in predictorNode::correct: node %ld has no group",
	     nodeNumber);      
    }
  
  return [nodeGroup getGroupCorrect];
}

-(boolean) getFired
{
    return fired;
}

-(boolean) setFired: (boolean) aBoolean
{
   fired = aBoolean;
   return fired;
}

-setCorrect: (boolean) aBoolean
{
   correct = aBoolean;
   return self;
}


-(int) getPredictionType
{
   return predictionType;
} 

-setPredictionType: (int) aType
{
   predictionType = aType;
   return self;
}

-(boolean) removeSupported
{
   if (supported == nil)
       return False;
   [supported removeSupporter: self];	
   supported = nil;
   return True;
}

// Fire when owners active is like a virtual copy of a Node.
// It means that even if it has active owners, unless those
// fire, you fire.

-createGroup
{
   id nodeGroup1;

   if (nodeGroup == nil)
   {
      nodeGroup1 = [NodeGroup createBegin: [agentModel getZone]];
      [nodeGroup1 setNodeNumber: [agentModel getNextNodeNumber: nodeGroup1]];
      [nodeGroup1 setAgentModel: agentModel];
      [agentModel addNode: nodeGroup1]; 
      nodeGroup1 = [nodeGroup1 createEnd];
      [nodeGroup1 buildObjects];
      [nodeGroup1 setNode: self];
      [self addGroup: nodeGroup1];
    }
   
// we belong to this group

   return self; 
}

-(boolean) getSteadyState
{
   return steadyState;
}


-(boolean) getTemporallySuspended
{
  return temporallySuspended;

}

-setTemporallySuspended: (boolean) aBoolean
{
  if ([agentModel getDebug])
    printf("\n Setting temporallysuspended to: %d for node: %ld",
	   aBoolean, nodeNumber);
  temporallySuspended = aBoolean;
  return self;
}


-(boolean) getSuspended
{
 // overridden in Narynode

   return suspended;
}

-(double) getDependentAccuracy
{ 
       return dependentAccuracy;
}

// Actual means not absolute - to fix a bug in the code for comparing
// terminal node strengths
-(double) getActualMaxIndependent
{
  // May 15 2000 - If all groups nil return 0 as no group is assigned yet
  // (i.e just copied). Used to printout as NaN in debug.

  if (nodeGroup != nil)
    return [nodeGroup getActualIndependentReturn];

  if (proxyGroup == nil)
      return 0;

  return [proxyGroup getActualIndependentReturn];
}


-(double) getMaxIndependentAccuracy
{
  // May 15 2000 - If all groups nil return 0 as no group is assigned yet
  // (i.e just copied). Used to printout as NaN in debug.

  if (nodeGroup != nil)
    return [nodeGroup getIndependentAccuracy];

  if (proxyGroup == nil)
      return 0;

  return [proxyGroup getIndependentAccuracy];
}


-(double) getMaxDependent
{
  // May 15 2000 - If all groups nil return 0 as no group is assigned yet
  // (i.e just copied). Used to printout as NaN in debug.

  if (nodeGroup != nil)
    return [nodeGroup getDependentReturn];

  if (proxyGroup == nil)
      return 0;

  return [proxyGroup getDependentReturn];
}


-(double) getMaxIndependent
{
  // May 15 2000 - If all groups nil return 0 as no group is assigned yet
  // (i.e just copied). Used to printout as NaN in debug.

  if (nodeGroup != nil)
    return [nodeGroup getIndependentReturn];

  if (proxyGroup == nil)
      return 0;

  return [proxyGroup getIndependentReturn];
}

-(int) getFamily
{
    return family;
}

-getInput: (id) owner
{
   int count; 

   count = [[self getActiveOwnerList] getCount];
   while (count > 0)
   {
       count--;
       if ([[self getActiveOwnerList] atOffset: count] == owner)
           return [[[self getActiveOwnerList] atOffset: count]
			 getInputFor: self];
   }

   count = [[self getSuspendedOwnerList] getCount];
   while (count > 0)
   {
       count--;
       if ([[self getSuspendedOwnerList] atOffset: count] == owner)
           return [[[self getSuspendedOwnerList] atOffset: count] 
			getInputFor: self];
   }

   printf("\n Warning no owner for self found +++++++++++++++++++");

   return nil;
}

-copyValues: (id) aNode 
{
  // This will copy the strengths for an existing node in a group
  // to a newly created node.

  // June 20 - comment all following to allow temporal and terminal 
  //           nodes to calculate own values 
  // if ([agentModel getCopyValues]) {
    // July 20 - commented accuracy lines
    [self setOwnCorrectCount: [aNode getOwnCorrectCount]];
    [(PredictorNode *) self setCorrectCount: [aNode getCorrectCount]];
    [self setDependentAccuracy: [aNode getDependentAccuracy]];
    [self setIndependentAccuracy: [aNode getIndependentAccuracy]];
    [self setRewardStrength: [aNode getRewardStrength]];

    [self setIndependentValue: [aNode getIndependentValue]];
    [self setDependentValue: [aNode getDependentValue]];

    [self setOwnActivationCount: [aNode getOwnActivationCount]];
    // [self setActivationCount: [aNode getActivationCount]];
    // }
  sentSupport = True;
  [prediction activePredictedBy: self]; 
  if ([agentModel getDebug])
    printf("\n node %ld copying values from: %ld, \n independentValue: %f, rewardStrength: %f",
	   [self getNodeNumber], [aNode getNodeNumber],
	   independentValue, rewardStrength);
  return self;
}

-setDependentAccuracy: (double) aDouble
{
  dependentAccuracy = aDouble;
  return self;
}

// Nov 13 2000- if accuracy is 0.1 for eg, then we can anticipate that the true reward
// is 10 times that. 

-(double) getDependentSpecificity {
  if (dependentAccuracy == 0)
    return 9999.0;
  return (1.0 / dependentAccuracy);
}

-(double) getIndependentSpecificity {
  if (independentAccuracy == 0)
    return 9999.0;
  return (1.0 / independentAccuracy);
}

-setIndependentAccuracy: (double) aDouble
{
  independentAccuracy = aDouble;
  return self;
}

-setRewardStrength: (double) aDouble
{
  rewardStrength = aDouble;
  return self;
}

-(double) getRewardStrength 
{
  return rewardStrength;
}

-setIndependentValue: (double) aDouble
{
  independentValue = aDouble;
  return self;
}

-(double) getIndependentValue
{
  return independentValue;
}


-(double) getAbsDependentValue
{
  if (dependentValue >= 0)
    return dependentValue;
  else
    return (dependentValue * -1.0);
}


-(double) getAbsIndependentValue
{
  if (independentValue >= 0)
    return independentValue;
  else
    return (independentValue * -1.0);
}


-(double) getIndependentAccuracy
{
    return independentAccuracy;
}

-(long) getOwnCorrectCount 
{
  return ownCorrectCount;
}

-setOwnCorrectCount: (long) aLong 
{
  ownCorrectCount = aLong;
  return self;
}

-(long) getOwnActivationCount 
{
  return ownActivationCount;
}

-setOwnActivationCount: (long) aLong 
{
  ownActivationCount = aLong;
  return self;
}

-(long) getCorrectCount 
{
  return correctCount;
}

-setCorrectCount: (long) aLong 
{
  correctCount = aLong;
  return self;
}

-(long) getActivationCount 
{
  return activationCount;
}

-setActivationCount: (long) aLong 
{
  activationCount = aLong;
  return self;
}

// Steady state is individual to particular nodes (independent from group)
// It determines when individual nodes can send support and 
// be used in new connections. It may be reset when a temporal chain is
// added to a group.

-setSteadyState: (boolean) aBoolean
{
  // Should only be set to True
  if (steadyState == aBoolean)
    return self;

  steadyState = aBoolean;

  if (nodeGroup != nil)
    [nodeGroup setSteadyState: aBoolean];

  return self;
}

-setDependentValue: (double) aDouble
{
  dependentValue = aDouble;
  return self;
}

-removeIfFinalTemporal {
  return [proxyGroup removeIfFinalTemporal];
}


-(double) getDependentValue
{
  return dependentValue;
}

-(double) getHypDependentValue
{
  return hypDependentValue;
}


-(boolean) getIncorrectOnce
{
  return incorrectOnce;
}

-isPredictor
{ 
  return self;
}

-setSentSupport: (boolean) aBoolean
{
    sentSupport = aBoolean;
    return self;
}

-setCopy
{
  copy=True;
  return self;
}

-(void) die
{
  [super die];
}

-printPredictors
{
  return self;  
}


-probeSelf: (int) number {
  if (nodeNumber == number) {
    [agentModel setDebug: True];
    [self printOn];
    [agentModel setDebug: False];
  }
  return self;
}

-incrementLifetimeCount
{
  lifetimeCount++;
  return self; 
}

-drawSelfOn: (Raster *) aRaster
{
  //	[aRaster drawPointX: x Y: y Color: color];
  return self;
}

-printOn
{
  return self;
}

-checkHypSupress 
{

// What this is doing is controlling the connections made by passive predictors
// If you are suspended, then supress your inputs. In this case, all the nodes
// beneath you (except your inputs without active owners) will update their
// predictive strengths and histories.  
// Otherwise, if you are active, and have active owners of yourself, only 
// supress your inputs when you yourself are firstsupressed.
// if you are active and do not have any active owners, or only suspended
// owners, then you should also supress your inputs. 

    return self;
}


-checkHypActiveSupress
{

// Changed this so that it activeSupresses nodes, if they have an
// activeOwner which is matched rather than just suspended owners
 
   if (![self respondsTo: M(isUnary)] 
      && hypMatched && !suspended)
       [(NaryNode *) self hypActiveSupressInputs];

   return self;
}


-hypPreFire
{

   if (([self getHypMatched] && !hypActiveSupressed) || 
          hypActive || (hypActivePredictorCount > 0)
                    || (hypSuspendedPredictorCount > 0))
   {
           
// If you have fired, supress your on inputs so you can be identified as 
// the highest node which has fired. The supress inputs message is passed
// down to the level of unary nodes


// If you don't want to supress nodes who have subordinated owners,
// at least make them have a suspended prediction.
// Note: that the fireUnlessOwnersActive flag is on. so they can make
// active predictions

       if ([self getSuspended])  
           hypPredictionType = suspendedType;  // defined in .def file
       else
           hypPredictionType = activeType;     // defined in .def file
   }

   return self;
}


-hypFire
{

 // Actually fire.  In this case if nodes with active or suspended owners
 // are supressed, their active predictions are converted to passive
 // to prevent the possibility of recreating existing connections

    if ((([self getHypMatched] && !hypActiveSupressed)
         || (hypActivePredictorCount > 0)
         || (hypSuspendedPredictorCount > 0)) &&!hypActive)
    {
        if ([agentModel getDebug])
        {  
          printf("\n hyp firing node: %ld", nodeNumber);
          printf("\nHyp Firing node %ld, group: %ld,  \n effector %d, realActive %d, \n prediction %ld, \n Suspended %d, sus own count: %d", 
             nodeNumber, [nodeGroup getNodeNumber],
             [supported getPosition], [self getRealActive], 
             [prediction getNodeNumber], [self getSuspended],
             [[self getSuspendedOwnerList] getCount]);
        }

        hypFired = True;
    }

// first supress is applied only to unary nodes, where if one in the family
// receives it another with the same effector does to.  IT DOES NOT
// affect nary nodes.

   if (hypFired)
   {
      if (hypSupressed)
      {
          hypPredictionType = passiveType; 
          if ([agentModel getDebug])  
              printf("\n node %ld supressed", nodeNumber);
      }
 
      if ([agentModel getDebug])  
          switch (hypPredictionType)
          {
             case activeType:
                printf("\t Active Prediction"); 
                break;
             case passiveType:
                printf("\t Passive Prediction");               
                break;
             case suspendedType:
                printf("\t Suspended prediction");  
                break;
             case connectType:
                printf("\t Connect prediction");  
                break;
           }

// Add suspended and active predictors to predictorList


      switch (hypPredictionType)
      {
        case activeType:
           [prediction hypActivePredictedBy: self]; 
           break;
        case suspendedType:
           [prediction hypSuspendedPredictedBy: self];      
           break;
        case passiveType:
           [prediction hypPassivePredictedBy: self];            
           break;
        case connectType:
           [prediction hypSuspendedPredictedBy: self];      
           break;
        default:
           printf("\n WARNING: No prediction type for node");
      }
   }
   return self;
}


-hypPay: (double *)  paymentPtr
{
 
   return self;
}

-(boolean) getHypFired
{
    return hypFired;
}

-(boolean) setHypFired: (boolean) aBoolean
{
    hypFired = aBoolean;
    return hypFired;
}

-(boolean) hypDeactivate
{

   [super hypDeactivate];

   return True;
}

-(boolean) hypActivate
{

    [super hypActivate];

    return True;
}
@end



