#import "EnvironmentSwarm.h"
#import "Cell.h"
#import <objectbase/SwarmObject.h>

@interface Position : SwarmObject
{
  Cell * cell;
  id worldModel;
  int x, y;
  int label;
  id positionArray;
  int north, south, east, west;
  id model;
  boolean occupied;
  float reward;
  int color;
}

+createBegin: aZone;
-setX: (int) newX Y: (int) newY;
-setModel: (id) aModel;
-setLabel: (int) aLabel; 
-(int) getLabel;
-(int) getX;
-(int) getY; 
-setPositionArray: (id) anArray;
-setWest: (int) aLabel; 
-(int) getWest; 
-setNorth: (int) aLabel; 
-(int) getNorth; 
-setSouth: (int) aLabel; 
-(int) getSouth; 
-setEast: (int) aLabel; 
-(int) getEast; 
-setModel: (id) aModel;
-(int) moveAgentNorth;
-(int) moveAgentSouth;
-(int) moveAgentEast;
-(int) moveAgentWest;
-setCell: (Cell *) aCell;
-setOccupied: (boolean) aBoolean;
-setReward: (float) aReward;
-(float) getReward;
-createEnd;
-drawSelfOn: aRaster; 
-buildObjects;
@end
