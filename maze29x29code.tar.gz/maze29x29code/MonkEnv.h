#import "AgentModelSwarm.h"
#import "Cell.h"
#import "Node.h"
#import "stdio.h"
#import <gui.h>

@interface EnvironmentSwarm  : Swarm
{
	id inputString;
        id datafile;
        id inputFile;
        id testfile;
        int problem;
	int inputFileCount;

        int epochCount;         
        int trainingEpochs;
        id agentModel;
        double reward;
        int effectorAction;
        id <Grid2d> grid;			     // objects representing 
        int cellCount;
        id cellArray;
        int gridXSize, gridYSize;
        int last, on, next;
        int correctCount, predictionCount, incorrectCount;

        FILE * inputfp, *outputfp;
        int end, class;
        int attrib[6];
}

+createBegin: (id) aZone;
-setAgent: (id) anAgent;
-setString: (char *) aString;
-createEnd;
-setProblem: (char *) aProblem epochs: (int) anEpoch;
-buildActions;
-activateIn: (id) swarmContext;
-getGrid;
-getCellArray;
-step;
-update;
-answer;
-(void) convertFrom: (int) anInt to: (id) aString length: (int) length;
-getString;
-resetAgentPosition;
-timeOut;
-(float) getPredictiveAccuracy;
-printOn;
@end






