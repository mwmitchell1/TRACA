// Agent application. Copyright (C) 1996 Matthew Mitchell.

#import "AgentObserverSwarm.h"

#import "AgentModelSwarm.h"
#import "EnvironmentSwarm.h"

#import <objectbase.h>
#import <analysis.h>
#import <simtoolsgui.h>

@implementation AgentObserverSwarm

// createBegin: here we set up the default observation parameters.

+createBegin: (id) aZone {
  AgentObserverSwarm * obj;
  id <ProbeMap> probeMap;
  
  // Superclass createBegin to allocate ourselves.
  obj = [super createBegin: aZone];

  // Fill in the relevant parameters (only one, in this case).
  obj->displayFrequency = 1;
  obj->effectorCount=4; // truck problem has 5 actions if using gaze back
  obj->detectorCount=70;
  obj->randomSeed=1;
  obj->stopAt=500001;
  obj->maze=1;
  obj->classify=0;
  obj->nyd=0;
  obj->reset = False;

  // Also, build a customized probe map. Without a probe map, the default
  // is to show all variables and messages. Here we choose to
  // customize the appearance of the probe, give a nicer interface.

  probeMap = [EmptyProbeMap createBegin: aZone];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameters
  [probeMap addProbe: [probeLibrary getProbeForVariable: "displayFrequency"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "detectorCount"
				    inClass: [self class]]];  
  [probeMap addProbe: [probeLibrary getProbeForVariable: "effectorCount"
 				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "randomSeed"
 				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "classify"
 				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "maze"
 				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "nyd"
 				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "stopAt"
 				    inClass: [self class]]];
 

  // Now install our custom probeMap into the probeLibrary.
  [probeLibrary setProbeMap: probeMap For: [self class]];

  return obj;
}

-setProblem: (char *) problemString
{
     problemFileName = problemString;
     return self;
}

-createEnd {
  return [super createEnd];
}

-buildObjects {
  id modelZone;					  // zone for model.
  id worldZone;

  [super buildObjects];
  
  // First, we create the model that we're actually observing. The
  // model is a subswarm of the observer. We also create the model in
  // its own zone, so storage is segregated.

  // First, create a colormap: this is a global resource, the information
  // here is used by lots of different objects.

  colormap = [Colormap create: [self getZone]];

  [colormap setColor: 1 ToName: "black"];
  [colormap setColor: 2 ToName: "red"];
  [colormap setColor: 3 ToName: "blue"];
  [colormap setColor: 4 ToName: "green"]; 
  [colormap setColor: 5 ToName: "white"];

  modelZone = [Zone create: [self getZone]];
  agentModelSwarm = [AgentModelSwarm create: modelZone];
  [agentModelSwarm setDetectorCount: detectorCount];
  [agentModelSwarm setEffectorCount: effectorCount];
  [agentModelSwarm setObserver: self];
  //  agentModelSwarm = [agentModelSwarm createEnd]; 

  worldZone = [Zone create: [self getZone]];

  environmentSwarm = [EnvironmentSwarm create: worldZone];
   [environmentSwarm setString: "1111100000"];
   [environmentSwarm setAgent: agentModelSwarm];
   //   [environmentSwarm setObserver: self];
   //  environmentSwarm = [environmentSwarm createEnd]; 

  // Now create probe objects on the model and ourselves. This gives a
  // simple user interface to let the user change parameters.

  [probeDisplayManager createProbeDisplayFor: environmentSwarm];
  [probeDisplayManager createProbeDisplayFor: agentModelSwarm];
  [probeDisplayManager createProbeDisplayFor: self];

  // Instruct the control panel to wait for a button event: we halt here
  // until someone hits a control panel button so the user can get a
  // chance to fill in parameters before the simulation runs

  [actionCache waitForControlEvent];
  if ([controlPanel getState] == ControlStateQuit)
    return self;
  //  [controlPanel setStateStopped] ;

  [agentModelSwarm setDetectorCount: detectorCount];
  [agentModelSwarm setEffectorCount: effectorCount];

  // First, let the model swarm build its objects.
  [agentModelSwarm buildObjects];

  //problemFileName = "1"; // to avoid crashing

  // NOTE: maze means that any +ve reward means the end of trial,
  // This happens for classification problems too, except any
  // reward other than zero it treated as end of cycle (this means
  // problems with zero rewards need to change AgentModel:move() 
  // Classify also executes 2 match cycles per timestep.

  if (maze || classify) {
    [(EnvironmentSwarm *) 
      environmentSwarm setProblem: problemFileName];
  }

  [environmentSwarm buildObjects];

  if (nyd)
    [probeDisplayManager createProbeDisplayFor: 
			 [environmentSwarm getNydConstants]];

  // Now get down to building our own display objects.

  //  if (maze) 
  // Now go in to the nodes in the model and set their colours to green (64)
  //  [[environmentSwarm getCellArray] forEach: M(setColor:) : (void *) 4];

// **** Number of Nodes Created
  
  triggerGraph = [Graph create: globalZone];
  [triggerGraph setTitle: "Number of Nodes vs. time"];
  [triggerGraph setAxisLabelsX: "Time" Y: "Number of Nodes"];

  triggerData = [triggerGraph createElement];
  [triggerData setLabel: "Unary Nodes"];
  [triggerData setColor: "green"];

  triggerGrapher = [ActiveGraph createBegin: globalZone];
  [triggerGrapher setElement: triggerData];
  [triggerGrapher setDataFeed: agentModelSwarm];
  [triggerGrapher setProbedSelector: M(getUnaryNodeCount)];
  triggerGrapher = [triggerGrapher createEnd];

  deltaTriggerData = [triggerGraph createElement];
  [deltaTriggerData setLabel: "Nary Nodes"];
  [deltaTriggerData setColor: "black"];

  deltaTriggerGrapher = [ActiveGraph createBegin: globalZone];
  [deltaTriggerGrapher setElement: deltaTriggerData];
  [deltaTriggerGrapher setDataFeed: agentModelSwarm];
  [deltaTriggerGrapher setProbedSelector: M(getNaryNodeCount)];
  deltaTriggerGrapher = [deltaTriggerGrapher createEnd];

  gammaTriggerData = [triggerGraph createElement];
  [gammaTriggerData setLabel: "Node Groups"];
  [gammaTriggerData setColor: "blue"];

  gammaTriggerGrapher = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapher setElement: gammaTriggerData];
  [gammaTriggerGrapher setDataFeed: agentModelSwarm];
  [gammaTriggerGrapher setProbedSelector: M(getNodeGroupCount)];
  gammaTriggerGrapher = [gammaTriggerGrapher createEnd];

  gammaTriggerDataB = [triggerGraph createElement];
  [gammaTriggerDataB setLabel: "Temporal Nodes"];
  [gammaTriggerDataB setColor: "red"];

  gammaTriggerGrapherB = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapherB setElement: gammaTriggerDataB];
  [gammaTriggerGrapherB setDataFeed: agentModelSwarm];
  [gammaTriggerGrapherB setProbedSelector: M(getTemporalNodeCount)];
  gammaTriggerGrapherB = [gammaTriggerGrapherB createEnd];

  gammaTriggerDataH = [triggerGraph createElement];
  [gammaTriggerDataH setLabel: "Terminal Nodes"];
  [gammaTriggerDataH setColor: "grey"];

  gammaTriggerGrapherH = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapherH setElement: gammaTriggerDataH];
  [gammaTriggerGrapherH setDataFeed: agentModelSwarm];
  [gammaTriggerGrapherH setProbedSelector: M(getTerminalNodeCount)];
  gammaTriggerGrapherH = [gammaTriggerGrapherH createEnd];
 
  [triggerGraph pack];

// **** Unsuspended node counts

  triggerGraphA = [Graph create: globalZone];
  [triggerGraphA setTitle: "Number of Unsuspended Nodes vs Time"];
  [triggerGraphA setAxisLabelsX: "Time" Y: "Active Count"];

  triggerDataA = [triggerGraphA createElement];
  [triggerDataA setLabel: "Temporal Nodes"];
  [triggerDataA setColor: "red"];

  triggerGrapherA = [ActiveGraph createBegin: globalZone];
  [triggerGrapherA setElement: triggerDataA];
  [triggerGrapherA setDataFeed: agentModelSwarm];
  [triggerGrapherA setProbedSelector: M(getTemporalActive)];
  triggerGrapherA = [triggerGrapherA createEnd];

  deltaTriggerDataA = [triggerGraphA createElement];
  [deltaTriggerDataA setLabel: "Nary Nodes"];
  [deltaTriggerDataA setColor: "black"];

  deltaTriggerGrapherA = [ActiveGraph createBegin: globalZone];
  [deltaTriggerGrapherA setElement: deltaTriggerDataA];
  [deltaTriggerGrapherA setDataFeed: agentModelSwarm];
  [deltaTriggerGrapherA setProbedSelector: M(getNaryActive)];
  deltaTriggerGrapherA = [deltaTriggerGrapherA createEnd];

  deltaTriggerDataB = [triggerGraphA createElement];
  [deltaTriggerDataB setLabel: "Unsuspended Groups"];
  [deltaTriggerDataB setColor: "green"];

  deltaTriggerGrapherB = [ActiveGraph createBegin: globalZone];
  [deltaTriggerGrapherB setElement: deltaTriggerDataB];
  [deltaTriggerGrapherB setDataFeed: agentModelSwarm];
  [deltaTriggerGrapherB setProbedSelector: M(getUnsuspendedGroups)];
  deltaTriggerGrapherB = [deltaTriggerGrapherB createEnd];

  triggerDataF = [triggerGraphA createElement];
  [triggerDataF setLabel: "Terminal Nodes"];
  [triggerDataF setColor: "grey"];

  triggerGrapherF = [ActiveGraph createBegin: globalZone];
  [triggerGrapherF setElement: triggerDataF];
  [triggerGrapherF setDataFeed: agentModelSwarm];
  [triggerGrapherF setProbedSelector: M(getTerminalActive)];
  triggerGrapherF = [triggerGrapherF createEnd];

  gammaTriggerDataE = [triggerGraphA createElement];
  [gammaTriggerDataE setLabel: "Total"];
  [gammaTriggerDataE setColor: "blue"];

  gammaTriggerGrapherE = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapherE setElement: gammaTriggerDataE];
  [gammaTriggerGrapherE setDataFeed: agentModelSwarm];
  [gammaTriggerGrapherE setProbedSelector: M(getActiveCount)];
  gammaTriggerGrapherE = [gammaTriggerGrapherE createEnd];

  [triggerGraphA pack];

// *** Predictive Accuracy of Network

  triggerGraphB = [Graph create: globalZone];
  [triggerGraphB setTitle: "Goal Achievement vs. time"];
  [triggerGraphB setAxisLabelsX: "Time" Y: "Achievement Rate"];

  gammaTriggerDataD = [triggerGraphB createElement];
  [gammaTriggerDataD setLabel: "Accuracy"];
  [gammaTriggerDataD setColor: "red"];

  gammaTriggerGrapherD = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapherD setElement: gammaTriggerDataD];
  [gammaTriggerGrapherD setDataFeed: environmentSwarm];
  [gammaTriggerGrapherD setProbedSelector: M(getPredictiveAccuracy)];
  gammaTriggerGrapherD = [gammaTriggerGrapherD createEnd];
 
  [triggerGraphB pack];

// *** Number of Incorrect Classifications

  triggerGraphC = [Graph create: globalZone];
  [triggerGraphC setTitle: "Incorrect Classifications vs. time"];
  [triggerGraphC setAxisLabelsX: "Time" Y: "Incorrect"];

  gammaTriggerDataC = [triggerGraphC createElement];
  [gammaTriggerDataC setLabel: "Incorrect Classifications"];
  [gammaTriggerDataC setColor: "red"];

  gammaTriggerGrapherC = [ActiveGraph createBegin: globalZone];
  [gammaTriggerGrapherC setElement: gammaTriggerDataC];
  [gammaTriggerGrapherC setDataFeed: environmentSwarm];
  [gammaTriggerGrapherC setProbedSelector: M(getIncorrectCount)];
  gammaTriggerGrapherC = [gammaTriggerGrapherC createEnd];
 
 
  [triggerGraphC pack];

  // Next, create a 2d window for display, set its size, zoom factor, title.
 
  agentRaster = [ZoomRaster create: [self getZone]];
  [agentRaster setColormap: colormap];
  [agentRaster setZoomFactor: 4];
  [agentRaster setWidth: [[agentModelSwarm getGrid] getSizeX]
	       Height: [[agentModelSwarm getGrid] getSizeY]];
  [agentRaster setWindowTitle: "Agent"];
  [agentRaster pack];				  // draw the window.

  // Create a raster for the agents environment (or world). 

  worldRaster = [ZoomRaster create: [self getZone]];
  [worldRaster setColormap: colormap];
  [worldRaster setZoomFactor: 8];
  [worldRaster setWidth: [[environmentSwarm getGrid] getSizeX]
	       Height: [[environmentSwarm getGrid] getSizeY]];
  [worldRaster setWindowTitle: "World"];
  [worldRaster pack];				  // draw the window.

  // And also create an Object2dDisplay: this object draws nodes on
  // the agentRaster widget for us, and also receives probes.

  agentDisplay = [Object2dDisplay createBegin: [self getZone]];
  [agentDisplay setDisplayWidget: agentRaster];
  [agentDisplay setDiscrete2dToDisplay: [agentModelSwarm getGrid]];
  [agentDisplay setObjectCollection: [agentModelSwarm getNodeList]];
  [agentDisplay setDisplayMessage: M(drawSelfOn:)];   // draw method
  agentDisplay = [agentDisplay createEnd];

  // Again for environment:

  worldDisplay = [Object2dDisplay createBegin: [self getZone]];
  [worldDisplay setDisplayWidget: worldRaster];
  [worldDisplay setDiscrete2dToDisplay: [environmentSwarm getGrid]];
  [worldDisplay setObjectCollection: [environmentSwarm getCellArray]];
  [worldDisplay setDisplayMessage: M(drawSelfOn:)];   // draw method
  worldDisplay = [worldDisplay createEnd];

  // Also, tell the agent raster to send mouse clicks to the agentDisplay
  // this allows the user to right-click on the display to probe the nodes.

  [agentRaster setButton: ButtonRight Client: agentDisplay Message: M(makeProbeAtX:Y:)];


  [worldRaster setButton: ButtonRight Client: worldDisplay Message: M(makeProbeAtX:Y:)];

  //  set the raster forEach of the created Nodes and Cells

  [[agentModelSwarm getNodeList] forEach: M(setRaster:) : (id) agentRaster];

  [[environmentSwarm getCellArray] forEach: M(setRaster:) : (id) worldRaster];
//  [agentModelSwarm setRaster: worldRaster];

// Seed the random generator, if this is False, seed from the following,
// otherwise, seed from time.

  //   if (timeSeedRandom == False)
  // {
  //    randomGenerator = [[PMMLCG1 alloc] initSeed: (randomSeed + 1)];
     [randomGenerator setStateFromSeed: (randomSeed + 1)];               
  //    uniformRandom = [[[Uniform alloc] init] setGenerator: randomGenerator];
  // }


  return self;
}

-buildActions {
  [super buildActions];
  
  [agentModelSwarm buildActions];
  
  modelActions = [ActionGroup create: [self getZone]];

  if (classify)
  { 
    printf("\n Classifying---");

    [modelActions createActionTo: self              message: M(checkToStop)];
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
  } 
  // Mar 28 2001 replaced following with 4 lines above.
  /*    [modelActions createActionTo: environmentSwarm  message: M(update)];  
    [modelActions createActionTo: agentModelSwarm   message: M(classify)];
    [modelActions createActionTo: environmentSwarm  message: M(answer)];  
    [modelActions createActionTo: agentModelSwarm   message: M(moveC)];
  */
  else
  {
    [modelActions createActionTo: self              message: M(checkToStop)];
    [modelActions createActionTo: environmentSwarm  message: M(step)];  
    [modelActions createActionTo: agentModelSwarm   message: M(move)];  
  }

  // And the display schedule. 

  modelSchedule = [Schedule createBegin: [self getZone]];
  [modelSchedule setRepeatInterval: 1]; 
  modelSchedule = [modelSchedule createEnd];
  [modelSchedule at: 0 createAction: modelActions];

  // Create an ActionGroup for display

  displayActions = [ActionGroup create: [self getZone]];
  [displayActions createActionTo: agentRaster          message: M(drawSelf)];
  [displayActions createActionTo: worldRaster          message: M(drawSelf)];
  [displayActions createActionTo: worldDisplay         message: M(display)];
  [displayActions createActionTo: agentDisplay         message: M(display)];
  [displayActions createActionTo: triggerGrapher       message: M(step)];
  [displayActions createActionTo: triggerGrapherA      message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherC message: M(step)];
  [displayActions createActionTo: deltaTriggerGrapher  message: M(step)];
  [displayActions createActionTo: deltaTriggerGrapherB message: M(step)];
  [displayActions createActionTo: deltaTriggerGrapherA message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapher  message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherB message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherC message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherD message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherE message: M(step)];
  [displayActions createActionTo: gammaTriggerGrapherH message: M(step)];
  [displayActions createActionTo: triggerGrapherF      message: M(step)];
  [displayActions createActionTo: probeDisplayManager  message: M(update)];
  [displayActions createActionTo: actionCache          message: M(doTkEvents)];

  // And the display schedule. 

  displaySchedule = [Schedule createBegin: [self getZone]];
  [displaySchedule setRepeatInterval: displayFrequency]; 
  displaySchedule = [displaySchedule createEnd];
  [displaySchedule at: 0 createAction: displayActions];

  return self;
}  

// activateIn: - activate the schedules so they're ready to run.

-resetAgentPosition
{
   reset = False;
   [environmentSwarm resetAgentPosition];
   return self;
}

-(boolean) getClassify
{
  return classify;
}

-(boolean) getMaze
{
  return maze;
}


-setReset: (boolean) aBoolean
{
     reset = aBoolean;
     return self;
}

-(boolean) getReset
{
      return reset;
}

-checkToStop
{
    if ((stopAt != 0) && (stopAt == getCurrentTime()))
        [self stop];
    return self;
} 

-stop
{
  [controlPanel setStateStopped] ;
  return self;
}

-timeOut
{
   [environmentSwarm timeOut];
   [self stop];
   return self;
}

-getEnvironment {
  return environmentSwarm;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  [modelSchedule activateIn: self];
  [displaySchedule activateIn: self];
  
  return [self getSwarmActivity];
}
@end




