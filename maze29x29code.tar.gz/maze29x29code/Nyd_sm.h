#import "EnvironmentSwarm.h"
#import <objectbase/SwarmObject.h>
#import "boolean.h"
#import "stdio.h"
#import "NYDConstants.h"

// This defines the learning agent's interface to the Sensory motor system
// implemented for the nyd problem.

@interface Nyd_sm : SwarmObject
{

  int nyd_sm_gaze_lane;
  int nyd_sm_gaze_position;
  int nyd_sm_last_action_illegal;
  int nyd_sm_last_action_overt;
  int nyd_sm_collision_count;
  int nyd_last_action;
  float nyd_sm_reward_noise_range;
  NYDConstants * Constants;
 
  int * pd;
  int done;
  id agentModel;
  id environment;
}

+createBegin: aZone;
-nyd_sm_init: (NYDConstants *) aConstants;
-createEnd;
-buildObjects;

-(char *) nyd_sm_name_for_action: (int) a;
-(int *) nyd_sm_perception_dimensions;
-(char *) nyd_sm_name_for_perception_dimension: (int) dimIndex;
-(char *) nyd_sm_name_for_perception: (int) perception index: (int) dimIndex;
-(float) nyd_sm_max_reward;
-(float) nyd_sm_min_reward;
-(int) nyd_sm_discretize: (int) dist;
-nyd_sm_get_percept_vector: (int *) vector;
-nyd_sm_perform_action: (int) action;
-setAgentModel: (id) aModel;
-setEnvironment: (id) anEnv;
-(float) nyd_sm_reward;
-writeDescription;
-(int) getCollisionCount;
- (char) nameForPerception: (int) percept;
@end




