#import "Position.h"

@implementation Position

+createBegin: aZone;
{  

  Position * obj;
  
  obj = [super createBegin: aZone]; 
  
  obj->east = -1;
  obj->west = -1;
  obj->north = -1;
  obj->south = -1;
  obj->reward = 0;

  return obj;
}

-setX: (int) newX Y: (int) newY
{
   x = newX;
   y = newY;
   return self; 
}

-setLabel: (int) aLabel 
{
  label = aLabel;
  return self;
}

-(int) getLabel
{
  return label;
}

-(int) getX 
{
  return x;
}

-(int) getY 
{
  return y;
}

-setPositionArray: (id) anArray
{
  positionArray = anArray;
  return self;
}

-setWest: (int) aLabel 
{
  west = aLabel;
  return self;
}

-(int) getWest 
{
  return west;
}

-setNorth: (int) aLabel 
{
  north = aLabel;
  return self;
}

-(int) getNorth 
{
  return north;
}

-setSouth: (int) aLabel 
{
  south = aLabel;
  return self;
}

-(int) getSouth 
{
  return south;
}

-setEast: (int) aLabel 
{
  east = aLabel;
  return self;
}

-(int) getEast 
{
  return east;
}

-setModel: (id) aModel
{
   worldModel = aModel;
   return self;
}

-(int) moveAgentNorth
{
  [self setOccupied: False];
  [[positionArray atOffset: north] setOccupied: True];
  return north;
}

-(int) moveAgentSouth
{
  [self setOccupied: False];
  [[positionArray atOffset: south] setOccupied: True];
  return south;
}

-(int) moveAgentEast
{
  [self setOccupied: False];
  [[positionArray atOffset: east] setOccupied: True];
  return east;
}

-(int) moveAgentWest
{
  [self setOccupied: False];
  [[positionArray atOffset: west] setOccupied: True];
  return west;
}

-setCell: (Cell *) aCell
{
  cell = aCell;
  [cell setCellColor: color];
  return self;
}

-setOccupied: (boolean) aBoolean
{
  occupied = aBoolean;
  if (aBoolean)
    [cell setCellColor: 3];
  else
    [cell resetColor];
  return self;
}

-setReward: (float) aReward
{
  reward = aReward;
  //  if ([agentModel getDebug])
  printf("\n reward set is: %f", reward);
  return self;
}

-(float) getReward
{
  return reward;
}
  
-createEnd
{
  return [super createEnd];
}

-drawSelfOn: aRaster 
{
  [cell drawSelfOn: aRaster];

  return self;
}

-buildObjects
{
  color = 0;
  occupied = False;

  if (west == -1)
    color = 1;
  else 
    if (reward > 0)
      color = 2;
    else
      color = 4;
 
  return self;
}

@end



