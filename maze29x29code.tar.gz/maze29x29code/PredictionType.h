#define noType 0
#define suspendedType 1
#define activeType 2
#define passiveType 3
#define connectType 4
#define inhibitedType 5
