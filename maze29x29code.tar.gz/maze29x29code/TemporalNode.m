#import "NaryNode.h"
#import "NodeGroup.h"
#import "TemporalNode.h"
#import "PredictorNode.h"
#import "DetectorNode.h"
#import "AgentModelSwarm.h"

/* Must set family of unary node in create phase 

   node addInput and removeInput are redifined here, although the predictor 
   class methods could be used this is more effecient as unary nodes have only    one input. It also allows for type checking, as UnaryNodes input must be a
   DetectorNode (Note: the prediction must also be a DetectorNode, but no type
   checking is used here). 
*/

@implementation TemporalNode

+createBegin: (id) aZone
{
   return [super createBegin: aZone];
}

-createEnd
{
   return self;
}

-buildObjects
{
   [super buildObjects];
   dependentAccuracy=1.0;

   [self setAcceptingMessages: True];
   waitingOnFirstInput = True;
   waitingOnSecondInput = False;
   secondInputMatchedNow = False;
   firstInputMatchedNow = False;
   firstInputMatchedLast = False;
   discountedTerminalValue = 0;
   temporalQreturn = 0;
   resetChain = False;
   lastResetChain = False;
   temporallyFired = 0;
   temporallyMatched = 0;
   temporallyRealActive = 0;

   okToFire = False;

   return self;
}

-realDeactivate
{

   [super realDeactivate];

// This next piece of code could be made more efficient by only doing it once
// nodes have fired.  In this it may be better to move some of the code
// into the owner ( and maybe move this bit) because otherwise, if the input
// node is a not connection, their could be a delay in setting the owner to 
// active

   if ([agentModel getDebug])
	printf("\n Temporal node %ld received deactivate. \n Realactive: %d matched: %d waitingOnsecondInput: %d waitingonfirstinput: %d, FIMN: %d", 
	       nodeNumber, realActive, matched, waitingOnSecondInput,
	       waitingOnFirstInput, firstInputMatchedNow);

   temporallyRealActive = temporallyMatched;
   temporallyMatched = False;

   [self setAcceptingMessages: True];
   if (firstInputMatchedNow)
     firstInputMatchedLast = True;
   else
     firstInputMatchedLast = False;

   lastResetChain = resetChain;
   resetChain = False;

   okToFire = False;

   return self;
}

-(boolean) getResetChain 
{
  return resetChain;
}

-(boolean) getLastResetChain 
{
  return lastResetChain;
}

/* June 2 2002 
   Temporal nodes are matched when first input matched and previous
   sequence in chain followed
*/

-(boolean) getTemporallyMatched {
  return temporallyMatched;
}

-(boolean) checkSuspended
{

  // Temporal nodes can also have themselves set to non-suspended
  // if the terminal node finds it is better predictor because
  // of the node. In that case, this group is set to finalGroup.

  // Feb 11 2000 - temporal node's suspended depends on how often the
  // chain has been matched, an individual node's activation does not count
  // (even though there is now only one per chain).

  if (!steadyState && ![self respondsTo: M(isUnary)])
   {
     if ([[nodeGroup getTopGroup] getFinalGroup])
       {
	 [self setSuspended: False];           
	 [self setSteadyState: True];
       }
   } 
  
   return True;
}


-(void) checkSuspendedInputs
{

// See PredictorNode checkSuspendedOwners 
// You are an owner and you need to test if you have improved the 
// prediction on one of your inputs. If not remove yourself       

// Here, you must ask your input nodes to move you to the activeowners
// list as you have improved your predictions on one of them


   if (([self getSuspended] == False) && (inputsMoved == False))
   {
       inputsMoved = True;
       [[[inputList getFirst] getNode] moveSuspendedOwner: self];
       [[[inputList getLast] getNode] moveSuspendedOwner: self];
   }
 
   // May 19 2000 - temporal nodes are not compared to inputs
   // They only initiate removal of the chain if the max q value
   // for the group is lower than some threshold after the group
   // has had its temporalActivation count reached.

   if  ([[self getGroup] getTemporallyActivated]
	&& suspended   // June 12 2002 - don't remove final chains!

	// April 4 2002 - don't do this until we have determined
	// to keep the most recent extension and therefore reset
	// the temporallyActivated count.
     //	&& ([[[self getGroup] getTerminalGroup] getChainCorrectCount] > 0)

	// Feb 23 2001 - chains are being removed before they
	// receive an updateValueEstimate, because the
	// prediction never occurs after the chain is matched.
	// perhaps the dicountedterminalvalue should be
	// updated more often (when FIMN?) 

	// July 9 - only first node should do this
	&& ([[self getGroup] getFirstNode] == self))
     //    == [self getDiscountedTerminalValue]))
     {
       // July 9 - >= 0
       if ((([self getDiscountedTerminalValue] >= 0)
	    && ([self getDiscountedTerminalValue] 
		< [agentModel getExtendThreshold]))
	   || (([self getDiscountedTerminalValue] < 0)
	       && ([self getDiscountedTerminalValue] 
		   > [agentModel getNegativeExtendThreshold]))) {

	 if ([agentModel getDebug]) {
	   //[agentModel printAsRule];
	   fprintf(stdout,"\n Removing Node %ld, chain too long, maxDepvalue: %f < extendThreshold", 
		   [[self getGroup] getNodeNumber], 
		   [self getDiscountedTerminalValue]);
	   [nodeGroup printOn];
	   [[nodeGroup getTerminalGroup] printOn];
	 }
	 [(NodeGroup *) [[self getGroup] getTopGroup] removeSelf: nil];
       }   

     }

   // the idea of the following piece of code was that if we
   // built a chain along one path, but then never followed that path
   // again, we could remove the chain. However, this lead to
   // useful chains being removed during random learning.
   // The unusedChainRemoval is now a parameter which should be set
   // very high for problems where there is no teacher. 

   if (![[[self getGroup] getTopGroup] getFinalGroup]
       && [[self getGroup] isTopGroup]
       && ([[self getGroup] getResetCount]
	   // Aug 13 2002 - chaned from activationThreshold to temporalAct.
	   > ([agentModel getTemporalActivationThreshold] 
	      * [agentModel getUnusedChainRemoval]))) {
     if ([agentModel getDebug])
       printf("Removing temporal node: %ld, because has not been extended", nodeNumber);
     [(NodeGroup *) [[self getGroup] getTopGroup] removeSelf: nil];
   }
   
}

// Prevent joins for nodes under temporal nodes except first.

-checkNarySupress 
{
  // Aug 8 - no I am undoing!
  // August 8 2002 - allow top temporal groups to nary supress. 
  /*
  if ([self getTemporallyRealActive]
      && [[self getGroup] isTopGroup]
      && [[[self getGroup] getTopGroup] getFinalGroup]) {
    if ([agentModel getDebug])
      printf("\n Temporal Node: %ld received checkNarySupress, realActive: %d",
	     nodeNumber, temporallyRealActive);
      [self narySupressInputs];    
  }
  */

  return self;
}

-narySupressInputs
{
  
   [[[inputList getFirst] getNode] narySupress];
 
   return self;
} 

-narySupress
{ 
   [self setNarySupressed: True];
   [proxyGroup setNarySupressed: True for: [self getSupported]];
   [self narySupressInputs];
  
   return self;
}

-(boolean) resetMatched: (boolean) aBoolean
{
   matched = aBoolean;
   return matched;
}

-checkCreateTemporalOk 
{
 // Nov 23 2000 - because for unfinished
  // chains new links can be added and removed from the ends, to prevent
  // duplicates, if you are the first group in a chain, and
  // you are unfinalised, you must prevent other chains from being
  // created if both your inputs were matched.

  // However you can be copied to predict new things as long
  // as you were correct - Nov 30 2000

  // Note that createTemporalOk is also set in match below
  // for finalised chains

  // Nov 30 2000 - commented following line
  //  if (![[proxyGroup getTopGroup] getFinalGroup] 

  // Dec 12 2000 - don't let any copies with same inputs form
  // regardless of prediction - nodes will be copied once final


  return self;
}

// This is the new match().  Ideally matched messages should be passed via
// the Input nodes.  Then we could turn off receiving matched messages from
// the second input until we have received one from the first. And once this
// is received turn off messages from the first. 
// If the messages are not on in the correct order we could abandon firing of
// this chain by reseting all the previously fired nodes in it. 
// We also need to allow differences for: 
// 1) First nodes in the chain which contain a terminal link.
// 2) other nodes in the chain
// 3) The necessity in both cases to take into consideration the firing of the 
//    previous node. 

// It works as follows, if you are the last node in the chain, you can accept
// messages from only your first input. Once this is true you can only accept 
// messages from your second input. If this subsequent match is not true, 
// you reset yourself and accept first node messages again.
// If you are a subsequent node you accept first messages, but they must be 
// true, otherwise you reset yourself and send a false matched message to 
// the previous node in the chain which passes it on. Each node receiving
// a not-matched message from its second node will reset itself. 

// Main problem: we will receive two messages each time step.  
// The message from the second input may come in the same timestep after 
// the first and may be true, meaning both inputs would be matched in same step.
// In fact, we can disregard any messages from second input until first is 
// received, however, once the first is received, we must prevent the second 
// from having any affect until the next time step. So must turn off accepting
// these messages until we are deactivated then messages from the second
// input will have affect.  Once we have been matched by the first message 
// (incorrect sequence with previous nodes) then we can disregard any messages
// from first input, until we the timestep after we are matched.


// A finite state machine implementation is probably more appropriate here!!! 


-match: (boolean) aBoolean by: (Node *) aNode
{

// if a nodes inputs have been removed it becomes a copy
// and is matched by the proxynode.

  id tNode;
  boolean reset = False;
  
  if (proxyGroup == nil)
    return self;
  
  if (!acceptingMessages)
    return self;
  
  // May 3 2000 - don't allow first first input to be matched if node is 
  // matched.
  
  if (matched)
    return self;
  
  if (firstInputMatchedNow)  // Some things need only be done in the same
    // cycle that the first input is matched. This flag is used to prevent them
    // recurring in subsequent cycles until the second input is matched.
    [self setFirstInputMatchedNow: False];
  
  if (secondInputMatchedNow)  // Some things need only be done in the same
    // cycle that the first input is matched.This flag is used to prevent them
    // recurring in subsequent cycles until the second input is matched.
    [self setSecondInputMatchedNow: False];
  
  if ([agentModel getDebug])
    fprintf(stdout,"\n In Temporal Match for node: %ld. OwnerWaitingOnSecond: %d, FirstInput: %d, waitingOnFirstInput: %d, aBoolean: %d, topGroup: %d", 
	    nodeNumber,   [self checkOwnerWaitingOnSecondInput], 
	    ([aNode getGroup] == [[[inputList getFirst] getNode] getGroup]),
	    waitingOnFirstInput, aBoolean,[(NodeGroup *) proxyGroup isTopGroup]);   

  // April 22 2002 - needed to change to deal with condition that occurs
  // with Rings' first maze, where 12 12 10 -> 7
  // the chain is 12, 10 -> 7, however, the first 12 matches the first input
  // meaning that it is reset on the second 12.  This only effects top groups
  // and only for homogenous chains where the first input occurs
  // two 



  // We need to check that the owner is accepting messages, as it may have 
  // just had its first input matched in this same timestep, this is done
  // in checkOwnerWaitingOnSecondInput 

  if ([(NodeGroup *) proxyGroup isTopGroup] ||
      [self checkOwnerWaitingOnSecondInput]) {
    // Don't need to worry about prior nodes
    // April 10 2000 - changed following condition significantly, 
    // the first input may be the same as the second
    if (([aNode getGroup] == [[[inputList getFirst] getNode] getGroup])
	&& waitingOnFirstInput)
      {
	// Feb 16 2001 - reset if owner did not fire
	if (![proxyGroup isTopGroup] && ![self checkOwnerPrimaryFired]) {
	  reset = True;
	  resetChain = True;
	}
	else {  
	  // This message is from first node.
	  if (aBoolean) {
	    [self setWaitingOnFirstInput: False];
	    [self setWaitingOnSecondInput: True];
	    [self setAcceptingMessages: False];
	    [self setFirstInputMatchedNow: True];
	    // May 20 2002 - 
	    [self setTemporallyMatched: True];
	    // If chain is matched again in new sequence
	    // reset activesuppressedatstart flag.
	    if ([[self getGroup] getFinalGroup]) {
	      [[self getGroup] setActiveSuppressedAtStart: False];
	    }
	    if ([[self getProxyOwnerList] getCount] > 0)
	      [[self getProxyOwnerList] forEach: M(match:by:) 
					  :(void *) True :(void *) self];
	  }
	  else {
	    // Our first input was not matched after the previous nodes 
	    // or in the case of a top group, just not matched
	    if (![proxyGroup isTopGroup]) {
	      resetChain = True;
	    }
	    reset = True;
	  }
	}
      }
    else {
      if (waitingOnFirstInput) { // just in case 1st input is different to 2nd
	return self;
      }
      // Added April 29 2000. Node's were being matched by first input 
      // in place of second input (but in correct order)

      if ([aNode getGroup] != [[[inputList getLast] getNode] getGroup]) {
	return self;
      }
      // Must be from second input
      if (aBoolean) {
	// Feb 16 2001 - if you're a temporal group with a terminal node,
	// your primary node must have fired to match, or you reset the chain.
	if (([proxyGroup getTerminalNode] != nil) 
	    && (![[self getGroup] getPrimaryFired])) {

	  // here is problem
 
	  reset = True; 
	  resetChain = True;
	}
	else
	  [self setSecondInputMatchedNow: True]; // reset waitingOn in match
      }
      else { // top groups may need to do nothing and wait a bit longer
        if ([(NodeGroup *) proxyGroup isTopGroup] 
	    && ![self getWaitingOnSecondInput])
	  [self setSecondInputMatchedNow: False];
	else {
	  // second input not matched after first
	  [self setSecondInputMatchedNow: False];
	  reset = True;
	  resetChain = True;
	  [proxyGroup incrementResetCount];
	}  
      } 
    }
  }
  else { 
    // We are not interested in any inputs until prior nodes have first
    // input matched. Unless we are waiting on second input, in this
    // we changed from being a top node after first input matched.
    if ([agentModel getDebug])
      printf("\n %ld returning self - owner not FIM", nodeNumber);
     return self;
  }

  if ([agentModel getDebug])
    fprintf(stdout, "\n %ld Finished match 1. FirstInputMAtchedNow: %d, \n SecondInputMAtchedNow: %d, waitingOnFirstInput: %d,\n waitingOnSecondInput: %d acceptingMessages: %d \nresetChain: %d", nodeNumber,
                     firstInputMatchedNow, secondInputMatchedNow,
                      waitingOnFirstInput, waitingOnSecondInput, 
                      acceptingMessages, reset); 
  
  // Thats the end of the complicated matching bit, now we concentrate on
  // things which must done once matched.


  if (secondInputMatchedNow) { // Now do the work    
    if ([agentModel getDebug])
      printf("\n Temporal Node: %ld Matched", nodeNumber);

    [self setMatched: True];
    [proxyGroup terminalNodeSetMatched: True];

    tNode = [proxyGroup getTerminalNode];
    
    if ((tNode != nil) 
	&& ([[tNode getGroup] getChainCorrectCount] > 0))
      [[tNode getGroup] setPredictionPassedFlag: False];
    
    if ([[self getTemporalOwnerList] getCount] > 0)
      [[self getTemporalOwnerList] forEach: M(match:by:) 
				:(void *) True :(void *) self];
  }         
  else 
    if (reset) {
      // Mar 2 2001 - if the actions to execute a chain are not
      // taken all nodes sending and sent the reset message
      // update a counter, once this reaches a maximum for any node
      // and the chain has not been extended, the chain is removed 
      if (resetChain)
	[proxyGroup incrementResetCount];

      [self setMatched: False];  // reset the chain
      [proxyGroup terminalNodeSetMatched: False];
      [self setTemporallyFired: False];

      if ([agentModel getDebug])
	printf("\n Temporal Group: %ld, notifying owners of false match", 
	       nodeNumber);
      // NOTE: this message should only go to owners that are
      // earlier than this group in the chain and NOT to nary owners
      // for this reason an additional list has been kept for TemporalGroups.

      // Temporal owners are also proxy owners. This code here
      // is the reason for the separate lists.  Nary owners
      // do not need this message (and should not get it! - matchCount)

      if ([[self getTemporalOwnerList] getCount] > 0)
	[[self getTemporalOwnerList] forEach: M(match:by:) 
				  :(void *) False :(void *) self];
    }

// Nodes which are at the top of the chain can be predicted by other nodes
// once they are established as the final group in the chain.
// In this case, they notify predictor nodes of their correctness once
// their first input is matched.

// Slightly different from NaryNodes, here the non copy node in the 
// group asks the proxyNode to send a correct message to any predictors.
// This is because realDeactivate affects the behaviour of -match for
// temporal nodes, but not for other nodes.  realDeactivate is not 
// sent to proxyNodes, so they cannot do the match cycle.
  // I guess we really only want ot do this if it is the final group.

  if (!acceptingMessages)
	// If we are not accepting messages, we have just matched first
	// node as True ,and will not do this again this timestep.
	// Don't send these messages to group
	// they are handled by proxy
    {
      if ([agentModel getDebug])
	printf("\n Temporal node: %ld sending correct", nodeNumber);
      [[proxyGroup getProxyNode] sendCorrect];
    }
  else {
    // Do this anyway, only nodes which fired will update counters
    if ([agentModel getDebug])
       printf("\n Temporal node: %ld sending incorrect", nodeNumber);
    [[proxyGroup getProxyNode] sendIncorrect];
  }
  // if we are the first node in the chain, must notify ourselves 
  // of being correct or incorrect.

  if (([[self getGroup] getTerminalNode] != nil) && matched)
    [[self getGroup] correct];
  // Nov 14 2000 - to only update when chain completes - do nothing
  
  if (reset) {
      if ([agentModel getDebug])
       printf("\n Temporal node: %ld sending incorrect 2", nodeNumber);

      // April 22 2002 - moved this from reset block further up.
      [[[self getGroup] getTopGroup] setActiveSuppressedAtStart: False];
 
      // Nov 14 2000 - to only update when chain completes
      // remove correct/incorrect 
      // [[self getGroup] incorrect];
      
      // May 26 2000 - This needs to be tested, but to
      // prevent duplicates, you  must now check that your first input
      // is not matched, if it is, matchfirstinput. 
      
      // The first input may be matching this cycle, but not
      // have matched yet (i.e second is 4 first is 5). This next bit
      // is for if it has already matched.

      // This code is repeated here for those times
      // when the chain is reset and the firstinput is matched 
      // in the same timestep.

      if ([(NodeGroup *) proxyGroup isTopGroup] &&
	  [[[[inputList getFirst] getNode] getGroup] getMatched]) {
	[self setAcceptingMessages: False];
	[self setWaitingOnFirstInput: False];
	[self setWaitingOnSecondInput: True];
	[self setFirstInputMatchedNow: True];

	[self setTemporallyMatched: True];
	// If chain is matched again in new sequence
	// reset activesuppressedatstart flag.
	if ([[self getGroup] getFinalGroup]) {
	  [[self getGroup] setActiveSuppressedAtStart: False];
	}
	if ([[self getProxyOwnerList] getCount] > 0)
	  [[self getProxyOwnerList] forEach: M(match:by:) 
				    :(void *) True :(void *) self];
	[self sendCorrect];
      }
    }

  if ([agentModel getDebug])
    fprintf(stdout, "\n %ld Finished match 2. FirstInputMAtchedNow: %d,\n SecondInputMAtchedNow: %d, waitingOnFirstInput: %d,\n waitingOnSecondInput: %d acceptingMessages: %d\n resetChain: %d", nodeNumber,
                     firstInputMatchedNow, secondInputMatchedNow,
                      waitingOnFirstInput, waitingOnSecondInput, 
                      acceptingMessages, resetChain); 
  return self;

}

// This will check if a node fired its designated action in the
// previous timestep, if it didn't the chain is reset,
// if its designated action has not been determined, because the chain
// has not yet been matched and the terminal node made a correct
// prediction, this will return True.

-(boolean) checkOwnerPrimaryFired
{
  // this will check (for a non-top group node) whether the owner
  // fired in the last cycle. 


  if (proxyGroup != nil && [(NodeGroup *) proxyGroup isTopGroup]) {
    if ([agentModel getDebug])
      fprintf(stdout, 
	      "\n WARNING: checkOwnerPrimaryFired called for topGroup");
    return False;
  }

  if ([agentModel getDebug]) {
    printf("\n Checking owner primary fired for node: %ld", nodeNumber);
    printf("Suspended owner list size: %d",
	   [[self getGroupSuspendedOwnerList] getCount]);
    printf("ActiveOwnerlist size: %d",
	   [[self getGroupActiveOwnerList] getCount]);
  }

  if ([[self getGroupSuspendedOwnerList] getCount] > 0)
    if ([[[[self getGroupSuspendedOwnerList] getFirst] 
	   getGroup] getPrimaryFired])
      return True;

  if ([[self getGroupActiveOwnerList] getCount] > 0)
    if ([[[[self getGroupActiveOwnerList] getFirst] 
	   getGroup] getPrimaryFired])
      return True;

  return False;
}

 
-(boolean) setMatched: (boolean) aBoolean
{
 // Overrides Nary node setMatched.

  // As we don't let our predicted node know we predicted them when we fired
  // we do it now.
  
  if ([agentModel getDebug])
    fprintf(stdout,"\n in setmatched for temporal node: %ld", nodeNumber);

   if (proxyGroup != nil)
     [proxyGroup setMatched: aBoolean];    
 
   [self setWaitingOnFirstInput: True];
   [self setWaitingOnSecondInput: False];
   
   matched = aBoolean;

   return matched;

}

// Added May 3 2000 - missing before so it didn't reset properly.

-(boolean) reset
{
  [self setTemporallyFired: False];
  firstInputMatchedLast = False;
  [self setMatched: False];
  realActive = False;
  resetChain = False;
  
  return True;
}


-sendCorrect
{

  // Only for proxyNodes
  // If we are the finalGroup in the chain, notify any predictors that we
  // were matched, otherwise, notify previous node in chain that we were 
  // matched (matched means first input matched)

  if ([(NodeGroup *) proxyGroup isTopGroup]) {
    if ([proxyGroup getFinalGroup]) {
      [activePredictorList forEach: M(correct)];   
      [suspendedPredictorList forEach: M(correct)];
      [passivePredictorList forEach: M(correct)];
    }
  } else {
    // Oct 25 2002 added: 
    // We are not top group, notify previous node in chain that we are
    // firstInputMatchedNow.
    [[[self getGroup] getPreviousNodeList] forEach: M(correct)];
  }


  // Mar 1 2001 - only update once chain is complete and prediction correct
  // or incorrect.
  /*
  else {
    // Nov 24 2000 - Each node is notified when the next link in the
    // chain is matched.  It allows each link to
    // reflect the uncertainty in the next being matched in turn.
    // But more importantly, it allows us to estimate the specificity
    // of the chain for comparisons with the input nodes. 
    [[[self getGroup] getPreviousNodeList] forEach: M(correct)];
  }
  */
   return self;
}

-sendIncorrect
{

  // Only for proxyNodes

  if ([(NodeGroup *) proxyGroup isTopGroup]) {
    if ([proxyGroup getFinalGroup]) {
      [activePredictorList forEach: M(incorrect)];
      [suspendedPredictorList forEach: M(incorrect)];
      [passivePredictorList forEach: M(incorrect)];
    }
  }

  // Mar 1 2001 - only update once chain is complete and prediction correct
  // or incorrect.
  /*
  else {
      [[[self getGroup] getPreviousNodeList] forEach: M(incorrect)];
  }

  */

  return self;
}

// Oct 16 2000 - added the following, only update correct and incorrect
// for temporal nodes when chain has been followed to completion and
// we can determine if the prediction is matched or not.
// sent initially by the first temporal node when it sends correct/incorrect
// The specificity from the most recent extension to the chain is used
// in the terminal node in place of its specificity. 

-sendPreviousCorrect: (boolean) aBoolean 
{

  if (([nodeGroup getFirstNode] != self)  
    && [(NodeGroup *) nodeGroup isTopGroup])
     return self;

  if (aBoolean)
      [[[self getGroup] getPreviousNodeList] forEach: M(correct)];
  else
      [[[self getGroup] getPreviousNodeList] forEach: M(incorrect)];

  [[[self getGroup] getPreviousNodeList] forEach: M(sendPreviousCorrect:)
					 : (void *) aBoolean];
  return self;
}


// This will only send
// if it is the final node (and can therefore be predicted).

-sendPredictorsReturn
{
    double payment=0;

    // Share in strength is passed back to predictors.  This is done through 
    // the node group which predicts nodes in itself.  First the strength
    // is set in the group, similar to getReward, only for each node in the 
    // group. This strength is then divided among nodes predicting the group.

    //  Payments are made whether a node has predictors or not.  If it doesn't
    //  the payments go to no-one.  This is to stop newly created nodes
    //  gaining a sudden high payment for just being first.

    if ([agentModel getDebug])
      printf("\nNode %ld group: %ld recieved sendPredictorsReturn", 
	     nodeNumber, [[self getGroup] getNodeNumber]);
    

    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    if ((nodeGroup == nil))
      // Jan 16 - removed following as temporal nodes
      // need to send returns to groups to update average
      // which is copied for predictors.
	// || ![nodeGroup getFinalGroup])
      return self;
    
    // Oct 5 2000 - include dependent specificity

    payment = dependentValue;
 
      // Oct 5 2000 - for now assume dependentAccuracy is 1, 
      // need to improve on this by only updating
      // temporal nodes dependenet accuracy when the policy of 
      // following the chain is being followed.

      // * (1 - dependentAccuracy); 
    
    // July 15 2002 - allow all nodes to send return - not jst those 
    // in final group.
    if ([[[self getGroup] getTopGroup] getFinalGroup]
	&& ([[self getGroup] getTopGroup] == [self getGroup])) {
      if ([self getFirstInputMatchedNow]
	  && !temporallySuspended) 
	{
	  if ([agentModel getDebug])
	    printf("\n TemporalNode %ld group: %ld sending return: %f \n activeSupressed: %d, activeTemporallySupressed: %d",
		   nodeNumber, [nodeGroup getNodeNumber], payment,
		   activeSupressed, activeTemporallySupressed);
	  
	  [nodeGroup setReturnStrength: &payment];
	}
    }

    /* July 4 2002 - removed following
    else {
      // Feb 21 2001 - only update if the terminal is realactive
      // if it is incorrect payment is xero.
      if ([[[self getGroup] getTerminalGroup] getRealActive]) {
	if (![[[[self getGroup] getTerminalGroup] getFirstNode] getCorrect])
	  payment = 0;
	[nodeGroup setReturnStrength: &payment];
      }
    }
    */
      
    
    return self;
}

-sendPreviousReturn
{
    double payment=0;

    // Share in strength is passed back to predictors.  This is done through 
    // the node group which predicts nodes in itself.  First the strength
    // is set in the group, similar to getReward, only for each node in the 
    // up. This strength is then divided among nodes predicting the group.
    
    //  Payments are made whether a node has predictors or not.  If it doesn't
    //  the payments go to no-one.  This is to stop newly created nodes
    //  gaining a sudden high payment for just being first.

    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    // For temporal Nodes, we must check that this is not
    // the highest node in the chain, or returns will be sent
    // to predictors at twice the value (see sendPredictorsReturn)

    if (nodeGroup == nil || [(NodeGroup *) nodeGroup isTopGroup])
        return self;

    // Oct 5 2000 - don't need to include dependent specificity
    // for temporal nodes, as this is taken into account with the 
    // terminal nodes.

    payment = dependentValue;
 
    if ([agentModel getDebug])
      printf("\n node %ld group: %ld sending previous return: %f \n activeSupressed: %d, firstinputmatched: %d, ActiveTS: %d",
	     nodeNumber, 
	     [nodeGroup getNodeNumber], payment, activeSupressed,
	     [self getFirstInputMatchedNow], activeTemporallySupressed);

    
    // Feb 21 2001 - only pay if terminal node is realactive

    // April 17 2002 - only pay if first input matched
    // (which only ocurs if previous group in chain fired and its effector
    // was selected). 


    // Oct 17 2002 - changed following:
    // If not1stinput match now - send zero return, 
    // otherwise full return, previous group will only update if
    // it sent support and effector was selected
    //    if (![self getFirstInputMatchedNow])
    //  {
    //    payment = 0;
    //  }

    if ([self getFirstInputMatchedNow]) {
      [nodeGroup setReturnStrength: &payment]; 
    }

    return self;
}

-payTemporalReturn: (double *)  paymentPtr
{
   
  //  Similar to payReturn, except applies only to temporal nodes.
  //  Is used to update dicountedTerminalValue using value passed 
  //  from next node in chain.
 
  if([agentModel getLearning])
    {
      if (temporallyFired) // only the first node temporally fires
	{
	  temporalQreturn = *paymentPtr;
	  if ([agentModel getDebug])
            printf("\n temporalQreturn received by: %ld is: %f", nodeNumber, temporalQreturn);
	}
    }
  
  return self;
}

// Feb 28 2001 - overridden as temporal nodes must remember they
// fired until the terminal group pays them.

-payReturn: (double *)  paymentPtr
{
   
  // Note: if this node is part of a node group, the payments received
  // are distributed across all nodes based on their predictive strength
  // The payments are distributed becauseall the nodes have the same inputs
  // and support the same effector, therefore they all contribute to the 
  // subsequent state.  However, the predictive strength is included
  // so that the strength of nodes reflects their accuracy. 
  
  // discount the amount you receive by your predictive strength
 
  if([agentModel getLearning])
    {
      if ([agentModel getDebug])
	printf("\n %ld sent support: %d", nodeNumber, sentSupport);

      if (fired) 
	{
	  Qreturn = *paymentPtr;
	  if ([agentModel getDebug])
            printf("\n Qreturn received by: %ld is: %f", nodeNumber, Qreturn);
	}
    }
  
  return self;
}

-sendTemporalReturn
{
    double payment=0;

    // This differs from sendPreviousReturn in that the value passed back  
    // is the discountedTerminalValue. This value does not include
    // any rewards received while the chain is active and is used
    // to determine when a chain is not useful and should be removed.
 
    if ((nodeGroup == nil) 
	|| [(NodeGroup *) nodeGroup isTopGroup]
	|| ([nodeGroup getFirstNode] != self ))
        return self;

    payment = discountedTerminalValue;
 
    if ([agentModel getDebug])
      printf("\n node %ld group: %ld sending temporal return: %f \n activeSupressed: %d, firstinputmatched: %d, ActiveTS: %d",
	     nodeNumber, 
	     [nodeGroup getNodeNumber], payment, activeSupressed,
	     [self getFirstInputMatchedNow], activeTemporallySupressed);
    // Mar 26 2001- send when matched
    // JUNE 1 2002 - careful here temporal getMatched return temporalMatched

    if ([self getMatched])
	// && (!activeSupressed)) 
      {
	[nodeGroup setTemporalReturnStrength: &payment]; 
      }
    return self;
}

-updateValueEstimate
{

 // This is used to update discountedTerminalValue, which
  // is used to determine when a chain has extended beyond
  // its usefulness.  The super version of this (in PredictorNode)
  // must still be called. The update to discountedTerminalValue
  // is conducted under the same conditions as for dependentValues.

  double newValue = 0;
  double temp = 0;
  double updateValue = 0;

  // Correct is slightly diff for temporal nodes, they are correct if the 
  // chain was followed to completion,(but must still be told this
  // and are when the next node in the chain has its input matched)
  // the fact that it might not is reflected in their ownActivationCount.
  // Temporal nodes won't be supressed.
  
  if (![agentModel getLearning])
    return self;

  // Aug 27 -
  //  if (firstInputMatchedNow)
  //  return self;

  if ([agentModel getDebug])
     printf("\n Update value estimate for Temporal Node: %ld, Group: %ld sentSuport: %d, eff: %d, temporallyFired: %d fired: %d", 
	       nodeNumber, [[self getGroup] getNodeNumber], sentSupport,
	    ([agentModel getSelectedEffector] == supported), 
	    temporallyFired, fired);

  // Feb 23 2001 - don't need to check this once primary node
  // established, however, must record if fired for other times
  // here we use temporallyFired as we must remember
  // when we fired until the temporal match cycle is complete

  // Feb 26 2001 - added check for temporal node being realActive,
  // otherwise each group updates immediately after firing and
  // not on completion of the chain. Note: this checks whether any
  // node in the terminal group fired (no realactive set yet).

  // May 22 2002 - changed temporallyFired to fired

  if (fired 
      // April 17 - changed below to above:
      //      && [[nodeGroup getTerminalGroup] getFired]
      && [agentModel getLearning])
      // Oct 24 - second try at changes - only update
      // values if correct (ie. next node in chain matched)
      // Oct 29 - ok now allow to reflect the probability of next 
      // link being activated  
      //      && correct)
    {
      /*
      if (nodeNumber == 1039)
	printf("\n Node 1039 updating value: %f with reward: %f q: %f time: %d", dependentValue, [agentModel getReward], Qreturn, getCurrentTime());
      */

     if ([agentModel getDebug] && [self respondsTo: M(isTemporal)])
	printf("\n Temporal Node %ld updating value with qReturn: %f to: %f",
	       nodeNumber, Qreturn, dependentValue);
      // Feb 10 2000
      
      // Now, dependentValue is used to send predictive support and calculate
      // Q return to previous nodes. independentValue is used to compare 
      // higher nodes to lower nodes. independentValue is updated every time
      // the node is activated, dependentValue takes into account active
      // supressions


     // August 8 2002 - added following:

     //     if (prediction == [self getGroup])
     //  Qreturn = 0;

     rewardStrength = [agentModel getReward];

     // Dec 4 2002 - added:

     Qreturn = [agentModel getQreturn];

     // Oct 29 2002 - if next link not matched, return is zero:
     if (!correct) {
       Qreturn = 0;
       // Oct 31 2002:
       // April 14 - trying uncomment this to see if reproduces orig results:
       rewardStrength = 0;
     }


     if (!lastActiveSupressed 
	 && !lastActiveActionSupressed
	 && ![self getUpdateTemporalSupressed]) { 
       
       dependentValue = // (1.0 - [self getAlpha]) *
	 dependentValue + 
	 [self getAlpha] *
	 ((rewardStrength + 
	   ([agentModel getDiscountRate] * Qreturn)) - dependentValue);

     
       if ([agentModel getDebug])
       printf("\n Node: %ld, indepValue: %f, ownActivationCount: %ld \n tempS: %f  rewardStrength: %f, Qreturn: %f, \n depAccuracy: %f",
	      nodeNumber, independentValue, ownActivationCount, 
	      dependentValue,
	      rewardStrength, Qreturn, dependentAccuracy);
     
     }
      // May 10 2001 - added following code - it is untested for 
      // temporal nodes, I don't know if they should check correct
      // or if next node is matched or has firstInputMatched
      // In fact, I don't think this matters for temporal nodes as
      // we do not use the independent value for any comparisons.

      if (correct)
	temp = 1.0;
      else
	temp = 0.0;

      updateValue = temp;
      

   //just comment out next bit if any problems
      
      /*
      if ([(NaryNode *) self getImproved] 
	  || ([self respondsTo: M(isUnary)] 
	      // Jun 5 2001 - changed totalActivationCount to correctCount
	      && [self getActivated]))
	// Sep 19 2001 - replaced following with above
	// && (correctCount >= [agentModel getActivationThreshold])))
	{
	  if (timeComparison == -1.0)
	    timeComparison = independentValue;
	  else
	    timeComparison = timeComparison + 
	      ([agentModel getLearningRate] *
	       (temp - timeComparison));
	  updateValue = timeComparison;
	  
	}
      */

      newValue = independentValue;
      // Really should always useAverage
      // if (activationCount <= [agentModel getActivationThreshold])
      if ([agentModel getUseAverageForReward]) 
	{
	  newValue = newValue + 
	    ((1.0 / (1.0 + (double) activationCount) *

     //	      ((rewardStrength + ([agentModel getDiscountRate] * Qreturn))
		(temp - newValue)));
	}
      else 
	{
	   newValue = newValue + 
	    ([agentModel getLearningRate] *
	      (updateValue - newValue));
	     
	   //  ((rewardStrength + 
	   // ([agentModel getDiscountRate] * Qreturn)) - newValue));
	} 
      independentValue = newValue;

      if ([agentModel getDebug])
	printf("\n Node: %ld, strength: %f, ownActivationCount: %ld tempS: %f\n rewardStrength: %f, Qreturn: %f, altAccurcy: %f",
	       nodeNumber, independentValue, ownActivationCount, 
	       dependentValue,
	       rewardStrength, Qreturn, dependentAccuracy);
      

      if ([agentModel getDebug]) {
	printf("\n finished temporal update");
      }
    }

  rewardStrength = 0;
  Qreturn = 0;
  reward = 0;
  
  if (matched  
      && [agentModel getLearning])
    {
      if ([agentModel getDebug] && [self respondsTo: M(isTemporal)])
	printf("\n Temporal Node %ld Group: %ld updating terminal discount with qReturn: %f to discountedTerminalValue: %f",
	       nodeNumber, [nodeGroup getNodeNumber], temporalQreturn, discountedTerminalValue);

      discountedTerminalValue = discountedTerminalValue 
	+ [agentModel getLearningRate] *
	(([agentModel getDiscountRate] 
	  * temporalQreturn) - discountedTerminalValue);
    }
  
  //printf("\n Temporal Node %ld Group: %ld setting temporalqreturn = 0",
  //	       nodeNumber, [nodeGroup getNodeNumber]);
  temporalQreturn = 0;
  reward = 0;
  
  return self;
}


-notifyPrediction
{

// Add suspended and active predictors to predictorList
// This done after fire (as is usual) because the predictors
// of a node are notified if they are correct or not when the node is matched
// Temporal nodes should not be notified until the chain is completed.
// As such this is called when a terminal node action is selected.

  switch (predictionType)
    {
    case activeType:
      [prediction activePredictedBy: self]; 
      break;
    case suspendedType:
      [prediction suspendedPredictedBy: self];      
      break;
    case passiveType:
      [prediction passivePredictedBy: self];            
      break;
    case connectType:
      [prediction suspendedPredictedBy: self];      
      break;
    default:
      printf("\n WARNING: No prediction type for node");
    }
  return self;
}

// Forward this message on once for each node group to the group.
-chainCorrect: (boolean) aBoolean 
{

  if ([agentModel getDebug])
    printf("\n Temporal node %ld sending chainCorrect to group", nodeNumber);

  if ([nodeGroup getFirstNode] == self)
    [nodeGroup chainCorrect: aBoolean];
  return self;
}

-checkSupress 
{
  return self;
}

-checkTemporalSupress 
{

  // For teminalGroups, temporallySupress when realActive
  // For temporalGroups, temporally suppress when firstInputMatchedLast
  // Note, this has the implication that once a node is included in a 
  // temporal chain it cannot ever be used again (as temporallySupressed
  // nodes are removed from extendList).  For this reason, only topGroups
  // in non-final chains and finalGroups in final chains checkTemporalSupress


  if ([agentModel getDebug])
    printf("\n Temporal node %ld received checkTemporalSupress FImatchedNow: %d", 
	   nodeNumber, firstInputMatchedNow);

  // Normally we would require that the node is realActive, however for
  // temporal nodes, this flag should not be reset until the 
  // next set of detector inputs, so this will work

  if (firstInputMatchedNow && [[self getGroup] getTopGroup]) 
      [(TemporalNode *) self temporalSupressFirstInput];     
   
  return self;
}

-checkUpdateTemporalSupress 
{

  if ([agentModel getDebug])
    printf("\n Temporal node %ld received checkUpdateTemporalSupress \n 1stInputMatched: %d", 
	   nodeNumber, firstInputMatchedNow);

  if (firstInputMatchedNow && [proxyGroup getPrimaryFired])
    [(TemporalNode *) self updateTemporalSupressFirstInput];     
    
  return self;
}

-checkActiveTemporalSupress 
{

  // What this is doing is controlling the connections made by passive 
  // predictors. If you are suspended, then supress your inputs. In this case,
  // all the nodes beneath you (except your inputs without active owners) will
  // update their predictive strengths and histories.  
  // Otherwise, if you are active, and have active owners of yourself, only 
  // supress your inputs when you yourself are firstsupressed.
  // if you are active and do not have any active owners, or only suspended
  // owners, then you should also supress your inputs. 

  if ([agentModel getDebug])
    printf("\n Temporal node %ld received checkActiveTemporalSupress \n matched: %d, suspended: %d, firstInputMatchedNow: %d", 
	   nodeNumber, matched, suspended, firstInputMatchedNow);

  // July 8 2002 - top groups should not prevent lower groups
  // from sending support.

  if (firstInputMatchedNow && !suspended && ![[self getGroup] isTopGroup])
    [(TemporalNode *) self activeTemporalSupressFirstInput];     

  return self;
}

-supress
{ 
   [self setSupressed: True];
   [proxyGroup setSupressed: True for: [self getSupported]];
   [self supressInputs];

   return self;
}

-temporalSupress
{ 
  [self setTemporallySupressed: True];
  [proxyGroup setTemporallySupressed: True for: [self getSupported]];
  
  if (waitingOnSecondInput)
    [self temporalSupressFirstInput];
  
   return self;
}


-updateTemporalSupress
{ 
   [self setUpdateTemporalSupressed: True];
   [proxyGroup setUpdateTemporalSupressed: True for: [self getSupported]];

   [self updateTemporalSupressFirstInput];
  
   return self;
}

-(double) getMaxTerminalValue
{
  if (nodeGroup != nil)
    return [nodeGroup getMaxTerminalValue];

  if (proxyGroup == nil)
      return 0;

  return [proxyGroup getMaxTerminalValue];
}


-supressInputs
{
   [[[inputList getFirst] getNode] supress];
 
   return self;
} 

-temporalSupressFirstInput
{
   [[[inputList getFirst] getNode] temporalSupress];
 
   return self;
} 

- (double) getAbsDiscountedTerminalValue {
  if (discountedTerminalValue < 0)
    return (-1.0 * discountedTerminalValue);
  return discountedTerminalValue;
}

-(double) getDiscountedTerminalValue
{
  return discountedTerminalValue;
} 

-updateTemporalSupressFirstInput
{
   [[[inputList getFirst] getNode] updateTemporalSupress];
 
   return self;
} 

-checkActiveSupress
{

  // this can be cleaned up, basically, the nodes which have just fired
  // for an effector activesupress their inputs, so they are not used
  // in new  connections, otherwise they are.

  // Changed this so that it activeSupresses nodes, if they have an
  // activeOwner which is matched rather than just suspended owners

  /*  May 19 2000 - removed as I don't think temporal nodes should
      respond to this message.
  */


  // Aug 8  - no! undoing
  // August 8 2002 - yes - top groups now should
  /*


  if ([agentModel getDebug])
    printf("\n Temporal node %ld received checkActiveSupress matched: %d, 
               suspended: %d, firstInputMatchedNow: %d", 
	   nodeNumber, matched, suspended, firstInputMatchedNow);

  if ([[self getGroup] isTopGroup])
    if (firstInputMatchedNow && !suspended)
      [(TemporalNode *) self activeSupressInput];
 
  */
  return self;
}

-activeTemporalSupress
{

   [self setActiveTemporallySupressed: True];

   //   if (firstInputMatchedNow)
   [self activeTemporalSupressFirstInput];

   [proxyGroup setActiveTemporallySupressed: True for: [self getSupported]];

   return self;
}

-activeSupress
{
  /*  May 19 2000 - removed as I don't think temporal nodes should
      respond to this message.
  */

  // April 17 2002 - yes they should.

  if ([agentModel getDebug])
   fprintf(stdout,"\n Temporal node: %ld received active supress", nodeNumber);
  
   [self setActiveSupressed: True];
   [self activeSupressInput];
   [proxyGroup setActiveSupressed: True for: [self getSupported]];

 
   return self;
}

-activeSupressInput
{

  /*  May 19 2000 - removed as I don't think temporal nodes should
      respond to this message.
  */
  // April 17 2002 - yes they should.
  /*
  if ([agentModel getDebug])
    fprintf(stdout, "\n Node: %ld active supressing input: %ld",
	    nodeNumber,  [[[inputList getFirst] getNode] getNodeNumber]);
  */
 
   [[[inputList getFirst] getNode] activeSupress];

   return self;
} 

-activeTemporalSupressFirstInput
{
   [[[inputList getFirst] getNode] activeTemporalSupress];

   return self;
} 


-setSecondInputMatchedNow: (boolean) aBoolean
{
   if (proxyGroup != nil)
       [proxyGroup setSecondInputMatchedNow: aBoolean];
   secondInputMatchedNow = aBoolean;
   return self;
}

-setWaitingOnSecondInput: (boolean) aBoolean
{
   if (proxyGroup != nil)
       [proxyGroup setWaitingOnSecondInput: aBoolean];
   waitingOnSecondInput = aBoolean;
   return self;
}

-(boolean) getWaitingOnSecondInput
{
   return waitingOnSecondInput;
}

-(boolean) getSecondInputMatchedNow
{
   return secondInputMatchedNow;
}


-(boolean) getAcceptingMessages
{
   return acceptingMessages;
}

-setAcceptingMessages: (boolean) aBoolean
{
  if (proxyGroup != nil)
       [proxyGroup setAcceptingMessages: aBoolean];
  acceptingMessages = aBoolean;
  return self;
}

-setWaitingOnFirstInput: (boolean) aBoolean
{
   if (proxyGroup != nil)
       [proxyGroup setWaitingOnFirstInput: aBoolean];
   waitingOnFirstInput = aBoolean;
   return self;
}

-setFirstInputMatchedNow: (boolean) aBoolean
{
  if (proxyGroup != nil)
    [proxyGroup setFirstInputMatchedNow: aBoolean];
  firstInputMatchedNow = aBoolean;
  return self;
}

-(boolean) getFirstInputMatchedNow 
{
  return firstInputMatchedNow;
}

-(boolean) getFirstInputMatchedLast 
{
  return firstInputMatchedLast;
}


-(boolean) getWaitingOnFirstInput
{
   return waitingOnFirstInput;
}

-isTemporal
{
   return self;
}


-copy: (id) aZone
{
   TemporalNode * node;
   int count;
   int index; 
  
   node = [TemporalNode createBegin: aZone];
   [node setGrid: grid];
   [node setX: x Y: y];
   [node setColor: color];
   [node setModel: agentModel];
   [node setType: type];                  // 0 is AND
   [node setNodeNumber: [agentModel getNextNodeNumber: node]];  
   node = [node createEnd]; 

   [node buildObjects];

   [node setMatched: matched];
   [node setSupressed: supressed];
   [node setNarySupressed: narySupressed];
   [node setSuspended: suspended];
   [node setSteadyState: steadyState];
   [node setAcceptingMessages: acceptingMessages];
   [node setSecondInputMatchedNow: secondInputMatchedNow];
   [node setFirstInputMatchedNow: firstInputMatchedNow];    
   [node setWaitingOnFirstInput: waitingOnFirstInput];
   [node setWaitingOnSecondInput: waitingOnSecondInput];
   count = [inputList getCount];
   
   for (index=0;index<count;index++)
     [node addInput: [[inputList atOffset: index] getNode]
	   AsOn: [[inputList atOffset: index] getOn]];

   // CAREFUL - this adds as active to the lower node, if suspended 
//           is used ask self if suspended or active, then add
   
   for(index=0;index<count;index++)
     if ([self isSuspended])
          [[[inputList atOffset: index] getNode] addSuspendedOwner: node]; 
     else  
          [[[inputList atOffset: index] getNode] addActiveOwner: node]; 
   
   // TerminalGroups and other TemporalGroups 
   // need to have any new nodes in chain added as owners, so that
   // they can send back support to these nodes.
   
   /* May 23 2002 - dont' need added as previous in Node.m
   if ([[self getGroup] getTerminalNode] == nil)
       [node addAsPreviousTo: [[inputList atOffset: 1] getNode]];  
   else
       [node addAsPreviousTo: [nodeGroup getTerminalNode]];  
   */   

   [agentModel addNode: node];
   
   [node setPrediction: prediction];

   [node setSupported: supported];
   
   return node;
}


-preFire
{
   okToFire = False;

// Check for copy tells us that the node was just matched

   if ([agentModel getDebug])
       fprintf(stdout,"\n Prefire Temporal Node %ld,\n checkOwnerWaiting 2nd input %d\n firstInputMatchedNow: %d\n waitingOnSecondInput: %d\ntopGroup: %d",
	       nodeNumber,
	       [[[self getGroup] getProxyNode] checkOwnerWaitingOnSecondInput],
	       firstInputMatchedNow,
	       waitingOnSecondInput, 
	       [(NodeGroup *) nodeGroup isTopGroup]);

   if (firstInputMatchedNow && 
       ((waitingOnSecondInput && [(NodeGroup *)nodeGroup isTopGroup])
	|| (![(NodeGroup *) nodeGroup isTopGroup] && 
	    waitingOnSecondInput && [self checkOwnerWaitingOnSecondInput])))
     {
       if ([agentModel getDebug])
	 printf("\n Node: %ld. Setting prefired for group to true", 
		nodeNumber);

       [nodeGroup setPreFired: True];
       
       // OkToFire is used for non-top nodes, so they only send support
       // if the chain before them has been activated.

       okToFire = True;
       
       // If you have fired, supress your on inputs so you can be identified as 
       // the highest node which has fired. The supress inputs message is 
       // passed down to the level of unary nodes

       // If you don't want to supress nodes who have subordinated owners,
       // at least make them have a suspended prediction.
       // Note: that the fireUnlessOwnersActive flag is on. so they can make
       // active predictions

       // May 3 temporal nodes have an additional condition that
       // they do not send support or make active predictions until
       // the chain is finalised

       if ([self getSuspended] 
	   || ![[[self getGroup] getTopGroup] getFinalGroup])  
	 predictionType = suspendedType;  // defined in .def file
       else
	 predictionType = activeType;     // defined in .def file
     }

   return self;
}

-fire
{

  // Actually fire.  In this case if nodes with active or suspended owners
  // are supressed, their active predictions are converted to passive
  // to prevent the possibility of recreating existing connections
  
  if (okToFire && [supported getSelected]) 
    {
      [(NodeGroup *) nodeGroup setFired: True];
      // Feb 21 2001 - this may end up being the primary node if the 
      // chain is matched and the prediction correct.
      firedCount++;
      if ([agentModel getDebug])
	{  
	  printf("\n firing Temporal node: %ld", nodeNumber);
	  printf("\n Firing Temporal node %ld, group: %ld, effector %d,\n realActive %d, \n prediction %ld, \n Suspended %d, sus own count: %d\n", 
		 nodeNumber, [nodeGroup getNodeNumber],
		 [supported getPosition], [self getRealActive], 
		 [prediction getNodeNumber], [self getSuspended],
		 [[self getSuspendedOwnerList] getCount]);
	}
      // Feb 23 2001 - reset this only once entire chain matched.
      // used in updateValueEstimate.


      // May 22 2002 - inserted if condition:

      if ([[self getGroup] getFirstNode] == self)
	temporallyFired = True;

      fired = True;
   }

  if (fired)
    {
      if ([self getNarySupressed]
	  || lastActiveSupressed 
	  || lastActiveTemporallySupressed
	  || suspended)
	// Jan 29 2001 - allow temporallySupressed nodes to make
	// active predictions. 
	// || temporallySupressed)
	{ 
	  if (lastActiveSupressed 
	      || lastActiveTemporallySupressed)
	    {
	      if ([agentModel getDebug])  
                printf("\n Temporal node %ld active supressed", nodeNumber);
	      predictionType = passiveType; 
	    }
	  else
             predictionType = suspendedType;
	} 
  
  // Note temporal nodes don't really make predictions, as they are just
  // part of a chain, they are notified of correctness or incorrectness
  // based on wether or not the subsequent node in the chain had
  // its first input matched.
  
      if ([agentModel getDebug])  
	switch (predictionType)
	  {
	  case activeType:
	    printf("\t Active Prediction"); 
	    break;
	  case passiveType:
	    printf("\t Passive Prediction");               
	    break;
	  case suspendedType:
	    printf("\t Suspended prediction");  
	    break;
	  case connectType:
	    printf("\t Connect prediction");  
	    break;
	  }
      
      // June 2 2002 - add as predictor to prediction
      
      if ([[self getGroup] getFirstNode] != self)
	switch (predictionType)
	  {
	  case activeType:
	    [prediction activePredictedBy: self]; 
	    break;
	  case suspendedType:
	    [prediction suspendedPredictedBy: self];      
	    break;
	  case passiveType:
	    [prediction passivePredictedBy: self];            
	    break;
	  case connectType:
	    [prediction suspendedPredictedBy: self];      
	    break;
	  case inhibitedType:
	    [prediction suspendedPredictedBy: self];      
	    break;
	  default:
	    printf("\n WARNING: No prediction type for node: %ld", nodeNumber);
	  }
    }
  
  return self;
}

-sendFrequency {

  double adjustedPSupport = 0;
  
  if (removed)
    return self;
  
  if ([agentModel getDebug])
    printf("\n Temporal Node sendFrequency: %ld, group: %ld realActive: %d", nodeNumber,
	   [[self getGroup] getNodeNumber], [self getRealActive]);

  // Removed July 2 - 2020 for maze10 task -
  // allows each group in a temporal chain to send support.
  if (![[[self getGroup] getTopGroup] getFinalGroup])
    return self;
  
  if (okToFire)
    {
      sentSupport = True;  
      
      adjustedPSupport = dependentValue;
      
      if ([self getActiveSupressed]
	  ||  [self getActiveTemporallySupressed])
	return self;  
      
      //      if (adjustedPSupport != 0.0)
      //	{
      [nodeGroup setFrequencyFrom: self];  
	  //	}
    }
   return self;
}

-sendActivePredictiveSupport
{
  
   double adjustedPSupport=0;

   // In this case the predictive strength is used to influence the systems
   // exploration rate.  This is determined by an exploration rate.  
   // A higher exploration rate will lead to more exploration over exploitation

   // As firstInputMatchedNow is not reset until the next match cycle
   // this should be ok.

   if (!firstInputMatchedNow) // || ![[nodeGroup getTopGroup] getFinalGroup])
     return self;

   // May 20 2002 - not any more - allow other nodes to fire
 
  // May 30 2002 added following:

   if (!okToFire)
     return self;

   sentSupport = True;  
  
   // Jan 31 2001 - allowing suspended terminal and temporal
   // nodes to send support, as these values will be no less incorrect
   // than those of the input nodes and may avoid oscillating values.

   if ([agentModel getDebug] 
       || ([agentModel getTrackRules]
	   && [agentModel getTrackActions]))
     printf("\n Temporal Node number %ld Group: %ld sending support: %f,\n depValue: %f for effector: %d",
	    nodeNumber, [[self getGroup] getNodeNumber], adjustedPSupport, 
	    dependentValue, [supported getPosition]);

   // July 8 2002 - nodes in top temporal groups do not send support


   // 2019 if ([[(NodeGroup *) [self getGroup] getTopGroup] getFinalGroup]) {
   // 2019   adjustedPSupport = dependentValue;
   // 2019 }

   // June 18 2002 - changed to use sendFrequency

   //   if (adjustedPSupport != 0 && ![self getActiveSupressed]) {
     
   //  if ((dependentValue - [agentModel getVariance]) > 0) {
   if ([nodeGroup getMostFrequentPositive: self] == self) {
     if ([agentModel getDebug] || ([agentModel getTrackRules]
				   && [agentModel getTrackActions])){
       printf("\n Temporal Node number %ld Group: %ld Effector: %d\n \t sending support: %f, depVal: %f",
	      nodeNumber, [nodeGroup getNodeNumber], 
		    [supported getPosition], 
	      adjustedPSupport, dependentValue);
     }
     
     [supported addPredictiveSupport: adjustedPSupport node: self];
     [nodeGroup setMostFrequentPositive: self to: nil];
   } 

   /*
     else
       if ((dependentValue + [agentModel getVariance]) < 0) {
	 if ([nodeGroup getMostFrequentNegative: self] == self) {
	   if ([agentModel getDebug] 
	       || ([agentModel getTrackRules]
		   && [agentModel getTrackActions])) {
	     printf("\n Temporal Node number %ld Group: %ld Effector: %d
                     \t sending support: %f, depVal: %f",
		    nodeNumber, [nodeGroup getNodeNumber], 
		    [supported getPosition], adjustedPSupport, dependentValue);
	   }
	   
	   [supported addPredictiveSupport: 
			adjustedPSupport node: self];
	   [nodeGroup setMostFrequentNegative: self to: nil];
	 }
	 }

   */ 
     
   return self;
}

// 14 Nov 2000 - chains have a concept of correctness now,
// given that the policy should be followed (select action with
// highest value) when incomplete chains are being formed
// chains will be correct when the entire chain is completed
// and the prediction is correct, and incorrect only when the
// entire chain is completed and the prediction incorrect.

//  If chain is not followed, correct/incorrect not called

// This is possible because incomplete chains have only one terminal
// node. Therefore this only makes sense while the chain is 
// incomplete (non-final).

// Nov 20 2000 - changed this - as the policy may mean that the 
// next link in a chain does not follow the first - chains accuracy
// must reflect this.  The independentAccuracy is only independent
// of any direct influence, it is however, dependent on the policy.

-correct 
{

  // Oct 16 2000
  // Mar 1 2001 - just check if this temporal node fired during the
  // chain's execution

  // May 22 2002 - changed temporallyFired to fired

  if (!fired)
    return self;

  if ([agentModel getLearning]) 
    { 
      if (!lastActiveSupressed && !lastActiveTemporallySupressed) 
	{
	  if ([agentModel getDebug])
            fprintf(stdout, "\n Temporal Node: %ld incrementing \nactivation count in correct", nodeNumber);
	  
	  ownCorrectCount++;
	  ownActivationCount++;
	  
	  if ([agentModel getLearningRate] == 0 || 
	      [agentModel getUseAverageForAccuracy])
	    dependentAccuracy =  dependentAccuracy + 
	      (((double) 1.0 / ((double) ownActivationCount + 1)) *
	       ((double) 1 - dependentAccuracy));
	  else
	    dependentAccuracy =  dependentAccuracy + ([agentModel getLearningRate] *
					  ((double) 1 - dependentAccuracy));
	  
	}	       
      thresholdCount++;
      activationCount++;
      correctCount++;
      totalActivationCount++;
      totalCorrectCount++;
    }
  
  correct = True;
  
  if ([agentModel getLearning]) 
    {
      if ([self getDependentAccuracy] > [agentModel getThreshold])
	dependentAccuracy = 1;
    }
  
  return self;
}

-incorrect
{

  // Oct 16 2000
  if (!fired || ([agentModel getSelectedEffector] != supported))
    return self;

  if ([agentModel getLearning]) 
    {
      if (!lastActiveSupressed && !lastActiveTemporallySupressed) 
	{
	  if ([agentModel getDebug])
            fprintf(stdout, "\n Temporal Node: %ld incrementing \n activation count in INcorrect", nodeNumber);
	  ownActivationCount++;
	  if ([agentModel getLearningRate] == 0 || 
	      [agentModel getUseAverageForAccuracy])
	    dependentAccuracy =  dependentAccuracy + 
	      (((double) 1/((double) ownActivationCount + 1)) *
	       ((double) 0 - dependentAccuracy));
	  else
	    dependentAccuracy =  dependentAccuracy + 
	      ([agentModel getLearningRate] *
	       ((double) 0 - dependentAccuracy)); 
	}
      
      thresholdCount++;
      activationCount++;
      totalActivationCount++;
      totalCorrectCount++;
    } 
  
  // update predictive strength
  
  correct = False;

  if ([agentModel getLearning])
    {
      if (dependentAccuracy < (1 - [agentModel getThreshold]))
	dependentAccuracy = 0;
    }
  
  return self;
}

-temporalCorrect
{
  // Temporal nodes have no concept of correctness, they keep an activation
  // count for the number of times their inputs have been matched.  Send by
  // Node.m temporalCorrect.
  
  // 14 Nov 2000 - they have a concept of correctness now,
  // given that the policy should be followed (select action with
  // highest value) when incomplete chains are being formed
  // chains will be correct when the entire chain is completed
  // and the prediction is correct, and incorrect onyl when the
  // entire chain is completed and the prediction incorrect.

  // This is possible because incomplete chains have only one terminal
  // node. Therefore this only makes sense while the chain is 
  // incomplete (non-final).


  if ([agentModel getDebug])
    printf("\n Temporal Node correct %ld", nodeNumber);

  if ([agentModel getLearning]) 
    {
      if (!activeSupressed)
        ownActivationCount++;
			       
      thresholdCount++;
      activationCount++;
      totalActivationCount++;
      totalCorrectCount++;
    }
  
  correct = True;
  
  return self;
}

-(boolean) checkOwnerWaitingOnSecondInput
{
  // this will check (for a non-topgroup node) whether the owner
  // has had its first input matched.  (note that temporal 
  // nodes will have only temporal owners (unless perhaps it is top)). 

  if (proxyGroup != nil && [(NodeGroup *) proxyGroup isTopGroup]) {
    fprintf(stdout, 
	    "\n WARNING: checkOwnerWaitingOnSecondInput called for topGroup");
    return False;
  }

  if ([agentModel getDebug]) {
    printf("\n Checking owners for node: %ld", nodeNumber);
    printf("Suspended owner list size: %d",
	   [[self getGroupSuspendedOwnerList] getCount]);
    printf("ActiveOwnerlist size: %d",
	   [[self getGroupActiveOwnerList] getCount]);
  }

  // July 1 2002 - changed following added method to get temporal owner list:

  if ([[self getGroupTemporalOwnerList] getCount] > 0)
    if ([[[self getGroupTemporalOwnerList] getFirst] getAcceptingMessages])
      return [[[self getGroupTemporalOwnerList] getFirst] getWaitingOnSecondInput];

  return False;
}

// Since individual temporal nodes don't have any owners, 
// need to ask proxy node for list

-getGroupTemporalOwnerList
{
  if (nodeGroup != nil)
    return [[nodeGroup getProxyNode] getTemporalOwnerList];
  else
    return temporalOwnerList;
}

-getGroupSuspendedOwnerList
{
  if (nodeGroup != nil)
    return [[nodeGroup getProxyNode] getSuspendedOwnerList];
  else
    return suspendedOwnerList;
}

-getGroupActiveOwnerList
{
  if (nodeGroup != nil)
    return [[nodeGroup getProxyNode] getActiveOwnerList];
  else
    return activeOwnerList;
}


-addAsPreviousTo: (id) aNode 
{

  // Adds a temporal node as previous to the given node (next in chain or
  // terminal node).

  [[aNode getGroup] addPreviousNode: self];

  return self;
}

-setTemporallyMatched: (boolean) aBool {
  temporallyMatched = aBool;
  return self;
}

-resetTemporallyFired
{
  // Feb 28 2001 - only do this if terminal GROUP fired,
  // otherwise, will be reset if chain is reset 

  // Only applies to firstnode anyway.

  if ([[nodeGroup getTerminalGroup] getFired]) 
    {
      [self setTemporallyFired: False];
    }
  return self;
}

-(boolean) getTemporallyFired {
  return temporallyFired;
}

-setTemporallyFired: (boolean) aBoolean
{
  temporallyFired = False;
  return self;   
}

-(boolean) getTemporallyRealActive {
  return temporallyRealActive;
}

-(boolean) checkSecondInputMatched
{

// this will check whether a temporal node's second input group
// has its first input matched now.  Used for the creation of
// copies for temporal nodes.
   
   if ([[[inputList getLast] getNode] respondsTo: M(isTemporal)])
       return [[[inputList getLast] getNode] getWaitingOnSecondInput];
   else
       return [[[inputList getLast] getNode] getMatched];
}
@end




