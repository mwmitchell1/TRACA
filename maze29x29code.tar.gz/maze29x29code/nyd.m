/* Implementation of the New York Driving reinforcement learning task. */

/* Highway is layed out as a grid.
   Left-most lane number is low, right-most lane number is high.
   Forward direction of travel is toward higher position numbers. */

#import <random.h>
#include "nyd.h"
#include <malloc.h>
#include <printf.h>

/* Global variables. */
int nyd_num_lanes, nyd_num_positions;
int nyd_agent_lane, nyd_agent_position;
struct nyd_truck ***nyd_grid;
int nyd_last_action_illegal;

/* Parameters of the world's behavior, with default values. */
int nyd_max_truck_speed = 1;
int nyd_min_truck_speed = -1;
float nyd_fast_truck_probability = 0.0f; // change to 0.5 for gazeback
float nyd_new_truck_probability = 0.5f;
float nyd_double_truck_probability = 0.0f;

/* Initialize the world.  This function should be called before any
   other nyd_ functions. */
void
nyd_init (int num_lanes, int num_positions)
{
  int i;

  nyd_num_lanes = num_lanes;
  nyd_num_positions = num_positions;
  nyd_agent_lane = num_lanes - 2;
  nyd_agent_position = num_positions / 2;
  nyd_grid = (struct nyd_truck ***) 
    malloc (num_lanes * sizeof (void*));
  for (i = 0; i < num_lanes; i++)
    nyd_grid[i] = (struct nyd_truck**) calloc (num_positions, sizeof (void*));
  nyd_last_action_illegal = NO;
}


/* Functions for manipulating the world in a low-level way. */

struct nyd_truck *
nyd_truck_create (int speed, int color)
{
  struct nyd_truck *t = 
    (struct nyd_truck *) malloc (sizeof (struct nyd_truck));
  t->speed = speed;
  t->color = color;
  return t;
}

void
nyd_truck_destroy (struct nyd_truck *t)
{
  free (t);
}

void
nyd_add_truck (struct nyd_truck *t, int lane, int position)
{
  if (lane == 0 || lane == nyd_num_lanes-1)
    NYD_ERROR ("Can't put truck on the shoulder");
  //  assert (nyd_grid[lane][position] == NULL);
  nyd_grid[lane][position] = t;
}

int
nyd_truck_in_lane (int lane)
{
  int p;
  for (p = 0; p < nyd_num_positions; p++)
    if (nyd_grid[lane][p])
      return YES;
  return NO;
}

struct nyd_truck *
nyd_truck_at_position (int lane, int p)
{
  return nyd_grid[lane][p];
}

void
nyd_add_random_truck ()
{
  /* xxx This function can choose new truck positions that make it
     impossible for the agent to avoid a collision. */
  int lane = 0;
  int position = 0;
  int speed = nyd_min_truck_speed;
  struct nyd_truck *t;
  int retry_count = 0;

  /* Decide if it will be a fast or slow truck. */
  if ([randomGenerator getDoubleSample] < nyd_fast_truck_probability)
    speed = nyd_max_truck_speed;

  /* Set which horizon it will appear on, depending on its speed. */
  if (speed < 0)
    position = nyd_num_positions-1;

  /* We return here when the position we choose for the new truck is
     already occupied. */
try_lane_again:
  retry_count++;
  if (nyd_fast_truck_probability > 0)
    {
      /* This assumes that there are six lanes, truck lanes (1,2,3,4) */
      int laner = [uniformIntRand getIntegerWithMin: 0 
				    withMax: 9];
      if (speed == -1)
	{
	  //  assert (nyd_num_lanes-3);
	  switch (laner) 
	    {
	    case 0:
	    case 1:
	    case 2:
	    case 3:
	      lane = 4;
	      break;
	    case 4:
	    case 5:
	    case 6:
	      lane = 3;
	      break;
	    case 7:
	    case 8:
	      lane = 2;
	      break;
	    case 9:
	      lane = 1;
	      break;
	    }
	}
      else if (speed == 1)
	{
	  switch (laner) 
	    {
	    case 0:
	    case 1:
	    case 2:
	      lane = 1;
	      break;
	    case 3:
	    case 4:
	    case 5:
	      lane = 2;
	      break;
	    case 6:
	    case 7:
	      lane = 3;
	      break;
	    case 8:
	    case 9:
	      lane = 4;
	      break;
	    }
	}
      else
	NYD_ERROR("speed out of range");
    }
  else
    {
      lane = [uniformIntRand getIntegerWithMin: 1 
				    withMax: (nyd_num_lanes - 2)];
    }
  //  assert (lane > 0 && lane < nyd_num_lanes);
  //assert (position == 0 || position == nyd_num_positions-1);
  if (nyd_grid[lane][position])
    {
      if (retry_count > 20)
	return;
      goto try_lane_again;
    }

  t = nyd_truck_create (speed, [uniformIntRand getIntegerWithMin: 0 
				    withMax: (NYD_NUM_TRUCK_COLORS - 1)]);
  nyd_add_truck (t, lane, position);
}

void nyd_add_trucks ()
{
  if ([randomGenerator getDoubleSample] <= nyd_new_truck_probability)
    {
      nyd_add_random_truck ();
      if (nyd_double_truck_probability > 0)
	if ([randomGenerator getDoubleSample] <= nyd_double_truck_probability)
	  nyd_add_random_truck ();
    }
}

void
nyd_update_trucks ()
{
  int speed;
  int i, j;
  /* This implementation assumes there are only two speeds, -1, and +1 */
  /* First move all the fast trucks, then move all slow trucks. */
  speed = +1;
  for (j = nyd_num_positions-1; j >= 0; j--)
    for (i = 0; i < nyd_num_lanes; i++)
      {
	struct nyd_truck *t = nyd_grid[i][j];
	if (!t || t->speed != speed)
	  continue;
	{
	  int lane = i;
	  int position = j;
	  nyd_grid[i][j] = NULL;
	  /* Move truck by speed */
	  position += t->speed;
	  if (position < nyd_num_positions && position >= 0)
	    {
	      if (nyd_grid[lane][position])
		{
		  /* This could happen when faster trucks reach slower trucks */
		  /* This implementation assumes there are only two possible
		     speeds, -1, and +1. */
		  /* The truck we are meeting couldn't be a fast truck, otherwise
		     (b/c of for loop) it would already be out of the way */
		  if (nyd_grid[lane][position]->speed == -1)
		    t->speed = -1; /* We're now stuck behind a slow truck. */
		  nyd_grid[i][j] = t;  /* Put us back where we were. */
		}
	      else if (position+1 < nyd_num_positions
		       && nyd_grid[lane][position+1] 
		       && nyd_grid[lane][position+1]->speed == -1)
		{
		  t->speed = -1; /* We're now stuck behind a slow truck. */
		  // assert (!nyd_grid[lane][position]);
		  nyd_grid[lane][position] = t;
		}
	      else if (lane == nyd_agent_lane
		       && position == nyd_agent_position)
		{
		  //	  assert (!nyd_grid[lane][position-1]);
		  nyd_grid[lane][position-1] = t;
		}
	      else
		nyd_grid[lane][position] = t;
	    }
	  else
	    nyd_truck_destroy (t);
	}
      }
  /* Now move all the slow trucks. */
  speed = -1;
  for (j = 0; j < nyd_num_positions; j++)
    for (i = 0; i < nyd_num_lanes; i++)
      {
	struct nyd_truck *t = nyd_grid[i][j];
	if (!t || t->speed != speed)
	  continue;
	{
	  int lane = i;
	  int position = j;
	  nyd_grid[i][j] = NULL;
	  position += t->speed;
	  if (position < nyd_num_positions && position >= 0)
	    {
	      if (nyd_grid[lane][position])
		{
		  /* This can happen when faster trucks reach slower trucks */
		  /* This implementation assumes there are only two possible
		     speeds, -1, and +1. */
		  //	  if (nyd_grid[lane][position]->speed == -1)
		  //  assert (!nyd_grid[lane][position-1]);
		  nyd_grid[lane][position-1] = t;
		}
	      else
		nyd_grid[lane][position] = t;
	    }
	  else
	    nyd_truck_destroy (t);
	}
      }
}

void
nyd_update ()
{
  nyd_update_trucks ();
  nyd_add_trucks ();
}

void nyd_place_agent (int lane, int position)
{
  if (lane == 0 || lane == nyd_num_lanes-1)
    NYD_ERROR ("Can't put agent on the shoulder");
  nyd_agent_lane = lane;
  nyd_agent_position = position;
}

int
nyd_position_of_next_truck (int lane, int position)
{
  int p;
  for (p = position; p < nyd_num_positions; p++)
    if (nyd_grid[lane][p])
      {
	return p;
      }
  return nyd_num_positions-1;
}

int
nyd_position_of_prev_truck (int lane, int position)
{
  int p;
  for (p = position; p >= 0; p--)
    if (nyd_grid[lane][p])
      {
	return p;
      }
  return 0;
}

int
nyd_horn_is_blowing ()
{
  struct nyd_truck *t_behind = nyd_grid[nyd_agent_lane][nyd_agent_position-1];
  return ((t_behind && t_behind->speed > 0)
	  ?
	  YES : NO);
}

/* Functions for doing the agent's overt actions. */

void
nyd_agent_right_action ()
{
  nyd_last_action_illegal = NO;
  if (nyd_agent_lane >= nyd_num_lanes-2)
    nyd_last_action_illegal = YES;
  else {
    if (nyd_grid[nyd_agent_lane+1][nyd_agent_position])
      nyd_last_action_illegal = YES;
    else
      nyd_agent_lane++;
  }
}

void nyd_agent_left_action ()
{
  nyd_last_action_illegal = NO;
  if (nyd_agent_lane <= 1)
    nyd_last_action_illegal = YES;
  else {
    if (nyd_grid[nyd_agent_lane-1][nyd_agent_position])
      nyd_last_action_illegal = YES;
    else
      nyd_agent_lane--;
  }
}

void nyd_agent_straight_action ()
{
  nyd_last_action_illegal = NO;
  if (nyd_grid[nyd_agent_lane][nyd_agent_position])
    nyd_last_action_illegal = YES;
  /* This can leave the agent truck and a truck on top of each other.
     xxx Is this what we want? */
}










