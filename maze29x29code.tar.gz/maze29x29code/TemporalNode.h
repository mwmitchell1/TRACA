#import <collections.h>
#import "NaryNode.h"
#import "Node.h"
#import "boolean.h"

@interface TemporalNode : NaryNode 
{
     id terminalGroup;
     int checkForCopy;
     boolean okToFire;
     boolean secondInputMatchedNow;
     boolean firstInputMatchedNow;
     boolean firstInputMatchedLast;
     boolean acceptingMessages;
     boolean waitingOnSecondInput;
     boolean waitingOnFirstInput;
     boolean resetChain;
     boolean lastResetChain;
     double discountedTerminalValue;
     double temporalQreturn;
     boolean temporallyFired;
     boolean temporallyMatched;
     boolean temporallyRealActive;
}

+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-realDeactivate;
-(boolean) getResetChain;
-(boolean) getLastResetChain;
-(void) checkSuspendedInputs;
-checkCreateTemporalOk;
-match: (boolean) aBoolean by: (Node *) aNode;
-sendPredictorsReturn;
-sendFrequency;
-payTemporalReturn: (double *)  paymentPtr;
-updateValueEstimate;
-sendTemporalReturn;
-sendPreviousReturn;
-sendPreviousCorrect: (boolean) aBoolean;
-sendCorrect;
-(double) getDiscountedTerminalValue;
-(double) getAbsDiscountedTerminalValue;
-sendIncorrect;
-(boolean) setMatched: (boolean) aBoolean;
-notifyPrediction;
-checkSupress;
-checkActiveTemporalSupress; 
-checkTemporalSupress; 
-checkUpdateTemporalSupress; 
-supress;
-checkNarySupress;
-narySupressInputs;
-narySupress;
-(boolean) getTemporallyMatched;
-temporalSupress;
-updateTemporalSupress;
-supressInputs;
-temporalSupressFirstInput;
-updateTemporalSupressFirstInput;
-checkActiveSupress;
-activeTemporalSupress;
-activeSupress;
-activeSupressInput;
-activeTemporalSupressFirstInput;
-(boolean) getSecondInputMatchedNow;
-isTemporal;
-addAsPreviousTo: (id) aNode;
-copy: (id) aZone;
-preFire;
-fire;
-sendActivePredictiveSupport;
-correct;
-chainCorrect: (boolean) aBoolean;
-incorrect;
-temporalCorrect;
-setWaitingOnSecondInput: (boolean) aBoolean;
-setWaitingOnFirstInput: (boolean) aBoolean;
-setAcceptingMessages: (boolean) aBoolean;
-setFirstInputMatchedNow: (boolean) aBoolean;
-(boolean) getFirstInputMatchedNow;
-(boolean) getFirstInputMatchedLast; 
-(boolean) getAcceptingMessages;
-(boolean) getWaitingOnSecondInput;
-(boolean) getWaitingOnFirstInput;
-(boolean) checkOwnerWaitingOnSecondInput;
-(boolean) checkOwnerPrimaryFired;
-getGroupSuspendedOwnerList;
-getGroupTemporalOwnerList;
-getGroupActiveOwnerList;
-(boolean) checkSecondInputMatched;
-correct;
-(boolean) getTemporallyFired;
-resetTemporallyFired;
-payReturn: (double *)  paymentPtr;
-setTemporallyFired: (boolean) aBoolean;
-setTemporallyMatched: (boolean) aBool;
-(boolean) getTemporallyRealActive;
-setSecondInputMatchedNow: (boolean) aBoolean;
@end





