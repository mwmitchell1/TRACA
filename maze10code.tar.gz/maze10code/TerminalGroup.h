#import "Node.h"
#import "PredictorNode.h"
#import "DetectorNode.h"
#import "NaryNode.h"
#import "TemporalNode.h"
#import "UnaryNode.h"
#import "AgentModelSwarm.h"
#import "boolean.h"
#import "NodeGroup.h"

// a node group is a node which contains a collection of nodes
// That is, it implements the protocol of a node that can be predicted
// but in fact interfaces between one node and the group it contains.
// A group is created when a node is copied and the inputs to the 
// copy are identical, even if the prediction is different.
// This way any node which predicted the original node now predicts the copy 
// also, although this is transparent to it because its prediction has 
// actually been replaced by a node group, which forwards its messages  

// Its main purpose isto balance payments to predictors nodes, and copy the 
// predictors of one node to the copied node therefore preventing the
// need to rediscover its preceedor. 

@interface TerminalGroup : NodeGroup 
{
  id temporalGroup;
  int chainCorrectCount;
  boolean predictionPassedFlag;
}

+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-setPredictionPassedFlag: (boolean) aBoolean;
-(boolean) getPredictionPassedFlag;
-setNode: (id) aNode;
-setFirstNode: (id) aNode;
-setTopGroup: (id) aGroup;
-(int) getChainCorrectCount;
-incrementChainCorrectCount;
-getTopGroup;
-setTemporalGroup: (id) aGroup;
-getTemporalGroup;
-(double) getGroupDependentReturn;
-(double) getTemporalOwnerReturn;
-notifyPreviousGroupsChainCorrect: (boolean) aBoolean;
-addToConnectList;
-preventTemporalConnect;
-payPredictors;
-pay: (double *) paymentEach;
-addToTemporalConnectList;
-createTerminalProxy: (id) aNode;
-sendPreviousReturn;
-sendTemporalReturn;
-isTerminalGroup;
-removeTopGroup;
-setInputsSuspended;
-inhibitInputNodes;
-setSuspended: (boolean) aBoolean;
-(boolean) setMatched: (boolean) aBoolean;
-remove;
-removeSelf: (id) aNode;
@end



