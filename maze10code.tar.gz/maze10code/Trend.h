#import "EnvironmentSwarm.h"
#import <objectbase/SwarmObject.h>
#import "boolean.h"
#import "Double.h"

@interface Trend : SwarmObject
{
  id observations;
  id inputObservations;
  int maxObservations;
  int observationCount;
  int totalObservations;
  int totalInputObservations;
  id agentModel;
  double significance;
  int middleCount;
  int arrayStart;
  boolean trendExists;
  boolean changed;
  boolean printing;
  boolean removed;

  int plus;
  int minus;
  float signif;
}

+createBegin: aZone;
-setAgentModel: (id) aModel;
-setMaxObservations: (int) obs; 
-setSignificance: (double) aDouble;
-createEnd;
-buildObjects;
-addObservation: (double) obs;
-addInputObservation: (double) obs;
-(boolean) enoughObservations;
-(boolean) trendExists;
-(boolean) trendExistsForThis;
-(double) binomial: (int) obs totalObsFac: (double) totalObsFac totalObs: (int) totalObs prob: (double) aProb; 
-(double) cumulativeBinomial: (int) obs totalObs: (int) totalObs prob: (double) aProb;
-(double) factorial: (double) n; 
-(double) power: (double) mantissa to: (double) exponent;
-calculateMiddle;
-printOn;
-printThisTrendOn;
-(boolean) isTrendUp;
-(boolean) isConverging;
-(int) getTotalObservations;
-(double) getTruncatedObs: (double) obs;
-removeSelf;
@end




