#import "Node.h"
#import "PredictorNode.h"
#import "NaryNode.h"
#import "NodeGroup.h"
#import "TemporalNode.h"
#import "AgentModelSwarm.h"
#import <collections.h>
#import <gui.h>
#import <random.h>
#import <stdio.h>

extern boolean classify;

@implementation Node

/*  Note: the node number must be set in the createBegin stage 

 Also X and Y coordinates need to be set, this is not checked for in createEnd.
*/

+createBegin: (id) aZone
{
  Node * obj;
  
  obj = [super createBegin: aZone]; 
  
  obj->rewardStrength = 0;
  obj->Qreturn = 0;
  obj->hypQreturn = 0;
  obj->realActive = False;
  obj->lastRealActive = False;
  obj->previousRealActive = False;
  
  obj->hypActive = False;
  obj->hypActiveSupressed = False;
  obj->hypLastActiveSupressed = False;
  obj->hypSupressed = False;
  obj->hypActivePredictorCount=0;
  obj->hypSuspendedPredictorCount = 0;
  obj->hypMatched = False;
  
  obj->matched = False;
  obj->suspended = False;
  obj->supressed = False;
  obj->narySupressed = False;
  obj->temporallySupressed = False;
  obj->activeTemporallySupressed = False;
  obj->lastActiveTemporallySupressed = False;
  obj->lastTemporallySupressed = False;
  obj->activeSupressed = False;
  obj->activeActionSupressed = False;
  obj->lastActiveActionSupressed = False;
  obj->lastActiveSupressed = False;
  obj->updateTemporalSupressed = False;
  obj->activePredictorCount=0;
  obj->suspendedPredictorCount=0;
  obj->removed = False;  
  obj->predictorCount=0;     
  obj->nodeGroup=nil;
  obj->proxyGroup=nil;
  obj->copy=False;
  obj->nodeNumber = 0;
  
  return obj;
}

-(boolean) setNodeNumber: (long) aNumber
{
    return (nodeNumber = aNumber);
}

-createEnd
{	
   if (nodeNumber <= 0)
       [InvalidCombination raiseEvent: "Node Number not set"];
    return [super createEnd];
}

-(long) getNodeNumber
{ 
    return nodeNumber;
}

-buildObjects 
{
  // the activeOwnerList and suspendedOwnerList
  // are used by non-proxy nodes.  Non proxynodes do
  //  really need a proxyOwner list, as they use the 
  // proxyNodes list of proxyOwners.  Except for
  // detector nodes, which do not have a proxyNode.

  activeOwnerList = [List create: [self getZone]];
  finalTerminalOwnerList = [List create: [self getZone]];
  suspendedOwnerList = [List create: [self getZone]];
  predictorList = [List create: [self getZone]];
  activePredictorList = [List create: [self getZone]];
  passivePredictorList = [List create: [self getZone]];
  suspendedPredictorList = [List create: [self getZone]];
  proxyOwnerList = [List create: [self getZone]];
  temporalOwnerList = [List create: [self getZone]];
  hypPredictorList = [List create: [self getZone]];
  hypActivePredictorList = [List create: [self getZone]];
  hypSuspendedPredictorList = [List create: [self getZone]];
  hypPassivePredictorList = [List create: [self getZone]];
  
  return self;
}

-realDeactivate
{

  if ([agentModel getDebug])
    printf("\n Node %ld realDeactivate", nodeNumber);

   [self clearPredictors]; 
   previousRealActive = lastRealActive;
   lastRealActive = realActive;

   if ([agentModel getDebug])
     printf("\n Node %ld setting previousRealActive to: %d lastRealActive to: %d, matched: %d",
	    nodeNumber, previousRealActive, lastRealActive, matched);
   [self setRealActive: [self getMatched]];
   
   if (matched)  // leave this line or it stuffs up temporal nodes
     [self setMatched: False];

   [self setSupressed: False];
   [self setNarySupressed: False];
   [self setTemporallySupressed: False]; 

   [self setUpdateTemporalSupressed: False];

   return self;
}

-clearPredictors
{
   [activePredictorList removeAll];   
   [passivePredictorList removeAll];
   [suspendedPredictorList removeAll];

   activePredictorCount=0;
   suspendedPredictorCount = 0;

   return self;
}

-match: (boolean) aBoolean
{
   // Pass this message to owners who will update predictive strength 
   // if boolean is True, and reward strength based on the reward. 
   // Predictive nodes call co nect to make connections based on correctness  
   // or incorrectness or predictors

  return self;
}

// pay some percentage of the reward just received to predictors

// This needs to e looked at, when a system reward is received all nodes
// active (just fired) should receive an equal share of the reward.
// Otherwise, nodes just pass back some percentage of their strength
// (as done here).

-hypPayPredictors
{

    float payment=0, realPayment=0, hypPayment = 0;


// Share in strength is passed back to predictors.  This is done through 
// the node group which predicts nodes in itself.  First the strength
// is set in the group, similar to getReward, only for each node in the group.
// This strength is then divided among nodes predicting the group.

    if (nodeGroup == nil)
        return self;

    if (hypActive && !hypLastActiveSupressed)
        return self;          
 
    payment = realPayment + hypPayment;
    
    if ([agentModel getDebug])
        printf("\n node %ld hyp about to pay predictors", nodeNumber); 
    if (!hypActiveSupressed) {
       if ((hypActivePredictorCount > 0) 
         || (hypSuspendedPredictorCount > 0))
       {

          hypStrength = hypStrength - hypPayment;

          if ([agentModel getDebug])
              printf("\n node %ld hyp paying predictors amount: %f", 
                       nodeNumber, payment); 

          if (([hypActivePredictorList getCount] > 0) ||
             ([hypSuspendedPredictorList getCount] > 0))
          {
              [nodeGroup setHypStrength: &payment];
              [nodeGroup hypPayPredictors];
          } 
       }
       else
          hypStrength = hypStrength - hypPayment;
    }

    return self;
}


-sendPredictorsReturn
{
    double payment=0;

// Share in strength is passed back to predictors.  This is done through 
// the node group which predicts nodes in itself.  First the strength
// is set in the group, similar to getReward, only for each node in the group.
// This strength is then divided among nodes predicting the group.

//  Payments are made whether a node has predictors or not.  If it doesn't
//  the payments go to no-one.  This is to stop newly created nodes
//  gaining a sudden high payment for just being first.

    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    if (nodeGroup == nil)
        return self;
 
    if ([agentModel getDebug])
      printf("\nNode %ld group: %ld recieved sendPredictorsReturn", 
	     nodeNumber, [[self getGroup] getNodeNumber]);

    if ([agentModel getEndOfTrial]) // && [self respondsTo: M(isUnary)])
    {
      if ([agentModel getDebug])
	fprintf(stdout,"\n Node::sendPredictorsReturn: End of Trial, node %ld returning", nodeNumber);
      return self;
    }

    // June 10 - don't send return until had enough trials
    // Sept 2 2002 -
    // if (![self respondsTo: M(isUnary)]) {
      if ([(PredictorNode *) self getOwnActivationCount] 
	  < [agentModel getActivationThreshold])
	return self;
      // }
    

    if ([agentModel getDebug])
      printf(" active.");
  
    // April 4 2002 - don't send return if you predict yourself.
    if ([(PredictorNode *) self getPrediction] == [self getGroup])
      return self;
     
    // May 19 2000 - changed independentValue to dependentValue
    // Oct 6 2000 - include dependent specificity
    payment = [(PredictorNode *) self getDependentValue];
    // Dec 12 2000 - removed next line. 
    //                   * (1 - [(PredictorNode *)self getDependentAccuracy]); 
 
    // July 4 2002 - don't send zero. return.
    // Aug 12 2002 - group will send zero!
    if (activeSupressed || activeTemporallySupressed) {
      if ([agentModel getDebug])
	printf("\n node : %ld active supressed or temporalsupressed", 
	       nodeNumber);
      return self;
    }

    // April 15 2002 - changed following:
    if ([self getMatched]
	&& ![(PredictorNode *) self getTemporallySuspended])
      {
       	if ([agentModel getDebug])
	  printf("\n node %ld group: %ld sendingPredictors return: %f  activeSupressed: %d, matched %d", nodeNumber, 
		 [nodeGroup getNodeNumber], payment, 
		 [self getActiveSupressed],
		 matched);
	// Mar 26 2002
	// April 15 2002 - changed following:
	[nodeGroup setReturnStrength: &payment];
	
	// Dec 4 2002:
	[agentModel setReturnStrength: &payment];
      }
    
    return self;
}


-hypSendPredictorsReturn
{
    double payment=0;
    double realPayment=0;
    double hypPayment=0;


// Share in strength is passed back to predictors.  This is done through 
// the node group which predicts nodes in itself.  First the strength
// is set in the group, similar to getReward, only for each node in the group.
// This strength is then divided among nodes predicting the group.


//  Payments are made whether a node has predictors or not.  If it doesn't
//  the payments go to no-one.  This is to stop newly created nodes
//  gaining a sudden high payment for just being first.


    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    if (nodeGroup == nil)
        return self;

    if (hypActive && !hypLastActiveSupressed)
       return self;
    payment = realPayment + hypPayment;
 

    if (([self getHypMatched]) && (!hypSupressed)) 
      if (([activePredictorList getCount] > 0) 
	  || ([suspendedPredictorList getCount] > 0))
	{
	  if ([agentModel getDebug])
	    printf("\n node %ld group: %ld about to pay hyp strength: %f  activeSupressed: %d", nodeNumber, 
		   [nodeGroup getNodeNumber], payment, hypActiveSupressed);
	  {
	    [nodeGroup hypSetReturnStrength: &payment];
	  } 
        }

    return self;
}

-getActiveOwnerList
{
// overridden in nary node
    return activeOwnerList;
}

-getSuspendedOwnerList
{
// overridden in nary node
    return suspendedOwnerList;
}

-connect
{

   if (([activePredictorList getCount] > 0) || 
        ([suspendedPredictorList getCount] > 0) ||
        ([passivePredictorList getCount] > 0))
   {
     if ([agentModel getLearning])
       [self connectAndActive];
   }

   return self;
}

-temporalConnect
{

  if (![agentModel getLearning])
    return self;

  // June 23 - added suspendedPredictorList
 if ([agentModel getDebug])
   fprintf(stdout, "\n Node %ld group: %ld activePredictorList: %d, suspendedPredictorList: %d, matched: %d, createOk: %d",
	   nodeNumber,
	   [[self getGroup] getNodeNumber],
	   [activePredictorList getCount],
	   [suspendedPredictorList getCount],
	   matched, [agentModel getCreateTemporalOk]);

 // if it is not ok to create a temporal chain return. May 1 2000.

  if ([agentModel getCreateTemporalOk] == False)
    return self;

  if (([activePredictorList getCount] > 0)
       || ([suspendedPredictorList getCount] > 0))
  {
      // Nov 29 2000 - allow for temporal nodes to connect 
      if ([self respondsTo: M(isTemporal)]) {
	if ([(TemporalNode *) self getFirstInputMatchedNow])
	  [self temporalConnectActive];
      } 
      else 
      {
	if (matched)   // July 20 - changed matched to !matched 
	  [self temporalConnectActive];
      }
  }
  else {
    if ([agentModel getDebug])
      fprintf(stdout, "\n Node %ld not doing temporalConnect as was not predicted incorrectly", nodeNumber);
  }

  return self;
}

-connectAndActive
{
   id tempList;
   int count;

// Include all active predictions.

// Dont include all active predictors, as 
// some may have been supressed, in another nodes connect
// sequence between predicting and its connect.
// This will prevent duplicates for the same state

   tempList = [List create: [self getZone]];  

// Except those with a predictiveHistory of 1.0
// In fact if an active predictor has a predictive history of 1.0
// we have a correct predictor, remove all other predictors
        
   if ([[self getGroup] getAccuratelyPredictedOk]) {
     if ([agentModel getDebug])
       printf("\n %ld returning self - accurately predicted", nodeNumber);
     return self;
   }
   
 // Apr 17 2001 - Here we use the presence of suspendedPredictors to determine
 // whether new combinations should be made.  If we have a  
 // suspendedPredictor, we should see if it predicts us accurately before
 // creating more.
 // If we have a good enough activePredictor we would have exited in the 
 // loop above. (unless we want to allow not connections)
 // We are interested in suspended predictors which are suspended, 
 // rather than supressed.     

   count = [suspendedPredictorList getCount];
   if (count > [agentModel getMaxPredictorCount])
     return self; 

   if ([agentModel getDebug])
       printf("\n In connect and active, predictorList: %d suspendedList: %d", 
	      [activePredictorList getCount],
	      [suspendedPredictorList getCount]);

// Also include nodes which have suspended owners which have not fired
// (only nodes with no active owners).
// An alernative way to do this is to allow nodes to fireUnlessOwnerActive
// until an activeOwner is added, except in this case the strength will be
// used to support effectors 


   // CHANGE HERE

   count = [activePredictorList getCount];
   while (count > 0)
   {
       count--;
       if ([agentModel getDebug])
	 printf("\n Active Node: %ld, suspneded: %d, narySupressed: %d",
	      [[activePredictorList atOffset: count] getNodeNumber],
	      [[activePredictorList atOffset: count] getSuspended],
	      [[activePredictorList atOffset: count] getNarySupressed]);

       // Subordinate nodes may be included here if excluded from
       // nary supression.

       if (![[[activePredictorList atOffset: count] 
		  getGroup] getRemoved]
	   // June 24 - may have been narysupressed since it made a prediction
	   // if used already in another AND created this timestep.
	   && ![[activePredictorList atOffset: count] getNarySupressed]
	   && ![[[activePredictorList atOffset: count] getGroup] isTopGroup])
	 // Terminal nodes are not included unless !suspended in which 
	 // case a final node has been determined.
	 [tempList addLast: [activePredictorList atOffset: count]]; 
   }

   // Allows !NarySupressed nodes to be joined?
  
   /*
  count = [suspendedPredictorList getCount];
   while (count > 0)
   {
       count--;
       if ([agentModel getDebug])
	 printf("\n Suspended Node: %ld, supressed: %d, narySupressed: %d",
		[[suspendedPredictorList atOffset: count] getNodeNumber],
		[[suspendedPredictorList atOffset: count] getSupressed],
		[[suspendedPredictorList atOffset: count] getNarySupressed]);

       if (![[suspendedPredictorList atOffset: count] getSuspended]
	   // June 18 2002 - leave this as nodes that are
	   // activetemporally supressed are left in connectList so they
	   // can be used for temporal chains is a chain is not followed.
	   && ![[[suspendedPredictorList atOffset: count] getGroup]
		  getActiveTemporallySupressed]
	   && ![[[suspendedPredictorList atOffset: count] getGroup]
		  getActiveSupressed]
	   && ![[[suspendedPredictorList atOffset: count] getGroup] 
		 getRemoved]
	   && ![[suspendedPredictorList atOffset: count] getNarySupressed])
	 [tempList addLast: [suspendedPredictorList atOffset: count]]; 
   }
   */
   
   
   [self connectAnd: tempList];

   [tempList drop];

   return self;
} 

-temporalConnectActive
{
   id tempList;
   int count;

   // Oct 2 2002 - replaced tempList with tempNode
   id tempNode = nil;

   // Oct 2 2002 - select best predictor for crating chains.

   double bestAccuracy = 0;

// Include all active predictions.

// Dont include all active predictors, as 
// some may have been supressed, in another nodes connect
// sequence between predicting and its connect.
// This will prevent duplicates for the same state

// Except those with a predictiveHistory of 1.0
// In fact if an active predictor has a predictive history of 1.0
// we have a correct predictor, remove all other predictors
   // Nodes which are already predicted by temporalChains will be 
   // prevented from creating others by preventTemporalConnect.

   // Oct 2 2002 - also prevent if accuratelyPredictedOk.

   if ([[self getGroup] getAccuratelyTemporallyPredictedOk] || 
       [[self getGroup] getAccuratelyPredictedOk]) {
     if ([agentModel getDebug])
       printf("\n %ld returning self - accurately predicted", nodeNumber);
     return self;
   }

   if ([agentModel getDebug])
       printf("\n In temporal connect active for node:%ld group: %ld", 
	      nodeNumber, [[self getGroup] getNodeNumber]);

// Also include nodes which have suspended owners which have not fired
// (only nodes with no active owners).
// An alernative way to do this is to allow nodes to fireUnlessOwnerActive
// until an activeOwner is added, except in this case the strength will be
// used to support effectors 

   tempList = [List create: [self getZone]];  

   count = [activePredictorList getCount];
   while (count > 0)
   {
       count--;

   if ([agentModel getDebug])
     fprintf(stdout,"\n Checking if active node:%ld accuracy: %f",
	     [[activePredictorList atOffset: count] getNodeNumber],
	     [[activePredictorList atOffset: count] getDependentAccuracy]);
	    
   if ((([[activePredictorList atOffset: count] getSuspended] == False))
 //	|| ([[activePredictorList atOffset: count] respondsTo: M(isUnary)]))
       && ![[activePredictorList atOffset: count] respondsTo: M(isTemporal)]
       // Oct 24 2002 - allow terminal predictors 
       // && ![[activePredictorList atOffset: count] respondsTo: M(isTerminal)]
       // Only create if predictor has been wrong
       && (([[activePredictorList atOffset: count] getDependentAccuracy]
	    + [agentModel getVariance])
	   < 1.0)
       && !([[activePredictorList atOffset: count] getGroup]
           == [self getGroup])
       )
     { 
       // Oct 2 2002 - select best predictor perhaps probabilistically another
       // node.
       if ([[activePredictorList atOffset: count] getIndependentValue]
	   > bestAccuracy) {
	 tempNode = [activePredictorList atOffset: count];
	 bestAccuracy = [[activePredictorList atOffset: count] 
			  getIndependentValue]; 
       }
     }
   }

   // Nodes which made suspended predictions ONLY because they
   // were temporallySupressed can be added to connect active list.
   
   count = [suspendedPredictorList getCount];
   while (count > 0)
   {
       count--;

       if ([agentModel getDebug])
	 fprintf(stdout,"\n Checking if suspended node:%ld accuracy: %f",
	     [[suspendedPredictorList atOffset: count] getNodeNumber],
	     [[suspendedPredictorList atOffset: count] getDependentAccuracy]);
     
       if (([[suspendedPredictorList atOffset: count] getSuspended] == False)
	   // Oct 5 2000 - changed supressed to activeSupressed
       
	   && ([[suspendedPredictorList atOffset: count] getActiveSupressed] 
	       == False)
       && ([[suspendedPredictorList atOffset: count] getActiveActionSupressed] 
	       == False)
	   // Oct 24 2002 - allow terminal predictors 
	   //	   && ![[suspendedPredictorList atOffset: count] 
	   //	 respondsTo: M(isTerminal)]
	   && ![[suspendedPredictorList atOffset: count] 
		 respondsTo: M(isTemporal)]
	   && ([[suspendedPredictorList atOffset: count] 
		 getDependentAccuracy] < 1.0)
	   && !([[suspendedPredictorList atOffset: count] getGroup]
	   	== [self getGroup])
	   )
	 { 
	   // Oct 2 2002 - select best predictor:
	   if ([[suspendedPredictorList atOffset: count] getIndependentValue]
	       > bestAccuracy) {
	     tempNode = [suspendedPredictorList atOffset: count];
	     bestAccuracy = [[suspendedPredictorList atOffset: count] 
			      getIndependentValue]; 
	   }
	 }
   }

   if ([agentModel getDebug])
       printf("\n Temp list count: %d", [tempList getCount]);

   // Oct 2 2002 - if tempNode!= nil
   //    if ([tempList getCount] > 0)
   if (tempNode != nil)
     [self connectTemporal: tempNode];
   
   [tempList drop];
   
   return self;
} 

-connectAnd: (id) tempList
{
 
  // This code could be more efficient 
  
  id tempNode=nil;
  id otherNode=nil;
  
  int count;
  int tempIndex;
  
  count = [tempList getCount];
  
  while (count > 1)
    {
      tempIndex  = [uniformIntRand getIntegerWithMin: 0 
				   withMax: ([tempList getCount] -1)];

      tempNode = [tempList atOffset: tempIndex];
      [tempList remove: tempNode];
      
      tempIndex  = [uniformIntRand getIntegerWithMin: 0 
				   withMax: ([tempList getCount] -1)];

      otherNode = [tempList atOffset: tempIndex];
      [tempList remove: otherNode];
      // May 8 2002 - don't connect two temporal groups
      if (!([tempNode respondsTo: M(isTerminal)]
	    && [otherNode respondsTo: M(isTerminal)])
	  && !([tempNode respondsTo: M(isTemporal)]
	       && [otherNode respondsTo: M(isTemporal)]))
	[self connect: tempNode And: otherNode];  
      count = count - 2;    
    }
  
  return self; 
}

// Oct 2 2002 - changed tempList to tempNode:

-connectTemporal: (id) tempNode
{
  
  // the difference between connect and and connectTemporal is that
  // one list contains groups and the other nodes.  AndConnect
  // uses only nodes. 
    
  id otherNode=nil;

  id newNode = nil;   
  int tempIndex;
  int count = 0;
  double bestValue = 0;

  id newList = [List create: [self getZone]];

  newList = [[agentModel getLastExtendList] copy: [self getZone]];

  if ([agentModel getDebug]) {
    printf("\n In connectTemporal for Node: %ld, lastExtendList size: %d",
	   nodeNumber, [newList getCount]); 
    fflush(stdout);
  }

  if ([newList getCount] == 0)
    return self;
  
  /*
  Oct 2 2002 - there is now only one node selected in calling 
               method
  tempIndex  = [uniformIntRand getIntegerWithMin: 0 
			       withMax: ([tempList getCount] - 1)];

  tempNode = [tempList atOffset: tempIndex];

  */
  
 if ([agentModel getDebug])
  fprintf(stdout, "\n Node: %ld group: %ld doing temporal connect. predictor count: %d",
	  nodeNumber, [[self getGroup] getNodeNumber], [newList getCount]); 

 /*

  tempIndex  = [uniformIntRand getIntegerWithMin: 0 
			       withMax: ([newList getCount] - 1)];

 */

 // Select the node which best predicts the node closest the prediction:

 count = [newList getCount];
 while (count > 0) {
   count--;
   if (([[[newList atOffset: count] getPrediction] getNodeNumber] 
	== [[tempNode getGroup] getNodeNumber])
       && ([[newList atOffset: count] getIndependentValue] >
	   bestValue))
     {
       bestValue = [[newList atOffset: count] getIndependentValue];
       otherNode = [newList atOffset: count];
     }
 }

 if (otherNode != nil) 
   [self connectTemporal: otherNode And: tempNode];  
 
 [newList drop];
 
 return self; 
}

-temporalExtend
{
  
  id otherList, newList;
  id otherNode=nil;
  int tempIndex, count;

  id newNode = nil;
  id inputNode = nil;
  double bestValue = 0;
  
  if (![agentModel getLearning])
    return self;

 
  if (![(TemporalNode *) self getFirstInputMatchedNow])
    return self;
 

 //  if ([agentModel getDebug])
  /*
  if ([[self getGroup] getNodeNumber] == 1020) {
 
   fprintf(stdout,"\n Node: %ld doing temporal extend. 
                                firstInputMatchedNow: %d time: %d",
	    nodeNumber, [(TemporalNode *) self getFirstInputMatchedNow],
	    getCurrentTime());  
    [agentModel stop];
  }
    */

  otherList = [[agentModel getExtendList] copy: [self getZone]];
  newList = [List create: [self getZone]];

  inputNode = [[[(NaryNode *) self getInputList] getFirst] getNode];
  
  if ([agentModel getDebug])
    fprintf(stdout, "\n Node: %ld doing temporal extend. otherList count: %d",
	    nodeNumber, [otherList getCount]);  
  
  count = [otherList getCount];
  while (count > 0)
    {
      count--;
      if ([agentModel getDebug])
	  printf("\n node %ld, adding to other list. Suspended: %d, isTerminal: %d, lastActiveSupressed: %d", 
		 [[otherList atOffset: count] getNodeNumber], 
	     [[otherList atOffset: count] getSuspended],
		 [[otherList atOffset: count] respondsTo: M(isTerminal)],
	  [[otherList atOffset: count] getLastActiveSupressed] );

      if (![[otherList atOffset: count] getLastActiveActionSupressed]
	  && ![[otherList atOffset: count] getLastActiveSupressed])
	{
	// Oct 2 2002 - select node which best predicts this node's input:

	  if ([[[otherList atOffset: count] getPrediction] getNodeNumber] 
	      == [[inputNode getGroup] getNodeNumber])
	    if ([[otherList atOffset: count] getIndependentValue] >
		bestValue) {
	      bestValue = [[otherList atOffset: count] getIndependentValue];
	      // Oct 2 2002 - replace newList with newNode
	      newNode = [otherList atOffset: count]; 
	    }
	}
    }
  
  if ([agentModel getDebug])
    fprintf(stdout, "\n Node: %ld doing temporal extend. newList count: %d",
	    nodeNumber, [newList getCount]); 
   
      //  if ([newList getCount] == 0)
  if (newNode == nil)
    return self;
      
  //  tempIndex  = [uniformIntRand getIntegerWithMin: 0 
  //			       withMax: ([newList getCount] - 1)];

  //  otherNode = [newList atOffset: tempIndex];

  [self extendTemporal: newNode];  
  
  [otherList drop];
  [newList drop];
  
  return self; 
}

-extendTemporal: (id) node1 
{
  TemporalNode * node;
  
  if ([agentModel getDebug])
    printf("\n Creating new Node in extend temporal");
  
  node = [TemporalNode createBegin: [agentModel getZone]];
  [node setGrid: grid];
  [node setX: 0 Y: (y + 1)];
  [node setColor: color];
  [node setModel: agentModel];
  [node setNodeNumber: [agentModel getNextNodeNumber: node]];
  node = [node createEnd]; 
  
  [node buildObjects];
  
  // Here is a problem, connect AND always has two nodes which predict
  // the same node, connect temporal doesn't ??
  
  // April 13 2000 - changed following line to use proxyNode rather than node 
  [node addInput: [[node1 getGroup] getProxyNode] AsOn: True];
  // April 13 2000 - add to proxy not self
  [node addInput: [[self getGroup] getProxyNode] AsOn: True];
  
  [(PredictorNode *) node setPrediction:
		       [(PredictorNode *) self getPrediction]];
  
  [(TemporalNode *) node createGroup]; 

  if ([[node getGroup] getNodeNumber] == 8066) {
    //      || [[node getGroup] getNodeNumber] == 2718) {
    printf("\n created group: %ld at time: %d", 
	   [[node getGroup] getNodeNumber], getCurrentTime());
    fflush(stdout);
  }
  
  // Set the terminal node for the new group
  [[node getGroup] setTerminalGroup: [[(PredictorNode *) 
					self getGroup] getTerminalGroup]]; 
  
  // reset the topGroup for the terminal node to this new node's group
  // the terminalnode is a proxy, get its group, then set the top
  // group for the firstnode in that group (the non-copy node).
  
  [(TerminalGroup *)[[(TemporalNode *) self getGroup] getTerminalGroup] 
		    setTopGroup: [node getGroup]];
  
  if ([agentModel getDebug])
    fprintf(stdout,"\n Extended temporal node %ld set topGroup to: %ld",
	    [[node getGroup] getNodeNumber], 
	    [[[node getGroup] getTopGroup] getNodeNumber]);
  
  
  // Tell new group it is top.
  [(NodeGroup *)[node getGroup] setTopGroup: True];
  // Tell the old group (the group of the current node) it is not top
  [(NodeGroup *) [self getGroup] setTopGroup: False];     
  
  // Temporal Nodes need to have any new nodes added as owners, so that
  // they can send back support to these nodes.
  
   //   [node addAsPreviousTo: [[[(NaryNode *)self getInputList] 
  //                atOffset: 1] getNode]];  
  
  [node addAsPreviousTo: self]; 
  
  [node setFired: True];
  [node setCorrect: False];
  [node setRealActive: True];
  
  // Feb 1 2001 - set realactive false rather than true
  [[node getGroup] setRealActive: False];
  [[node getGroup] setPreFired: True];
  [node setPredictionType: suspendedType];  // defined in .def file
  
  [[[node getGroup] getProxyNode] setMatched: False];
  [[[node getGroup] getProxyNode] setFirstInputMatchedNow: False];
  [[[node getGroup] getProxyNode] setSecondInputMatchedNow: False];
  [[[node getGroup] getProxyNode] setWaitingOnFirstInput: False];
  [[[node getGroup] getProxyNode] setWaitingOnSecondInput: True];
  [[[node getGroup] getProxyNode] setAcceptingMessages: True];
  
  [[[node getGroup] getProxyNode] addInput: 
				    [[node1 getGroup] getProxyNode] AsOn: True];
  [[[node getGroup] getProxyNode] addInput: self AsOn: True];
  
  // difference here and with AND nodes, is that the *actual nodes* have 
  // the new proxy node as an owner whereas in ANDs, the *proxy* has the new 
  // node as an owner. 
  // This is because temporal chains are based on action sequences.

  [[[node1 getGroup] getProxyNode] addProxyOwner: [[node getGroup] 
						    getProxyNode]];
  
  // Jun 27 - remove this - use temporalOwner list for
  // nodes prior in the chain. 

  //  [self addProxyOwner: [[node getGroup]
  //		 getProxyNode]]; 
  
  // Keep a separate list for messages down chain.

  [self addTemporalOwner: [[node getGroup]
			 getProxyNode]]; 

  // April 13 2000 - Add node to proxy not actual input
  [[[node1 getGroup] getProxyNode] addSuspendedOwner: node];
  [[[self getGroup] getProxyNode] addSuspendedOwner: node];  
  
  [(TemporalNode *) node setSupported: 
		      [(PredictorNode *) node1 getSupported]];

  [[node getGroup] setPrimaryNode: node];

  if ([agentModel getCopyValues])
      // Oct 5 2000 - added:
    [node copyValues: node1];  
  
  // Note: we are adding to the list while traversing it, however, 
  // this will be placed last
  
  [agentModel addNode: node];
  
  // supress your inputs so they are not used in other temporal connections
  // as a duplicate of your self.
  
  [[node getGroup] checkTemporalSupress];

  // reset temporalActivationCount -
  //  July 12 2002 - for all nodes in group

  [[[self getGroup] getTerminalGroup]  resetTemporallyActivated];
  
  if ([agentModel getDebug])
     printf("\n Temporal Node: %ld, finished temporal extend. topGroup: %ld,\n finalGroup: %d, suspended: %d activeTemporallySupressed: %d\n activated: %d, temporallySupressed: %d,\n firstinputmatchednow: %d,\n waitingonSecond: %d, waitingOnFirst: %d, matched: %d",
	    nodeNumber, [[[self getGroup] getTopGroup] getNodeNumber], 
	    [[self getGroup] getFinalGroup], suspended,
	    [[[self getGroup] getProxyNode] getActiveTemporallySupressed],
	    [[self getGroup] getTemporallyActivated],
	    [[[self getGroup] getProxyNode] getTemporallySupressed],
	    [[[self getGroup] getProxyNode] getFirstInputMatchedNow],
	    [[[self getGroup] getProxyNode] getWaitingOnSecondInput],
	    [[[self getGroup] getProxyNode] getWaitingOnFirstInput],
	    matched);

  return node;
} 

-connectTemporal: (id) node1 And: (id) node2 
{
  TemporalNode * node;
  id valueNode;
  id tempNode;

  // Once a temporal chain is created, do not create another one this cycle
  // May 1 2000.
  [agentModel setCreateTemporalOk: False];
  
  node = [TemporalNode createBegin: [agentModel getZone]];
  [node setGrid: grid];
  [node setX: 0 Y: (y + 1)];
  [node setColor: color];
  [node setModel: agentModel];
  [node setNodeNumber: [agentModel getNextNodeNumber: node]];
  node = [node createEnd]; 
  
  [node buildObjects];
  
  // Here is a problem, connect AND always has two nodes which predict
  // the same node, connect temporal doesn't ??
  
  // April 13 - added proxynode as input instead of actual node
  [node addInput: [[node1 getGroup] getProxyNode] AsOn: True]; 
  [node addInput: [[node2 getGroup] getProxyNode] AsOn: True];
  
  [node setPrediction: proxyGroup];
  
  [node createGroup]; 

   if ([agentModel getDebug]) {
     // if ([[self getGroup] getNodeNumber] == 40) {
    printf("\n Node Group 40 Creating new Node in connect temporal ANd group created: %d", [[node getGroup] getNodeNumber]);
    fflush(stdout);
    printf("\n first node group: %ld, 2nd group: %ld", 
	   [[node1 getGroup] getNodeNumber], 
	   [[node2 getGroup] getNodeNumber]);
  }


  [node setFired: False];
  [node setCorrect: True];
  // April 13 - setting this to true
  [node setRealActive: True];
 
  [[node getGroup] setRealActive: True];
  [(NodeGroup *)[node getGroup] setTopGroup: True];
  // April 13 - setting this to False
  [[[node getGroup] getProxyNode] setMatched: False];
  
  [[[node getGroup] getProxyNode] addInput: [[node1 getGroup] getProxyNode] 
				  AsOn: True];
  [[[node getGroup] getProxyNode] addInput: [[node2 getGroup] getProxyNode] 
				  AsOn: True];
  
  // First level temporal nodes are added as previous to the terminal group
  // of the chain so they can receive rewards.
  
  [node addAsPreviousTo: [[node getGroup] getTerminalNode]];
  
  // difference here and with AND nodes, is that the *actual nodes* have 
  // the new proxy node as an owner whereas in ANDs, the *proxy* has the new 
  // node as an owner. 
  // This is because temporal chains are based on action sequences.
  
  // May 3 2000 - Wrong, add as proxy owner to proxynode
  [[[node1 getGroup] getProxyNode] 
    addProxyOwner: [[node getGroup] getProxyNode]];
  
  if ([agentModel getDebug])
    printf("\n just added proxyOwners for 1st input %ld. Owner count: %d", 
	   [node1 getNodeNumber], [[node1 getProxyOwnerList] getCount]);
  
  [node2 addProxyOwner: [[node getGroup]
			  getProxyNode]]; 

  if ([agentModel getDebug])
    printf("\n just added proxyOwners for 2nd input %ld. Owner count: %d", 
	   [self getNodeNumber], [[node1 getProxyOwnerList] getCount]);
  
  // April 13 2000 - add node as owner to proxynode not actual node
  
  [[[node1 getGroup] getProxyNode] addSuspendedOwner: node];
  [[[node2 getGroup] getProxyNode] addSuspendedOwner: node];  
  
  [(TemporalNode *) node setSupported: 
		      [(PredictorNode *) node1 getSupported]];

  // Temporal Groups should have only one node.
  
  [[node getGroup] setPrimaryNode: node];

  // Note: we are adding to the list while traversing it, however, 
  // this will be placed last
  
  [agentModel addNode: node];
  
  // Feb 16 2000 - added this as inputs may be matched again when 
  // AND is constructed
  // Actually, not sure how this should work for temporal nodes, may be ok.
  //    if ([node1 getMatched] && [node2 getMatched])
  //   [[node getGroup] setMatched: True];
  
  [self addPredictor: node];
  
  // supress your inputs so they are not used in other temporal connections
  // as a duplicate of your self.
  
  // Removed following line. It didn't work anyway.
  // [[node getGroup] checkTemporalSupress];
  
  // Dec 1 as per next comment, now ask the prediction to copy
  // the terminal node to predict it:
  // remove this if we change NodeGroup::createTemporalproxy to
  // make that a real predictive node.  

  [(NaryNode *) self copyPredictor: 
		  [[[[node getGroup] 
		      getTerminalNode] getGroup] getFirstNode]]; 

  // Nov 22 2000 - set first node in terminal group to second node
  // as the first is really a dummy.

  [[[[node getGroup] getTerminalNode] getGroup] setFirstNode:  
	[[[[[node getGroup] getTerminalNode] getGroup] getNodeList] 
	  atOffset: 1]]; 
  
  /* Dec 1, don't do this for initial temporal nodes, as action was one
     timestep ago, this code is therefore removed and a terminal node
     is created to make the prediction given the last action selected.
     This is necessary as before although a terminal group was created
     no predictor nodes were until next time chain was executed. 
     With the way it is now chains will be immediately removed
     if they have no predictive terminal nodes as the other nodes
     don't copy input's strengths and therefore don't pass the 
     comparison test. 
     
  */
  

 // Dec 20 2000 - set independentValue nad dependentValue to
  // predictions average return + average reward. The use of the average 
  // here should help overcome distortion (i.e only recieves a high pay-off
  // very rarely.
  // The primary purpose of this is to allow early comparison of terminal
  // nodes strengths with predictions.
  
  tempNode= [[[[node getGroup] getTerminalNode] getGroup] getFirstNode];

  //  [tempNode setDependentValue: [[self getGroup] getAverageReinforcement]];
  [tempNode setIndependentValue: [agentModel getInitialQvalue]];
  //  [tempNode setDependentValue: [agentModel getInitialQvalue]];

  // Feb 1 2000 - uncommented and modified the following code
  // Nov 28 2000 - changed following to copy values for terminal node

  // Oct 5 2000 - added:
  if ([agentModel getCopyValues]) {
    tempNode= [[[[node getGroup] getTerminalNode] getGroup] getFirstNode];
    valueNode = [[node1 getGroup] findSimilarTerminalNode: node];
    if (valueNode != nil)
      [tempNode copyValues: valueNode];
  }

  // May 25 2000
  // Added code to check if firstinput is matched now, if it is
  // set firstInputMatchedNow to prevent duplicates.

  if ([[[node1 getGroup] getProxyNode] getMatched]) {
    [[[node getGroup] getProxyNode] setWaitingOnFirstInput: False];
    [[[node getGroup] getProxyNode] setWaitingOnSecondInput: True];
    [[[node getGroup] getProxyNode] setAcceptingMessages: False];
    [[[node getGroup] getProxyNode] setFirstInputMatchedNow: True];
  }

 // Nov 28 - copy average strength of prediction
  //  [[[[[node getGroup] getTerminalNode] getGroup] getFirstNode]
  //  setIndependentValue: ([[self getGroup] getAverageReturn]
  //			  + [[self getGroup] getAverageReward])];
  //if ([agentModel getDebug])
  //  printf("\n TerminalNode %ld setting indep val to prediction's: %f",
  //	   [[[[node getGroup] getTerminalNode] getGroup] getFirstNode]);

  return node;
} 

-connect: (id) node1 And: (id) node2 
{
  NaryNode * node;
  id valueNode = nil;
  
  if ([agentModel getDebug]) {
    printf("\n Creating new Node in connect AND first node: %ld, 2nd: %ld", 
	   [node1 getNodeNumber], [node2 getNodeNumber]);
    fflush(stdout);

    printf("\n first node group: %ld, 2nd group: %ld", 
	   [[node1 getGroup] getNodeNumber], 
	   [[node2 getGroup] getNodeNumber]);
  }


  node = [NaryNode createBegin: [agentModel getZone]];
  [node setGrid: grid];
  [node setX: 0 Y: (y + 1)];
  [node setColor: color];
  [node setModel: agentModel];
  [node setNodeNumber: [agentModel getNextNodeNumber: node]];
  node = [node createEnd]; 
  
  [node buildObjects];
  
  [node addInput: node1 AsOn: True];
  [node addInput: node2 AsOn: True];
  
  [node setPrediction: proxyGroup];
  
  [(NaryNode *) node createGroup]; 

  /*
  if ((([[node1 getGroup] getNodeNumber] == 15) 
      && ([[node2 getGroup] getNodeNumber] == 20))
    || (([[node1 getGroup] getNodeNumber] == 20) 
	&& ([[node2 getGroup] getNodeNumber] == 15)))
      printf("\nCreating group to lookleft and see shoulder: %ld", 
	     [[node getGroup] getNodeNumber]);

  if ((([[node1 getGroup] getNodeNumber] == 17) 
      && ([[node2 getGroup] getNodeNumber] == 20))
     || (([[node1 getGroup] getNodeNumber] == 20) 
	 && ([[node2 getGroup] getNodeNumber] == 17)))
      printf("\nCreating group to lookright and see shoulder: %ld", 
	     [[node getGroup] getNodeNumber]);
  */

  if ([agentModel getDebug])
    printf("\n New group created: %ld", [[node getGroup] getNodeNumber]);

  [node setFired: True];
  [node setCorrect: True];
  [node setRealActive: True];
  
  [[node getGroup] setRealActive: True];
  
  [[[node getGroup] getProxyNode] setMatched: False];
  
  [[[node getGroup] getProxyNode] addInput: [[node1 getGroup]
					      getProxyNode] AsOn: True];
  [[[node getGroup] getProxyNode] addInput: [[node2 getGroup] 
					      getProxyNode] AsOn: True];
  
  [[[node1 getGroup] getProxyNode] addProxyOwner: [[node getGroup] 
						    getProxyNode]];
  
  [[[node2 getGroup] getProxyNode] addProxyOwner: [[node getGroup]
						    getProxyNode]]; 
  
  // June 6 2001 - add suspended owners to proxyNode

  [[[node1 getGroup] getProxyNode] addSuspendedOwner: node];  
  [[[node2 getGroup] getProxyNode] addSuspendedOwner: node];

  [node1 addSuspendedOwner: node];
  [node2 addSuspendedOwner: node];  
  
  // July 15 - added the following, nodes were being removed in monk 3 
  // before they
  // had a chance to improve on inputs (alternative is to allow long 
  // activationThresholds). In actual fact, this doesn't seem to  
  // helps anything, but it didn't seem to do any harm so I am leaving it.
  if ([node1 getAbsIndependentValue] > [node2 getAbsIndependentValue])
    valueNode = node1;
  else
    valueNode = node2;


 // Dec 20 2000 - set independentValue nad dependentValue to
  // predictions average return + average reward. The use of the average 
  // here should help overcome distortion (i.e only recieves a high pay-off
  // very rarely.
  // The primary purpose of this is to allow early comparison of terminal
  // nodes strengths with predictions.
  
  // [node setDependentValue: [[self getGroup] getAverageReinforcement]];
  //  [node setDependentValue: [agentModel getInitialQvalue]];
  [node setIndependentValue: [agentModel getInitialQvalue]];

  if ([agentModel getCopyValues])
      [node copyValues: valueNode];

  // Feb 16 2000 - added this as inputs may be matched again when 
  // AND is constructed
  if ([node1 getMatched] && [node2 getMatched])
    [[node getGroup] setMatched: True];
  
  [(NaryNode *) node setSupported: [(PredictorNode *) node1 getSupported]];
  
  // Note: we are adding to the list while traversing it, however, 
  // this will be placed last
  
  [agentModel addNode: node];
  
  [self addPredictor: node];
  
  // supress your inputs so they are not used in other ANDS
  // as a duplicate of your self.
  
  //  [[node getGroup] checkSupress];
  // June 20 2002 - prevent inputs being used for AND's again this cycle
  [[[node getGroup] getProxyNode] narySupress];
  
  return node;
} 

-(boolean) addPredictor:  (id) aNode
{
  if (aNode == nil)
    return False;
  
  if (aNode == proxyGroup)
    printf("\n Warning: proxy node %ld added own group as predictor",
	   nodeNumber);
  
  [predictorList addLast: aNode];
  
  return True;	
}

-getPredictorList
{
   if (nodeGroup == nil)
   {
       return predictorList;
   }
   else
   {
       return [nodeGroup getPredictorList];
   }
}

-(boolean) removePredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  [predictorList remove: aNode];
  [self clearPassivePredictor: aNode];
  [self clearActivePredictor: aNode];
  [self clearSuspendedPredictor: aNode];
  return True;
}


-(boolean) activePredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  
  [activePredictorList addLast: aNode];
  activePredictorCount++;
  
  return True;
}
	
-(boolean) passivePredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  
  [passivePredictorList addLast: aNode];
  return True;
}

-(boolean) suspendedPredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  suspendedPredictorCount++;
  [suspendedPredictorList addLast: aNode];
  return True;
}

-(boolean) clearActivePredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([activePredictorList contains: aNode])
    [activePredictorList remove: aNode];
  return True;
}

-(boolean) clearPassivePredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([passivePredictorList contains: aNode])
    [passivePredictorList remove: aNode];
  return True;
}

-(boolean) clearSuspendedPredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([suspendedPredictorList contains: aNode])
    [suspendedPredictorList remove: aNode];
  return True;
}

// Oct 24 2002 - added proxy only responds to these messages:

-addFinalTerminalOwner: (id) anOwner {

  int count = 0;
  id tempList;

  // If a terminal group is added for the first time,
  // remove any temporal chains whose final node is 
  // on you. 
  
  if ([finalTerminalOwnerList getCount] == 0) {
    tempList = [proxyOwnerList copy: [self getZone]];
    [[tempList atOffset: count] removeIfFinalTemporal];
  }

  [finalTerminalOwnerList addLast: anOwner];
  return self;
}

// Oct 24 2002 - added

-removeFinalTerminalOwner: (id) anOwner {
  if ([finalTerminalOwnerList contains: anOwner])
    [finalTerminalOwnerList remove: anOwner];
  return self;
}

-getFinalTerminalOwnerList {
  return finalTerminalOwnerList;
}

-addActiveOwner: (Node *) aNode
{

  if (aNode == nil)
    return self;

  // owners are initially added as active 
  // this allows them to influence system behaviour
  
  [[self getActiveOwnerList] addLast: aNode];

  return self;
}


-addProxyOwner: (id) aNode
{
  if ([agentModel getDebug])
    printf("\n Node :%ld adding proxyOwner: %ld", nodeNumber, 
	   [aNode getNodeNumber]);

  [[self getProxyOwnerList] addLast: aNode];
  return self;
} 

-removeProxyOwner: (id) aNode
{
  [[self getProxyOwnerList] remove: aNode];
  return self;
}

-getProxyOwnerList
{
  if (proxyGroup != nil)	
    return proxyOwnerList;
  return [[nodeGroup getProxyNode] getProxyOwnerList];
} 

-addTemporalOwner: (id) aNode
{
  if ([agentModel getDebug])
    printf("\n Node :%ld adding temporalOwner: %ld", nodeNumber, 
	   [aNode getNodeNumber]);

  [[self getTemporalOwnerList] addLast: aNode];
  return self;
} 

-removeTemporalOwner: (id) aNode
{
  [[self getTemporalOwnerList] remove: aNode];
  return self;
}

-getTemporalOwnerList
{
  if (proxyGroup != nil)	
    return temporalOwnerList;
  return [[nodeGroup getProxyNode] getTemporalOwnerList];
} 

-addSuspendedOwner: (id) aNode
{
  if (aNode == nil)
    return self;

  if ([agentModel getDebug])
    printf("\n node %ld adding suspended owner", nodeNumber);

  [[self getSuspendedOwnerList] addLast: aNode];
  return self;
}

-removeSuspendedOwner: (id) aNode
{
  if (aNode == nil)
    return self;
  
  // this could be cleaned up to search first
  
  [[self getSuspendedOwnerList] remove: aNode];
  return self;
}

-removeActiveOwner: (id) aNode
{
  if (aNode == nil)
    return self;

 // This next line is a precaution - see moveSuspendedOwner.

  if (nodeGroup != nil) {
    [[nodeGroup getProxyNode] removeActiveOwner: aNode];
  }

  // this could be cleaned up to search first
  
  [[self getActiveOwnerList] remove: aNode];
  return self;
}

-(boolean) removeOwner: (Node *) aNode
{

  // The if statement is neccesary as certain conditions in removing
  // owners (i.e if you send a message to your owner to removeitself
  // after you have already removed yourself  
  
  if ([[self getSuspendedOwnerList] contains: aNode])
    [[self getSuspendedOwnerList] remove: aNode];
  if ([[self getActiveOwnerList] contains: aNode]) 
    [[self getActiveOwnerList] remove: aNode];
  if ([[self getProxyOwnerList] contains: aNode])
    [[self getProxyOwnerList] remove: aNode];
  if ([[self getTemporalOwnerList] contains: aNode])
    [[self getTemporalOwnerList] remove: aNode];

  // Because nary node moveSuspended copies active owners to proxyNode's
  // we need the following line

  if (nodeGroup != nil) {
    [[nodeGroup getProxyNode] removeActiveOwner: aNode];
  }

 if (nodeGroup != nil) {
    [[nodeGroup getProxyNode] removeSuspendedOwner: aNode];
  }

  return True;
}


-(boolean) setNarySupressed: (boolean) aBoolean
{
  // overridden in nary node
  return supressed;
}


-(boolean) setSupressed: (boolean) aBoolean
{

  // overridden in nary node
  return supressed;
}

-(boolean) setTemporallySupressed: (boolean) aBoolean
{

  // overrridden in nary node
  return temporallySupressed;

}

-(boolean) resetActiveSupressed: (boolean) aBoolean
{
 
   lastActiveSupressed = activeSupressed;
   activeSupressed =  aBoolean;

   return activeSupressed;
}

-(boolean) setActiveSupressed: (boolean) aBoolean
{
 
   if (proxyGroup != nil)
     if ([proxyGroup getActiveSupressed] != aBoolean)
       [proxyGroup setActiveSupressed: aBoolean];

   activeSupressed =  aBoolean;

   return activeSupressed;
}

-(boolean) resetActiveActionSupressed: (boolean) aBoolean
{
  lastActiveActionSupressed = aBoolean;
  activeActionSupressed = aBoolean;

  return activeActionSupressed;
}

-setActiveActionSupressed: (boolean) aBoolean for: (id) anEffector
{
 
   if (proxyGroup != nil)
     [(NodeGroup *) proxyGroup setActiveActionSupressed: 
		      aBoolean for: anEffector];
   else
     if ([(PredictorNode *) self getSupported] == anEffector)
       activeActionSupressed = aBoolean;

   return self;
}

-(boolean) resetActiveTemporallySupressed: (boolean) aBoolean
{
  lastActiveTemporallySupressed = activeTemporallySupressed;
  activeTemporallySupressed = aBoolean;
  return activeTemporallySupressed;
}

-(boolean) setActiveTemporallySupressed: (boolean) aBoolean
{
  if (proxyGroup != nil)
    // Nov 15 2000 - removed following
    if ([proxyGroup getActiveTemporallySupressed] != aBoolean)
      [proxyGroup setActiveTemporallySupressed: aBoolean];

  activeTemporallySupressed = aBoolean;
  return activeTemporallySupressed;
}


-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean
{
  
  // overridden in nary node 
  return updateTemporalSupressed;
}

-(boolean) getUpdateTemporalSupressed
{

  // overridden in nary node
  return updateTemporalSupressed;
}

-(boolean) getNarySupressed
{ 
  // overridden in nary node
  return narySupressed;
}

-(boolean) getSupressed
{
  
  // overridden in nary node
  return supressed;
}

-(boolean) getTemporallySupressed
{
  
  // overridden in nary node  
  return temporallySupressed;
}

-(boolean) getActiveSupressed
{
  return activeSupressed;
}


-(boolean) getActiveActionSupressed
{
  return activeActionSupressed;
}


-(boolean) getLastActiveSupressed
{
  return lastActiveSupressed;
}

-(boolean) getLastActiveActionSupressed
{
  return lastActiveActionSupressed;
}

-(boolean) getActiveTemporallySupressed
{
  return activeTemporallySupressed;
}

-(boolean) getLastActiveTemporallySupressed
{
  return lastActiveTemporallySupressed;
}

-removeSuspended
{
  if ((suspended == True) && [self respondsTo: M(isNary)])
    [(NaryNode *) self removeSelf: nil];
  return self;
}

-(boolean) isSuspended
{
  return ([(PredictorNode *) self getSuspended]);
}

-(boolean) setRealActive: (boolean) aBoolean
{
  // overridden in nary nodes
  realActive = aBoolean;
  return realActive;
}

-(boolean) getRealActive
{
  // overridden in nary node
  return realActive;
}

-(boolean) getLastRealActive
{
  return lastRealActive;
}

-(boolean) setPreviousRealActive: (boolean) aBoolean
{
  // overridden in nary nodes
  previousRealActive = aBoolean;
  return previousRealActive;
}

-(boolean) getPreviousRealActive
{
  return previousRealActive;
}

- (boolean) setX: (int) newX Y: (int) newY
{
  int maxX = 0, maxY = 0;
  
  if ([self getGrid] != nil) {
    maxX =  [[self getGrid] getSizeX];
    maxY =  [[self getGrid] getSizeY];
  }
  
  if (newX >= maxX || newY >= maxY)
    return False;
  x = newX;
  y = newY;
  return True;
}

-printOwners
{

  printf("\n -------- Node %ld, printing owners:", nodeNumber);
  
  printf("\n\t Active Owners:");
  [[self getActiveOwnerList] forEach: M(printNodeNumber)];
  printf("\n\t Suspended Owners:");
  [[self getSuspendedOwnerList] forEach: M(printNodeNumber)];
  printf("\n ---------- finished");
  
  return self;
}

-printNodeNumber
{
   printf("\n Owner node node Number: %ld", nodeNumber);
   return self;
}

-printMatched
{
  printf("\n====* PRINTMATCHED Node Number: %ld, Matched %d",
	 nodeNumber,[ self getMatched]);
  return self;
}

-setModel: (id) aModel
{
  agentModel = aModel;
  return self;
}

-getModel
{
  return agentModel;
}

-temporalUpdate
{
  // see NodeGroup.m setMatched for description 
  
  [predictorList forEach: M(temporalCorrect)];
  return self;
}

-temporalCorrect
{
  // Most nodes are not temporal, so do not do anything here.  
  // This is overridden in TemporalNode.m to give desired behaviour.

  return self;
}


-(boolean) getMatched
{
  return matched;   
}

-(boolean) setMatched: (boolean) aBoolean
{
  // overridden in Nary nodes to use groups (unary nodes too)
  // this is for the proxied node in groups.
  
   matched = aBoolean;
   return matched;
}

-getGrid
{
  return grid;
}

-setGrid: (id) aGrid
{
  grid = aGrid;
  return self;
}

-setColor: (int) aColor
{
  color = aColor;
  return self;
}

-(int) getActivePredictorCount
{
  return activePredictorCount;
}

-getActivePredictorList
{
  if (nodeGroup != nil)
    return [nodeGroup getActivePredictorList];
  else
    return activePredictorList;
}

-getSuspendedPredictorList
{
  if (nodeGroup != nil)
    return [nodeGroup getSuspendedPredictorList];
  else
    return suspendedPredictorList;
}

-getPassivePredictorList
{
  if (nodeGroup != nil)
    return [nodeGroup getPassivePredictorList];
  else
    return passivePredictorList;
}

-incrementPredictorCount
{
   predictorCount++;
   return self;
}

-setRaster: (id <Raster>) aRaster
{
   raster = aRaster;
   return self;
}

-getProxyGroup
{
   return proxyGroup;
}

-setProxyGroup: (id) aGroup
{
  proxyGroup = aGroup;
  return self;
}


-drawSelfOn: (id <Raster>) aRaster 
{
  [aRaster drawPointX: x Y: y Color: color];
  return self;
}

-(void) die
{

  [predictorList drop];
  [activePredictorList drop];
  [suspendedPredictorList drop];
  [activeOwnerList drop];
  [finalTerminalOwnerList drop];
  [proxyOwnerList drop];
  [temporalOwnerList drop];
}

-(boolean) reset
{
  //    lastTemporallySupressed=False;
  //  lastActiveSupressed=False;
  //  lastActiveTemporallySupressed=False;
  //  activeTemporallySupressed = False;

  lastActiveActionSupressed = False;
  lastActiveSupressed=False;
  lastActiveTemporallySupressed=False;
  activeSupressed = False;
  activeTemporallySupressed = False;
  activeActionSupressed = False;
  [self setUpdateTemporalSupressed: False];
  matched = False;
  lastRealActive = False;
  realActive = False;
  return True;
}

-getGroup
{
   if (nodeGroup == nil)
       return proxyGroup;
   return nodeGroup;
}

-(boolean) getCopy
{
  return copy;
}

-printOn
{
  /* not yet implemented */
  return self;
}


-getHypActivePredictorList
{
    if (nodeGroup != nil)
        return [nodeGroup getHypActivePredictorList];
    else
        return hypActivePredictorList;
}

-getHypSuspendedPredictorList
{
    if (nodeGroup != nil)
        return [nodeGroup getHypSuspendedPredictorList];
    else
        return hypSuspendedPredictorList;
}

-getHypPassivePredictorList
{
    if (nodeGroup != nil)
        return [nodeGroup getHypPassivePredictorList];
    else
        return hypPassivePredictorList;
}


-(boolean) hypActivePredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  
  [hypActivePredictorList addLast: aNode];
  hypActivePredictorCount++;
 
  return True;
}
	
-(boolean) hypPassivePredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  
  [hypPassivePredictorList addLast: aNode];
  return True;
}

-(boolean) hypSuspendedPredictedBy: (Node *) aNode
{
  if (aNode == nil)
    return False;
  hypSuspendedPredictorCount++;
  [hypSuspendedPredictorList addLast: aNode];
  return True;
}

-(boolean) clearHypActivePredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([hypActivePredictorList contains: aNode])
    [hypActivePredictorList remove: aNode];
  return True;
}

-(boolean) clearHypPassivePredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([hypPassivePredictorList contains: aNode])
    [hypPassivePredictorList remove: aNode];
  return True;
}

-(boolean) clearHypSuspendedPredictor: (Node *) aNode
{
  if (aNode == nil)
    return False;
  if ([hypSuspendedPredictorList contains: aNode])
    [hypSuspendedPredictorList remove: aNode];
  return True;
}

-clearHypPredictors
{
  [hypActivePredictorList removeAll];   
  [hypPassivePredictorList removeAll];
  [hypSuspendedPredictorList removeAll];
  
  hypActivePredictorCount=0;
  hypSuspendedPredictorCount = 0;
  
  return self;
}

-(double) getHypStrength
{
   return hypStrength;
}

-(boolean) setHypSupressed: (boolean) aBoolean
{

// overridden in nary node

  hypSupressed = aBoolean;
  return hypSupressed;
}


-(boolean) setHypActiveSupressed: (boolean) aBoolean
{

// overridden in nary node
  if (proxyGroup != nil)
    if ([proxyGroup getHypActiveSupressed] != aBoolean)
      [proxyGroup setHypActiveSupressed: aBoolean];
  hypLastActiveSupressed = hypActiveSupressed;
  hypActiveSupressed = aBoolean;
  return hypActiveSupressed;
}

-(boolean) getHypSupressed
{

// overridden in nary node

   return hypSupressed;
}


-(boolean) getHypActiveSupressed
{
  return hypActiveSupressed;
}

-(boolean) getHypMatched
{
  return hypMatched;   
}

-(boolean) setHypMatched: (boolean) aBoolean
{
  // overridden in Nary nodes to use groups (unary nodes too)
  // this is for the proxied node in groups.
  
   hypMatched = aBoolean;
   return matched;
}


-(boolean) hypActivate
{

  if ([self getHypMatched] == True)
    [self setHypActive: True];   
  else
    [self setHypActive: False];
  
  return [self getHypActive];
}


-(boolean) setHypActive: (boolean) aBoolean
{
 // overridden in nary nodes
  hypActive = aBoolean;
  return hypActive;
}

-(boolean) getHypActive
{

// overridden in nary node

  return hypActive;
}


-(boolean) hypDeactivate
{

  [self setHypActive: [self getHypMatched]];
  [self clearHypPredictors];
  if (hypActive == False) 
    [self setHypActive: [self getHypMatched]];
  [self setHypMatched: False];
  [self setHypSupressed: False];
  
  return False;
}

-hypReset
{
  hypStrength = 0;
  [self setHypActive: [self getHypMatched]];
  [self clearHypPredictors]; 
  [self setHypActive: [self getHypMatched]];
  [self setHypMatched: False];
  [self setHypSupressed: False];
  
  hypActiveSupressed = False;
  hypLastActiveSupressed = False;
  return self; 
}

@end













