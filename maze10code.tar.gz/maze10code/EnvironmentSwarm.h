#import "AgentModelSwarm.h"
#import "Cell.h"
#import "Node.h"
#import "stdio.h"
#import "boolean.h"

@interface EnvironmentSwarm  : Swarm
{
	id inputString;
	id lastInputString;
	id problemFile;
	
	id positionArray;
	id gridPositionArray;
	id resetList;

	int trialCount;
	int totalTrialCount;
	int averageMoves;
	boolean test;
	boolean failed;

        id agentModel;
        double reward;
	double bumpPenalty;
	boolean useGoalReward;
	int goalLabel;
	double changeDirectionPenalty;
        int effectorAction;
        int nextAction;

	boolean seeOrientation;

        id <Grid2d> grid;			     // objects representing 
        int cellCount;
        id cellArray;
        int gridXSize, gridYSize;
        int correctCount, predictionCount, incorrectCount;

        FILE *problemfp, *outputfp;

        int agentXpos;
        int agentYpos;
	int totalMoveCount;
	int epochCount;
	int trainingEpochs;

        int rewardXpos;
        int rewardYpos;
	int relocatePosition;
	boolean enumerative;  
	boolean useOrientation;
	boolean localRep;
	boolean useReward;
	boolean endOfTrial;
	int agentPosition;
	int on;

	int moveCount;

	int lastAction;
	int previousAction;
	int lastAgentPosition;
	int orientation;
	int previousOrientation;
}

+createBegin: (id) aZone;
-setAgent: (id) anAgent;
-setString: (char *) aString;
-createEnd;
-buildActions;
-setUpDisplay;
-loadFile;
-(int) readLine: (float[]) array;
-activateIn: (id) swarmContext;
-getGrid;
-getCellArray;
-step;
-update;
-answer;
-(void) convertFrom: (int) anInt to: (id) aString length: (int) length;
-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length;
-getString;
-(float) getPredictiveAccuracy;
-printOn;
-(boolean) getEndOfTrial;
-resetAgentPosition;
-(int) getChangeDirectionPenalty;
-setChangeDirectionPenalty: (int) anInt;
-(boolean) getLocalRep;
-setLocalRep: (boolean) aBool;
-setProblem: (char *) fileName;
-setUseOrientation: (boolean) aBool;
-timeOut;
-setNextAction: (int) anInt;
-(int) getNextAction;
@end






