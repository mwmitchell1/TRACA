#import "EnvironmentSwarm.h"
#import "Cell.h"
#import <collections.h>
#define __USE_FIXED_PROTOTYPES__   // for gcc headers
#include <stdio.h>
#include <strings.h>

extern unsigned int sleep(unsigned int);

@implementation EnvironmentSwarm

+createBegin: (id) aZone
{
   EnvironmentSwarm * obj;
   id <ProbeMap> probeMap;
 
   obj = [super createBegin: aZone];
   obj->reward=20;
   obj->gridXSize=50;
   obj->gridYSize=50;
   obj->on =1;
   obj->last = 3;
   obj->next = 1;
   obj->end=1;
   obj->class=0;
   obj->correctCount=0;
   obj->incorrectCount=0;
   obj->predictionCount=0;
   obj->epochCount=0;
   obj->inputString = [String create: aZone];
   obj->testfile =  [String create: aZone];
   obj->datafile =  [String create: aZone];
   obj->inputFile =  [String create: aZone];
   obj->trainingEpochs=10;
   obj->problem=1;
   // This is used to select different training sets.
   obj->inputFileCount =0;
 
   probeMap = [EmptyProbeMap createBegin: aZone];
   [probeMap setProbedClass: [self class]];
   probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameter
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridXSize"
         			     inClass: [self class]]];
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridYSize"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "trainingEpochs"
 				     inClass: [self class]]]; 
   [probeMap addProbe: [probeLibrary getProbeForVariable: "problem"
 				     inClass: [self class]]]; 
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "printOn"
	 		     inClass: [self class]]
			setHideResult: 1]];

   [probeLibrary setProbeMap: probeMap For: [self class]];

   return obj;
}

-setString: (char *) aString
{
   [inputString setC: aString];
   return self;
}

-setAgent: (id) anAgent
{
   agentModel = anAgent;
   return self;
}

-createEnd
{
   return [super createEnd];
}

-setProblem: (char *) aProblem epochs: (int) anEpoch
{
     problem = atoi(aProblem);
     trainingEpochs = anEpoch;
     return self;
}

-buildObjects {

  int i;

  [super buildObjects];
 
  grid = [Grid2d createBegin: [self getZone]];
  [grid setSizeX: gridXSize Y: gridYSize];
  grid = [grid createEnd];
 
  cellCount =  (gridXSize * gridYSize);
  cellArray = [Array create: [self getZone] setCount: cellCount];

  for (i = 0; i < cellCount; i++) {
    Cell * cell;
  
       // Create the cell, set the creation time variables
    cell = [Cell createBegin: [self getZone]];
    [cell setGrid: grid];
    [cell setX: (i - ((i / gridXSize) * gridXSize)) Y: (i/gridYSize)];
    [cell setModel: self];
     cell = [cell createEnd];
   
    [cell buildObjects];

    [cellArray atOffset: i put: cell];
  }

   // Now go in to the cells and set their colours to green (64)
  // [cellArray forEach: M(setColor:) : (void *) 4];

  switch (problem)
  {
     case 1:
      [datafile setC: "monk1.data"];
      [testfile setC: "monk1.test"];
      break;
    case 2: 
      [datafile setC: "monk2.data"];
      [testfile setC: "monk2.test"];
      break;
    case 3:
      [datafile setC: "monk3.data"];
      [testfile setC: "monk3.test"];
      break; 
    default:
      printf("Warning - no data file specified");
  }

  // open the monks input file

  inputfp = fopen([datafile getC],"r");
  if (inputfp == NULL)
     printf("\n WARNING:  input file not opened");   

  outputfp = fopen("agent.out","a");
  if (outputfp == NULL)
     printf("\n WARNING:  output file not opened");   

  fprintf(outputfp,"Problem number: %d ", problem);

  epochCount++;

  // allocate memory for inputstring
  
   return self;
}


-buildActions {

  [super buildActions];

  return self;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  return [self getSwarmActivity];
}


-getCellArray
{
   return cellArray;
}

-update
{  
 //  must get the position of the selected action from the agent, then update
 //  environment accordingly.   A new input string is then passed 
 //  to the agent along with the reward from the last action.

  char c;

//  int counter=6;

// read in attributes

   end = fscanf(inputfp,"%d%c%d%c%d%c%d%c%d%c%d%c",
           &attrib[0],&c,&attrib[1],&c,&attrib[2],&c,
           &attrib[3],&c,&attrib[4],&c,&attrib[5],&c);

// read in class
   end = fscanf(inputfp,"%d",&class);


  if (end == EOF)
  {
      end = 1;

      fclose(inputfp);
//      sleep(3);

// At the end of training, record details training data to determine accuracy

      if (epochCount == trainingEpochs)
      {
         fprintf(outputfp," Accuracy after %d epochs. Correct: %d, 
                            Incorrect: %d, Total: %d, Accuracy: %f ",
                            trainingEpochs,
                            correctCount,
                            incorrectCount,
                            predictionCount,
                            ((float) correctCount *
                             (100.0 / ((float) predictionCount))));  
         fprintf(outputfp," Nodes created: %ld",
                             [agentModel getNaryCreatedCount]);
         fprintf(outputfp," Current Nodes: %ld",
                            [agentModel getNaryNodeCount]);
         [agentModel setLearning: False];
         [agentModel setDeterministicSelect: True]; 
	 [agentModel setRandomEffectorRate: 0];
	 //	 [agentModel stop];
         correctCount=0;
         incorrectCount=0;
         predictionCount=0;
      }

// Run once on training data without learning to record performance

      if (epochCount == (trainingEpochs + 1))
      {
         fprintf(outputfp,"\n\tAccuracy after %d epochs. Correct: %d, 
                           Incorrect: %d, Total: %d, Accuracy: %f ",
                            trainingEpochs,
                            correctCount,
                            incorrectCount,
                            predictionCount,
                            ((float) correctCount * 
                             (100.0 / ((float) predictionCount)))); 
         [agentModel setTest: True];
         [agentModel setLearning: False];
         [agentModel setDeterministicSelect: True]; 
         [agentModel setUseStrength: True]; 
         correctCount=0;
         incorrectCount=0;
         predictionCount=0;
      }

// Run on test data

      if (epochCount == (trainingEpochs + 2))
      {
         fprintf(outputfp,"\n\tTest Accuracy after %d epochs. Correct: %d, 
                           Incorrect: %d, Total: %d, Accuracy: %f\n",
                            trainingEpochs,
                            correctCount,
                            incorrectCount,
                            predictionCount,
                            ((float) correctCount *
                             (100.0 / ((float) predictionCount)))); 
         fclose(outputfp);
         if ([agentModel getDebug]) 
             [agentModel printOn];
         [agentModel stop]; 
      }

      if ([agentModel getTest])
      {
          if ([agentModel getDebug])
          {
              printf("Doing Test $$$$$$$$");
              printf("\n opening test file:");
          } 
          inputfp = fopen([testfile getC] ,"r");
      }
      else {
	  [inputFile setC: [datafile getC]];
	  switch (inputFileCount) 
	      {
	      case 0:
		  [inputFile catC: "0"];
		  break;
	      case 1:
		  [inputFile catC: "1"];
		  break;
	      case 2:
		  [inputFile catC: "2"];
		  break;
	      case 3:
		  [inputFile catC: "3"];
		  break;
	      case 4:
		  [inputFile catC: "4"];
		  break;
	      case 5:
		  [inputFile catC: "5"];
		  break;
	      case 6:
		  [inputFile catC: "6"];
		  break;
	      case 7:
		  [inputFile catC: "7"];
		  break;
	      case 8:
		  [inputFile catC: "8"];
		  break;
	      case 9:
		  [inputFile catC: "9"];
		  break;
	      case 10:
		  inputFileCount = 0;
		  break;  
	      default:
		  printf("\n WARNING: invalid inputfilecount");
		  fflush(stdout);
	  }

	  inputfp = fopen([inputFile getC],"r");
	  //inputfp = fopen([datafile getC],"r");
	  inputFileCount++;

      }
      epochCount++;

      if (inputfp == NULL)
      {
          printf("\n WARNING:  input file not opened");
          fflush(stdout);
      }
      else
      {  
        end = fscanf(inputfp,"%d%c%d%c%d%c%d%c%d%c%d%c",
           &attrib[0],&c,&attrib[1],&c,&attrib[2],&c,
           &attrib[3],&c,&attrib[4],&c,&attrib[5],&c); 
          // read in class
        end = fscanf(inputfp,"%d",&class);
      }      
  }

  if ([agentModel getDebug])
      printf("\n Class: %d", class);

// convert attribute integer to 4 character binary string

   [inputString setC: ""];

// Remember added an extra 0 further down for binary number input

   [self convertFrom: attrib[0] to: inputString length: 3];
   [self convertFrom: attrib[1] to: inputString length: 3];
    [self convertFrom: attrib[2] to: inputString length: 2];
    //   [self convertFrom: 0 to: inputString length: 2];
   [self convertFrom: attrib[3] to: inputString length: 3];
   //[self convertFrom: 0 to: inputString length: 3];
   //  if (attrib[4] == 1)
     [self convertFrom: attrib[4] to: inputString length: 4];
     //   else
	//  [self convertFrom: 0 to: inputString length: 4];
      [self convertFrom: attrib[5] to: inputString length: 2];
  //[self convertFrom: 0 to: inputString length: 2];  

   [inputString catC:"00"];    
   if ([agentModel getDebug])
       printf("\n ENVIRONMENT: Input String is :%s", [inputString getC]);

   [agentModel setEndOfTrial: False];
   reward = 0;
   [agentModel setDetectorInput: inputString Reward: reward];

   return self;
}

-step
{
   if (on == 1)
   {
      [self update];
      on = 0;
   } 
  else
  {
      [self answer];
      on = 1;
  }
  return self;    
}

-answer
{

// remove later      inputString = "1100";
// remove later      [agent setDetectorInput: inputString Reward: 100];

   effectorAction = [agentModel getLastAction]; 

   reward = 0;

//  Note here that last must represent the value set in last in the switch 
//  statement, which is actually the NEXT number to be presented not the last

  if ([agentModel getUseStrength])
       predictionCount++;

   if ((effectorAction == 0) && (class == 0))
          reward = 100;
   if ((effectorAction == 1) && (class == 1))
          reward = 100;

   [agentModel setEndOfTrial: True];
 
   if (class == 0)
   {
     
     if (effectorAction == 0) {
	if ([agentModel getUseStrength])
	  correctCount++;
	reward = 100;
	if ([agentModel getDebug])
            printf("\n\t\t ENVIRONMENT: Action Selected was correct %d, 
                    reward %f", effectorAction, reward);
	[inputString setC: "0000000000000000010"];
     }
     else {
       if ([agentModel getUseStrength])
	 incorrectCount++;
       reward = -50;
       if ([agentModel getDebug])
         printf("\n\t\t ENVIRONMENT: Action Selected was incorrect %d ", 
		effectorAction);
       //     [inputString setC: "0000000000000000010"];
       [inputString setC: "0000000000000000001"];
     }


      if (![agentModel getLearning])
          reward = 0;
     

   }
   else
   {
     if (effectorAction == 1) {
       if ([agentModel getUseStrength])
	 correctCount++;
       reward = 100;
	if ([agentModel getDebug])
	  printf("\n\t\t ENVIRONMENT: Action Selected was correct %d, 
                    reward %f", effectorAction, reward);
	//inputString setC: "0000000000000000001"];
	[inputString setC: "0000000000000000010"];
     }
     else {
       if ([agentModel getUseStrength])
	 incorrectCount++;
       reward = -50;
       if ([agentModel getDebug])
         printf("\n\t\t ENVIRONMENT: Action Selected was incorrect %d ", 
		effectorAction);
       [inputString setC: "0000000000000000001"];
     }


      if (![agentModel getLearning])
          reward = 0;
     
   }

      [agentModel setDetectorInput: inputString Reward: reward];

   return self;
}

-(void) convertFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[5] = ""; 
    char temp1[5] = "";
  
    if (anInt == 0)
       strcpy(temp, "0000");
    if (anInt == 1)
       strcpy(temp, "1000");
    if (anInt == 2)
       strcpy(temp, "0100");
    if (anInt == 3)
       strcpy(temp, "0010");
    if (anInt == 4)
       strcpy(temp, "0001");

    strncat(temp1,temp,length);
    [aString catC: temp1];
}    

-getGrid
{
  return grid;
}

-getString
{
   return inputString;
}


-resetAgentPosition
{

  return self;
}

-(float) getPredictiveAccuracy
{
  float tempPredictionCount=0;
  float tempCorrectCount = 0;
  float accuracy=0;

  if (predictionCount > 0)
  {
     tempPredictionCount = predictionCount;
     tempCorrectCount = correctCount; 
     accuracy = ((100.0/tempPredictionCount) * tempCorrectCount);
  }
  if ([agentModel getDebug])
       printf("\n predictionCount, %d, correctCount, %d, accuracy: %f",
                   predictionCount, correctCount, accuracy);
  return accuracy;
}

-(int) getIncorrectCount
{
   return incorrectCount;
}


-timeOut {
  // does nothing yet
  return self;
}

-printOn
{
   printf("\n Environment String: %s", [inputString getC]);
   return self;
}
@end



















