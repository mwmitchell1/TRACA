// Agent application. Copyright (C) 1996 Matthew Mitchell.

#import <simtools.h>                // ... for initSwarm() and swarmGUIMode
#import <simtoolsgui.h>                // ... for initSwarm() and swarmGUIMode
#import "AgentObserverSwarm.h"
#import "AgentBatchSwarm.h"
#include <strings.h>

// The main() function is the top-level place where everything starts.
// For a typical Swarm simulation, in main() you create a toplevel
// Swarm, let it build and activate, and set it to running.

int
main (int argc, const char **argv)
{
  id theTopLevelSwarm;
  const char* argv2[2] = {argv[0], argv[1]};

  // This is for our batch mode, the default doesn't allow multiple args
  // ./agent --batch

  // if second arg is not --batch it is a filename 
  if ((argc > 1) && strcmp("--batch", argv[1]))
    argc = 1;

  if (argc >= 2)
       initSwarm(2, argv2);
  //   initSwarmApp (2, argv2, "1.4.1", "bug-swarm@santafe.edu");
  else
       initSwarm(1, argv2);
  // Swarm initialization: all Swarm apps must call this first.
    //    initSwarmApp (1, argv2, "1.4.1", "bug-swarm@santafe.edu");
  
  // swarmGUIMode is set in initSwarm(). It's set to be 1 if you
  // typed agent -batch. Otherwise, it's set to 0.
  
  if (swarmGUIMode == YES)
    // We've got graphics, so make a full ObserverSwarm to get GUI objects
  {
    theTopLevelSwarm = [AgentObserverSwarm create: globalZone];
    [(AgentObserverSwarm *) theTopLevelSwarm setProblem: (char *) argv[1]];
    [theTopLevelSwarm buildObjects];
    [theTopLevelSwarm buildActions];
    [theTopLevelSwarm activateIn: nil];
    [theTopLevelSwarm go];
  }
  else
  {
    // No graphics - make a batchmode swarm and run it.

    theTopLevelSwarm = [AgentBatchSwarm create: globalZone];
      
    if (argc > 2)
      [(AgentBatchSwarm *) theTopLevelSwarm setProblem: (char *) argv[2] 
                                               seed: (char *) argv[3]];
    [theTopLevelSwarm buildObjects];
    [theTopLevelSwarm buildActions];
    [theTopLevelSwarm activateIn: nil];
    [theTopLevelSwarm go];
  }
 

  // theTopLevelSwarm has finished processing, so it's time to quit.

  return 0;
}

