#import "Cell.h"

@implementation Cell

+createBegin: aZone;
{
   return [super createBegin: aZone];
}

-setGrid: (id) aGrid
{
   grid = aGrid;
   return self;
}

-setX: (int) newX Y: (int) newY
{
   x = newX;
   y = newY;
   return self; 
}

-setCellColor: (int) aColor
{
   previousColor = color;
   color = aColor;
   return self;
}

-(void) resetColor
{
   color = previousColor;
}

-setModel: (id) aModel
{
   worldModel = aModel;
   return self;
}

-createEnd
{
  return [super createEnd];
}

-setRaster: (id) aRaster
{
  raster = aRaster;
  return self;
}

-getRaster
{
  return raster;
}
 
-drawSelfOn: aRaster 
{
  [aRaster drawPointX: x Y: y Color: color];

  return self;
}

-buildObjects
{
  return self;
}

@end

