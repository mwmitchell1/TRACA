// Constants.def

// This file is used to overcome the absence of class variables 
// Constant variables can be loaded from file to override the defaults
// included in here.

// Individual implementation files declare the relevant variables 
// in this as as external

// Class PredictiveNode
// ********************

double predictiveUpdateRate = 0.1;   
