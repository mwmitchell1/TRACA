#import <objectbase.h>
#import <objectbase/SwarmObject.h>
#import "Node.h"
#import "boolean.h"

@interface Input : SwarmObject
{
     id node;
     boolean on;  
}

+createBegin: (id) aZone;
-setNode: (id) aNode;
-getNode;
-(int)getOn;
-setOn: (boolean) aBoolean;
-createEnd;
-addOwnerShare: (double *) aDouble;
-checkActive: (boolean *) aBoolean;
-checkMatched: (boolean *) aBoolean;
-(boolean) checkMatched;
-printOn;
@end




