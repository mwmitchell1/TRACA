#import "NaryNode.h"
#import "AgentModelSwarm.h"
#import "NodeGroup.h"
#import "Trend.h"
#import <collections.h>
#include <stdio.h>
#include <strings.h>


@implementation NaryNode

/*  Note: the family must be set to some integer > 0, 
    and the node number in the createBegin stage 

    Also X and Y coordinates need to be set, this is not checked for in createEnd.
*/

+createBegin: (id) aZone
{
  NaryNode * obj;

  obj = [super createBegin: aZone]; 	
  obj->subordinated=False;
  obj->matchCount = 0;
  obj->activated = False;  

  obj->hypMatchCount = 0;
  
  obj->matched = False;
  obj->isImproved = False;

  obj->activeCount = 0;
  obj->inputsMoved=False;
  obj->nodeGroup=nil;
  obj->firstInputCorrectCount=0;
  obj->firstInputCount=0;
  obj->secondInputCorrectCount=0;
  obj->secondInputCount=0;
  return obj;
}

-createEnd
{	
  return [super createEnd];
}

-buildObjects
{
  [super buildObjects];
  inputList = [List create: [self getZone]];
  suspended = True;
  steadyState = False;
  
  return self;
}

-connectPredictorList: (id) aList
{
        
  boolean skip;
  int index, index1;
  id aNode = nil;
  id aGroup = nil;

  id addList = [List create: [self getZone]];
  
  if ([agentModel getDebug])
    printf("\n Connect predictor list for group: %ld", 
	   [proxyGroup getNodeNumber]);
  
  if (![agentModel getLearning])
    return self;
  
  index = [aList getCount];
  while (index > 0)
    {
      index --;
      skip = False;
      aGroup = [aList atOffset: index];
      
      // first check we aren't predicted by this group

      index1 = [activePredictorList getCount]; 
      while (index1 > 0) 
	{
	  index1--;
	  aNode = [activePredictorList atOffset: index1];
	  if ([aNode getGroup] == [aList atOffset: index])
	    skip = True;
	} 
      
      index1 = [suspendedPredictorList getCount];
      while ((index1 > 0) && !skip)
	{
	  index1--;
	  aNode = [suspendedPredictorList atOffset: index1];
	  if ([aNode getGroup] == [aList atOffset: index]) 
	    skip = True;
	} 
      
      index1 = [passivePredictorList getCount];
      while ((index1 > 0) && !skip)
	{
	  index1--;
	  aNode = [passivePredictorList atOffset: index1];
	  if ([aNode getGroup] == [aList atOffset: index])
	    skip = True;
	} 
      
      // The following lines should be sufficient - BUT ARE NOT - Sept 26 2000 
      // remember to check the effector

      /* June 6 2002 - commented following:
       */
      index1 = [[self getPredictorList] getCount];        
      while ((index1 > 0) && !skip) 
	{
	  index1 --;
	  aNode = [[self getPredictorList] atOffset: index1];

      // The first node in a terminal group is a proxy
      // so has no supported effector
	  if (([(PredictorNode *) aNode getSupported] != nil) 
	      && ([aNode getGroup] == aGroup) 
	      && [[(PredictorNode *) aNode getSupported] getSelected])
	    skip = True;
	}
      
      if (skip == False)
	{
	  [addList addLast: [(NodeGroup *) aGroup getFirstNode]];
	}
    }

  if ([agentModel getDebug])
    printf("\n addlist count: %d", [addList getCount]);
  
  index = [addList getCount];
  while (index > 0)
    {  
      index--;
      aNode = [addList atOffset: index];
      // [aNode printId];
      // May 20 2002 - allow temporal nodes to be copied.
      if ([aNode respondsTo: M(isTemporal)]
	  && ([aNode getSuspended]
     // June 1 2002 - don't connect temporal predictors to their own group
     // June 18 2002 - unless first group in final chain
	      || (([self getGroup] == [aNode getGroup])
		  && ![[self getGroup] getTopGroup])))
	;  // do nothing
      else {
	[self copyPredictor: aNode]; 
      }
    }
  
  [addList drop];
  
  return self;

}

-copyPredictor: (id) aNode
{

  id newNode, valueNode;
  int count;
  
  if ([agentModel getDebug])
    {
      printf("\n Copying node :");
      printf(" nodeNumber: %ld", [aNode getNodeNumber]);
    } 
  
  newNode = [aNode copyNew: [agentModel getZone]];


  // remove the copied node as an owner of the input nodes
  // or copies will be removed when input nodes are removed
  
  count = [[newNode getInputList] getCount];
  
  // prediction to the node group
  
  [self addPredictor: newNode];
  
  [(PredictorNode *) newNode setSupported:
		       [agentModel getSelectedEffector]]; 
  
  // Self may be replaced by a Node group in setPrediction. See 
  // predictor node setPrediction
  
  // the proxyGroup is used for nodes that have a group acting as proxy
  
  [newNode setPrediction: proxyGroup];
  
  // Dec 20 2000 - set independentValue and dependentValue to
  // predictions average return + average reward. The use of the average 
  // here should help overcome distortion (i.e only recieves a high pay-off
  // very rarely.
  // The primary purpose of this is to allow early comparison of terminal
  // nodes strengths with predictions.
  
  // [newNode setDependentValue: [agentModel getInitialQvalue]];

  // Dependent value is based on reinforcement
  // independent value is based on prediction
  // June 2 2002 - removed following line: 
  // [newNode setDependentValue: [proxyGroup getAverageReinforcement]];
  [newNode setIndependentValue: [agentModel getInitialQvalue]];

  [newNode setSuspended: [aNode getSuspended]];
  [newNode setCorrect: True];
  [(PredictorNode *) newNode setCorrectCount: 1];
  //  10/5/98
  [newNode setRealActive: True];
  
  if (![newNode respondsTo: M(isTemporal)])        
    [proxyGroup suspendedPredictedBy: newNode];
  
  //  set sent support so new nodes can share in rewards straightaway.
  //  consider doing this in connectAnd too.  Must change agentModel connect
  //  to do this.
  
  [newNode setSentSupport: True];
  //  This needs to be done for proxyGroups as, as the inputs to a copy node
  //  may actually no longer exist.
  
  [[newNode getGroup] setRealActive: True];
  [[newNode getGroup] checkSupress];
  
  // May 20 2002 - added for terminal groups just finalised
  // so they can be copied and prevent this prediction from creating
  // another chain when already predicted.  After this terminal groups
  // sent this flag when they fire.

  // June 18 leave this - now remove any chains that also predict
  // what this does
  if ([newNode respondsTo: M(isTerminal)]) {
    [proxyGroup setPredictedByFinalisedChain: True];
      
    // Oct 5 2000 - added:
    if ([agentModel getCopyValues]) {
      valueNode = [[[[[newNode getInputList] getFirst] getNode] 
		     getGroup] findSimilarTerminalNode: newNode];
      if (valueNode != nil) {
	[newNode copyValues: valueNode];
	[newNode setSuspended: True]; // Feb 14 2000 changed to True 
      }
    }
  }
  
  // Oct 5 2000 - added:
  if ([newNode respondsTo: M(isTemporal)]
      && [agentModel getCopyValues]) {
    valueNode = [[[[[newNode getInputList] getFirst] getNode] 
      	   getGroup] findSimilarTemporalNode: newNode];
    if (valueNode != nil) {
      [newNode copyValues: valueNode];
      [newNode setSteadyState: [aNode getSteadyState]];
      [newNode setSuspended: [aNode getSuspended]];
    }
  }

  if ([agentModel getDebug])
      printf("\n new node created: %ld", [newNode getNodeNumber]);
  
  return self;
}

-realDeactivate
{
// Don't realdeactivate any more for proxyNodes, this is done
// by nodeGroup.

  if (proxyGroup != nil)
    return self;

  if (removed == True)
    return self;

  matchCount = 0;

  if (![self respondsTo: M(isUnary)] 
      && !suspended
      // Sep 19 2001
      //      && (correctCount > [agentModel getActivationThreshold])
      && ([self getDependentAccuracy] <= (1 - [agentModel getThreshold])))
    {
      // This could be improved to actually remove just this node, but leave
      // the others if getMaxDepdendent > or < 0.
      if ([agentModel getDebug]) 
	printf("\n In realDeactivate. PS <= 1 - threshold: %f, \n so removing node: %ld",
	       [agentModel getThreshold], nodeNumber);

      //      if ([[self getGroup] getNodeNumber] == 375) 
      //[nodeGroup printOn];

	[self removeSelf: nil];
	return self;
    }
     
  activeCount=0;  

  if (![self respondsTo: M(isTemporal)])
    matchCount=0;
  
  [super realDeactivate];

  return self;
}

-checkNarySupress 
{

  int index = 0;

// What this is doing is controlling the connections made by passive predictors
// If you are suspended, then supress your inputs. In this case, all the nodes
// beneath you (except your inputs without active owners) will update their
// predictive strengths and histories.  

// Otherwise, if you are active, and have active owners of yourself, only 
// supress your inputs when you yourself are firstsupressed.
// if you are active and do not have any active owners, or only suspended
// owners, then you should also supress your inputs. 


   if ([agentModel getDebug])
      printf("\n Node: %ld received checkNarySupress, realActive: %d",
	     nodeNumber, realActive);

  if ([self getRealActive] && ![self respondsTo: M(isUnary)]) {
    if ([agentModel getDebug])
      printf("\n Node: %ld received checkNarySupress, realActive: %d",
	     nodeNumber, realActive);
    if (activeSupressed || activeTemporallySupressed)
      return self; // Not a top node, return.
      //[(NaryNode *) self narySupressInputs];    
    else {
      // Here we have the option of narySupressing only one input
      // If we do this we must set narysupressed true for this group
      // otherwise we can get duplicate structures.

      index = [uniformIntRand getIntegerWithMin: 0 
			      withMax: [agentModel getNarySupressionRate]];
      if (index == 1) {

	if ([agentModel getDebug])
	  printf("\n doing one input"); 
	[self setNarySupressed: True];
	[proxyGroup setNarySupressed: True for: [self getSupported]];
	[(NaryNode *) self narySupressOneInput];
      }
      else {
	if ([agentModel getDebug])
	  printf("\n doing both inputs");
	[(NaryNode *) self narySupressInputs];    
	}
    }
  }
  return self;
}


// July 20 2000 - to make up for the fact that Terminal nodes do not send
// matched messages every timestep and nary nodes require two messages

-checkMatched
{
  if ([agentModel getDebug])
    printf("\n Nary node: %ld checkMatched matchCount: %d", nodeNumber,
	   matchCount);

  // June 1 2002 - changed for temporal nodes

  if (matchCount != 0) {

    if ([agentModel getDebug])
      printf("\n Nary node: %ld checkMatched", nodeNumber);
    [self setMatched: False];    
    
    if ([[self getProxyOwnerList] getCount] > 0)
      [[self getProxyOwnerList] forEach: M(match:by:) 
				:(void *) False :(void *) self];
    
    [activePredictorList forEach: M(incorrect)];
    // Uncommented following line May 19 2000
    [passivePredictorList forEach: M(incorrect)];
    [suspendedPredictorList forEach: M(incorrect)];

    matchCount = 0;
  }
  return self;
}


-decrementMatchCount {
  matchCount--;
  return self;
}

// Nov 13 2000 

-correct 
{
  return [super correct];
}

-incorrect
{
  return [super incorrect];
}

-checkInputs
{

  // removed Mar 21 2001 - see comment in check performance
  
  if (![self respondsTo: M(isTemporal)] 
      && ![self respondsTo: M(isTerminal)])
    [self checkPerformance];
 
  if (removed == True)
    return self;
  
  // Nary and unary nodes respond differently to checkSupended
  // Note also that temporal nodes respond differently.  They will
  // not check for removal based on inputs values


  if ([agentModel getDebug])
    printf("\n Node %ld, checkInputs, realActive: %d LRA: %d",
	   nodeNumber, realActive, lastRealActive);


   if (![self respondsTo: M(isTerminal)]
       // Jan 31 2001 - do following also once lastRealActive so we can
       // see whether the prediction was predicted by an already completed
       // chain.
    || ([self respondsTo: M(isTerminal)] && (realActive || lastRealActive))) { 
     // Jan 22 2001 - Terminal nodes can only do this when real active as
     // we check inputs for corridor tasks.
       [self checkSuspended];
   }

   // Nary nodes can be owners:
   
   if ([agentModel getLearning] && !removed)  
     if ((![self respondsTo: M(isUnary)]))
       [self checkSuspendedInputs];
   
   if (steadyState && suspended)
     [self setSuspended: False];
   
   return self;
}


// This is absolutely critical to good performance on Monks problems.

-checkPerformance
{

  // Check if we are accurately predicting our prediction,
  // if so remove owners.
  // Removed Mar 21 2001 - input nodes may approach
  //                       max value if best policy
  //                       is always followed?

  int count;
  id dummy = nil, tempList;
  id aNode = nil;  
  id node1 = nil, node2 = nil;

  //----------------------------------------------------

  // Apr 18 2001 -  allow 12 in monk 1 to have owners
  return self;
   
  //-----------------------------------------------------

  if (steadyState
      && !suspended
      // Sep 19 2001
      //      && (correctCount >= [agentModel getActivationThreshold])
      && ([self getDependentAccuracy] >= [agentModel getThreshold]))
    // Apr 18 2001 - removed following
	   //	   || [self getPerformingAtBest]))
    {
      count = [[self getSuspendedOwnerList] getCount];
      
      tempList = [[self getSuspendedOwnerList] copy: [self getZone]];
      while (count > 0)
       {
          count--;
	  aNode = [[self getSuspendedOwnerList] atOffset: count];

	  if (![aNode respondsTo: M(isTemporal)] &&
	      ![aNode respondsTo: M(isTerminal)]) {	  
	    // April 6 2000 - only remove owners if you are an input to them
	    // (Don't know if this check is still necessary)
	    if ([agentModel getDebug])
	      printf("\n In Removing suspended owners: %d", count);

      node1 = [self getFirstSimilarInput]; 
      node2 = [self getSecondSimilarInput];
  
      if ([[(NaryNode *) aNode getInputList] contains: self]) {

	[(NaryNode *) aNode removeSelf: dummy];
      }
	  }
       }
      [tempList drop];
      
      count = [[self getActiveOwnerList] getCount];
 
      tempList = [[self getActiveOwnerList] copy: [self getZone]];
      while (count > 0)
	{
          count--;
	  aNode = [[self getActiveOwnerList] atOffset: count];
	  if (![aNode respondsTo: M(isTemporal)] &&
	      ![aNode respondsTo: M(isTerminal)]) {
	    if ([agentModel getDebug])
	      printf("\n In Removing active owners: %d", count);
	    // April 6 2000 - only remove owners if you are an input

      if ([[(NaryNode *) aNode getInputList] contains: self]) {
	[(NaryNode *) aNode removeSelf: dummy];
      }
	  }
	}
      [tempList drop];
    }
  return self;
}

-(boolean) checkSuspended
{
  id node1 = nil, node2 = nil;

  // Overridden in Terminal node and Temporal Node.

  if (!steadyState)
    {
      // If never been higher than inputs

      // Mar 4 2002 - changed following:

      // Mar 20 changed following:


      if ([agentModel getDebug] && [self respondsTo: M(isUnary)])
	printf("\n Unary Group: %ld Node: %ld, enoughObs: %d totalObs: %d",
	       [[self getGroup] getNodeNumber],
	       nodeNumber, [trendForThis enoughObservations],
	       [trendForThis getTotalObservations]);
	       

      if (([self respondsTo: M(isUnary)] 
	   && [trendForThis enoughObservations])
	  || (![self respondsTo: M(isUnary)]
	      && ![nodeGroup getHigherValue]
	      && [trendForThis enoughObservations] 
	      && (![trendForThis trendExistsForThis]))
	  || (![self respondsTo: M(isUnary)]
	      && [trend enoughObservations]
	      && higherValue))
       // allow removal of group.
       {

	 if ([agentModel getDebug])
	   {
	     printf("\n Node %ld setting suspended to False: time %ld", 
		    nodeNumber, getCurrentTime()); 
	   }
	 /*
	 if (![self respondsTo: M(isUnary)] &&
	     ![self respondsTo: M(isTemporal)] &&
	     ![self respondsTo: M(isTerminal)]) {
	   node1 = [self getFirstSimilarInput]; 
	   node2 = [self getSecondSimilarInput];
	 }
	 */
	 if (suspended) {	    
	   [self setSuspended: False];
	 }
	 [self setSteadyState: True];
       }
    }
  
  return True;
}


-(void) checkSuspendedInputs
{
  
  // Overridden in Terminal node and Temporal Node.
  
  
  // See PredictorNode checkSuspendedOwners 
  // You are an owner and you need to test if you have improved the 
  // prediction on one of your inputs. If not remove yourself       
  
  // Here, you must ask your input nodes to move you to the activeowners
  // list as you have improved your predictions on one of them
  
  if (![agentModel getLearning])
    return;

  if (([self getSuspended] == False) && (inputsMoved == False))
    {
      inputsMoved = True;
      [[[inputList getFirst] getNode] moveSuspendedOwner: self];
      [[[inputList getLast] getNode] moveSuspendedOwner: self];
    }         
  
  if ([agentModel getDebug]) {
    printf("\n node %ld group: %ld, received checksuspendedinputs", nodeNumber,
	   [nodeGroup getNodeNumber]);
    printf("\n first ratio: %f 2nd ratio: %f, this: %f", 
	   [self getFirstInputRatio], [self getSecondInputRatio], 
	   [self getAbsIndependentValue]);
  }

  // June 4 2001 - this is a bit different - nodes only 
  // set themselves as improved or not improved once they 
  // have established their strengths (independent of the group
  // being suspended or not).

  // Mar 5 2002 - only first node to reach higher value (with trend)
  // can be an improved node. 
  
  if (!removed
      && fired    // Jun 25 2001
      && ![self respondsTo: M(isTemporal)]
      && higherValue
      && ([prediction getNodeNumber] != [nodeGroup getNodeNumber]))
    {
      if (nodeGroup != nil) {
	if (// Trend up now means that inputs are higher than us more often
	    // than not (stat sig).
	    // The sig is important here - a higher sig means it is 
	    // harder to remove, as a sig is harder to achieve
	    isImproved
	    // if lower than inputs remove
	    && ((![trend trendExists] 
		 || ([trend trendExists] && ![trend isTrendUp]))))
	  {
	    isImproved = False;
	    [nodeGroup decrementImprovedNodeCount];
	  }
	else {
	  if (!isImproved
	      // && ([nodeGroup getImprovedNodeCount] == 0)
	      && ([trend trendExists] && [trend isTrendUp])) 
	    {
	      [nodeGroup incrementImprovedNodeCount];
	      isImproved = True;
	    }
	}
      }
    }
}


// After all nodes have added or removed themselves as improved
// then check if they need to be removed

-checkRemove {

  // Sep 19 2001 - don't do remove in second move of a classify cycle
  if (!fired)
    return self;

  if ([agentModel getLearning]
      && ![nodeGroup getRemoved] 
      && !removed
      && ![self respondsTo: M(isUnary)]
      && ![self getSuspended]
      && ![self respondsTo: M(isTemporal)]
      && ([nodeGroup getImprovedNodeCount] <= 0))
    {
      if ([agentModel getDebug])
	printf("\nCheck remove: removing node: %ld, group: %ld", nodeNumber,
	       [nodeGroup getNodeNumber]);
      
      [self removeSelf: nil];
    }

  return self;
}


// returns true if node value is less than inputs.
// use getCompareValue for inputs and independentValue for this.


-(boolean) compareInputs 
{ 

  if (([self getFirstSimilarInput] == nil)
    && ([self getSecondSimilarInput] == nil))
        return True;

  if ([self getFirstSimilarInput] == nil) {
      if ((independentValue * [self getImprovementFactor]) >=
	  [[self getSecondSimilarInput] getCompareValue])
	return False;
      else
	return True;
  }

  if ([self getSecondSimilarInput] == nil) {
    if ((independentValue * [self getImprovementFactor]) >=
	[[self getFirstSimilarInput] getCompareValue])
      return False;
    else
      return True;
  }

  if (((independentValue * [self getImprovementFactor]) <
       [[self getFirstSimilarInput] getIndependentValue])
      || ((independentValue * [self getImprovementFactor]) <
	  [[self getSecondSimilarInput] getIndependentValue]))  
    return True;
  
  return False;
}

// Nov 23 2000 - if we use this we need to uncomment the commented code

-(double) getImprovementFactor 
{
  //  return (1 + (independentAccuracy * [agentModel getImprovementFactor]));

  // if (!isImproved)

  return 1.0 - [agentModel getImprovementFactor];

   //   return 1.0; // + [agentModel getImprovementFactor];

  /* 
  if ([self getIndependentValue] < 0)
    return (1 + [agentModel getImprovementFactor]);
  else
    return (1 - [agentModel getImprovementFactor]);
  */
}

-removeOwners
{
  int count;
  
  count = [[self getSuspendedOwnerList] getCount];
  while (count > 0)
    {
      count--;
      [(NaryNode *) [[self getSuspendedOwnerList] atOffset: count]
		    removeSelf: nil];
    }
  
  count = [[self getActiveOwnerList] getCount];
  while (count > 0)
    {
      count--;
      [(NaryNode *) [[self getActiveOwnerList] atOffset: count] 
		    removeSelf: nil];
    }

  [[self getSuspendedOwnerList] removeAll];
  [[self getActiveOwnerList] removeAll];
  
  return self;
}

-match: (boolean) aBoolean by: (Node *) aNode
{

  // Once both inputs have been recieved, if this nary node is activated
  // Pass this message to predictors who will update predictive strength 
  // if boolean is True, and reward  strength based on the reward. 
  // Predictive nodes call connect to make connections based on correctness  
  // or incorrectness or predictors
  
  // if a nodes inputs have been removed it becomes a copy
  // and is matched by the proxynode.
 
  if (proxyGroup == nil)
    return self;

 if ([agentModel getDebug])
    printf("\n Nary node: %ld matchedBy: %ld count: %d", nodeNumber, 
	   [aNode getNodeNumber], matchCount);

  matchCount++;

  if ([agentModel getDebug])
    printf("\n Nary node: %ld matchedBy: %ld", nodeNumber, 
	   [aNode getNodeNumber]);

  if (matchCount == 2) 
    {
      testMatch = True;
      [inputList forEach: M(checkMatched:) : (void *) &testMatch];   
      if (testMatch) {
	[self setMatched: True];
	if ([agentModel getDebug])
	  printf("\n Nary node: %ld matched", nodeNumber);
      }
      else {
	if ([agentModel getDebug])
	  printf("\n Nary node: %ld not matched", nodeNumber);
	[self setMatched: False];    
      }

      if ([[self getProxyOwnerList] getCount] > 0)
	[[self getProxyOwnerList] forEach: M(match:by:) 
				  :(void *) testMatch :(void *) self];
      
      if (testMatch) 
	{
	  [activePredictorList forEach: M(correct)];   
	  // Uncommented following line May 19 2000
	  [passivePredictorList forEach: M(correct)];
	  [suspendedPredictorList forEach: M(correct)];
	}
      else
	{ 
	  [activePredictorList forEach: M(incorrect)];
	  // Uncommented following line May 19 2000
	  [passivePredictorList forEach: M(incorrect)];
	  [suspendedPredictorList forEach: M(incorrect)];
	} 
      matchCount = 0;
    }
  
  return self;
}

-(boolean) thisInputOn: (id) anInputNode
{
  // returns True if this node is an ON input
  
  if (type == 0)          // You are an AND node
    return True;
  
  if ([[inputList getFirst] getNode] == anInputNode)
    if ([[inputList getFirst] getOn] == False)  
      return False;
  
  if ([[inputList getLast] getNode] == anInputNode)
    if ([[inputList getLast] getOn] == False)  
      return False;      
  
  return True;
}

-(boolean) addInput: (Node *) aNode AsOn: (boolean) aBoolean
{
  Input * input;
  
  if ([self respondsTo: M(isTerminal)])
    if ([agentModel getDebug])
      printf("\n addinginput: %ld to terminal node: %ld", 
	     [aNode getNodeNumber], nodeNumber);
  
  if (aNode == nil)
    return False;
  
  input = [Input createBegin: [agentModel getZone]];
  [input setNode: aNode];
  [input setOn: aBoolean];
  input = [input createEnd];
  
  [inputList addLast: input];
  return True;	
}

// This is all a bloody mess, I have drawn the conclusion that the trouble
// (and there was a lot of it) was due to forEach loops having a problem which
// prevents them from sometimes working twice on the same list at once,
// consequently I have replaced them with explicit loops.

// Before wasting time on any problems here, make copies of lists

-removeSelf: (id) aNode
{
  int count = 0;
  id tempList = nil;
  
  if (removed == True)
    return self;
 
  // This stops the node being removed multiple times
  removed = True;
 
  if ([agentModel getDebug])
    printf("\n now removing node %ld ", nodeNumber);

  if (proxyGroup == nil) {
 
    if ([nodeGroup getMostFrequentPositive: self] == self) 
      [nodeGroup setMostFrequentPositive: self to: nil];
      
    if ([nodeGroup getMostFrequentNegative: self] == self)
      [nodeGroup setMostFrequentNegative: self to: nil];

    [(AgentModelSwarm *) agentModel removeNode: self];
   } else {
    [proxyGroup remove];
  }

  [agentModel removeFromList: self];
  if (proxyGroup == nil)
    [prediction removePredictor: self];
  
  if (nodeGroup != nil)
    {
      if (aNode == nil) // prevent call back to node group removeNode.
	{
	  
	  if ([agentModel getDebug])
	    printf("\n removing %ld from nodeGroup: %ld, copy: %d", nodeNumber,
		   [nodeGroup getNodeNumber], copy);

	  [(NodeGroup *) nodeGroup removeNode: self];
	}
    }
  else 
    {
      if ([agentModel getDebug])
	printf("\n removing %ld from proxyGroup: %ld, copy: %d", nodeNumber,
	       [proxyGroup getNodeNumber], copy);

      if ([predictorList getCount] > 0)
	{
	  tempList = [predictorList copy: [self getZone]];
	  count = [predictorList getCount];
	  while (count > 0) {
	    count--;
	    [[tempList atOffset: count] removeSelf: nil];
	  }
	  [tempList drop];
	}
    }


 // Remove from extend list

  [[agentModel getExtendList] remove: self];
  [[agentModel getLastExtendList] remove: self];
  
  if (!copy)
    {
      if ([agentModel getDebug])
	printf("\n------ removing first input for node: %ld", nodeNumber);
     
      if ([inputList getCount] > 0)
	[[[inputList getFirst] getNode] removeOwner: self];
 
      if ([agentModel getDebug])
	{
	  printf("\n------ removing second input for node: %ld", nodeNumber);
	  if ([inputList getCount] > 0)
	    [[[inputList getLast] getNode] printOn]; 
	}
      
      if ([inputList getCount] > 0)
	[[[inputList getLast] getNode] removeOwner: self]; 

      // ProxyNodes do not send this message to their owners.

      count = [activeOwnerList getCount];
      
      tempList = [activeOwnerList copy: [self getZone]];
      [activeOwnerList removeAll];
      while (count > 0) {
	count--;
	[[tempList atOffset: count] removeSelf: nil];
      }
      
      [tempList drop];
      
      count = [suspendedOwnerList getCount];

      tempList = [suspendedOwnerList copy: [self getZone]];
      [suspendedOwnerList removeAll];
      while (count > 0) {
	count--;
	[[tempList atOffset: count] removeSelf: nil];
      }
      [tempList drop];
      
    }
  else {

    if ([inputList getCount] > 0) {
      [[[inputList getFirst] getNode] removeOwner: self];
      [[[inputList getLast] getNode] removeOwner: self];  
    }

    count = [activeOwnerList getCount];

    tempList = [activeOwnerList copy: [self getZone]];
    [activeOwnerList removeAll];
    while (count > 0) {
      count--;
      [[tempList atOffset: count] removeSelf: nil];
    }
    [tempList drop];
    
    count = [suspendedOwnerList getCount];

    tempList = [suspendedOwnerList copy: [self getZone]];
    [suspendedOwnerList removeAll];
    while (count > 0) {
      count--;
      [[tempList atOffset: count] removeSelf: nil];
    }       
    [tempList drop];
  }
  
  if ([agentModel getDebug])
    printf("\n finished remove for node: %ld", nodeNumber);
  
  [[agentModel getDropList] addLast: self];
  
  if (trend != nil)
    [trend removeSelf];
  if (trendForThis != nil) 
     [trendForThis removeSelf];

  if ([agentModel getDebug])
    printf("\n added node to droplist: %ld", nodeNumber);
  
  return self;
}


// This is a copy of the above for situtations  where only the last temporal
// group in a chain needs to be removed.  
// Oct 9 2000 

-temporalRemoveSelf: (id) aNode
{
  int count = 0;
  id tempList = nil;
  
  if (removed == True)
    return self;
  
  if ([agentModel getDebug]) 
    printf("\n Temporal removing node: %ld", nodeNumber);
  
  // This stops the node being removed multiple times
  removed = True;
  
  [(AgentModelSwarm *) agentModel removeNode: self];

  /* Oct 9 2000 - the difference between temporalRemoveSelf and removeSelf
     is the following two lines:

  else
    [proxyGroup remove];
  */ 

  [agentModel removeNode: self];
    
  if (proxyGroup == nil)
    [prediction removePredictor: self];
  
  if (nodeGroup == nil)
      {
	if ([predictorList getCount] > 0)
	  {
	    tempList = [predictorList copy: [self getZone]];
	    count = [predictorList getCount];
	    while (count > 0) {
	      count--;
	      [[tempList atOffset: count] removeSelf: nil];
	    }
	    [tempList drop];
	  }
      }
    
    if (!copy)
      {
        if ([agentModel getDebug])
	  printf("\n------ removing first input for node: %ld", nodeNumber);
	
	if ([inputList getCount] > 0)
	  [[[inputList getFirst] getNode] removeOwner: self];
	
        if ([agentModel getDebug])
	  {
            printf("\n------ removing second input for node: %ld", nodeNumber);
	    if ([inputList getCount] > 0)
	      [[[inputList getLast] getNode] printOn]; 
	  }
	
	if ([inputList getCount] > 0)
	  [[[inputList getLast] getNode] removeOwner: self]; 
	
	count = [activeOwnerList getCount];
	tempList = [activeOwnerList copy: [self getZone]];
	while (count > 0) {
	  count--;
	  [[tempList atOffset: count] removeSelf: nil];
	}
	[tempList drop];
	
	count = [suspendedOwnerList getCount];
	tempList = [suspendedOwnerList copy: [self getZone]];
	while (count > 0) {
	  count--;
	  [[tempList atOffset: count] removeSelf: nil];
	}
	[tempList drop];
      }
    else {
      if ([inputList getCount] > 0) {
        [[[inputList getFirst] getNode] removeOwner: self];
        [[[inputList getLast] getNode] removeOwner: self];  
      }
      
      count = [activeOwnerList getCount];
      tempList = [activeOwnerList copy: [self getZone]];
      while (count > 0) {
	count--;
        [[tempList atOffset: count] removeSelf: nil];
      }
      [tempList drop];
      
      count = [suspendedOwnerList getCount];
      tempList = [suspendedOwnerList copy: [self getZone]];
      while (count > 0) {
	count--;
        [[tempList atOffset: count] removeSelf: nil];
      }       
      [tempList drop];
    }
    
    if ([agentModel getDebug])
      printf("\n finished remove for node: %ld", nodeNumber);
    
    [[agentModel getDropList] addLast: self];

    if ([agentModel getDebug])
      printf("\n added node to droplist: %ld", nodeNumber);
    
    return self;
}

-(boolean) removeInputs
{
  [inputList forEach: M(removeSelf:) :(id) nil];
  return True;
}

-hypSupress
{ 

   [self setHypSupressed: True];
   [proxyGroup setHypSupressed: True for: [self getSupported]];
   if ([self getType] == 0)
      [self hypSupressInputs];
  
   return self;
}

-updateTemporalSupress
{
   [self setUpdateTemporalSupressed: True];
   [proxyGroup setUpdateTemporalSupressed: True for: [self getSupported]];
   [self updateTemporalSupressInputs];
   return self;
}

-checkActiveSupress
{

// this can be cleaned up, basically, the nodes which have just fired
// for an effector activesupress their inputs, so they are not used
// in new  connections, otherwise they are.

// Changed this so that it activeSupresses nodes, if they have an
// activeOwner which is matched rather than just suspended owners
 
// Note that a group (proxyNode) is considered not suspended once
// the first node is no longer suspended.

  if (![self respondsTo: M(isUnary)] 
      && matched && !suspended)
    [self activeSupressInputs];
  
  return self;
}

-activeTemporalSupress
{
   [self setActiveTemporallySupressed: True];
   if (![self respondsTo: M(isUnary)])
        [self temporalActiveSupressInputs];
   // Nov 15 2000 - removed following already done in self setActTempSupressed
   [proxyGroup setActiveTemporallySupressed: True for: [self getSupported]];

   return self;
}

-activeActionSupress: (id) anEffector
{
   [self setActiveActionSupressed: True for: anEffector];

   return self;
}

-activeSupress
{
   [self setActiveSupressed: True];
   if (![self respondsTo: M(isUnary)])
        [self activeSupressInputs];
   [proxyGroup setActiveSupressed: True for: [self getSupported]];

   return self;
}


-hypActiveSupress
{
   [self setHypActiveSupressed: True];
   if (![self respondsTo: M(isUnary)])
        [self hypActiveSupressInputs];
   [proxyGroup setHypActiveSupressed: True for: [self getSupported]];
   return self;
}

-checkSupress 
{

// What this is doing is controlling the connections made by passive predictors
// If you are suspended, then supress your inputs. In this case, all the nodes
// beneath you (except your inputs without active owners) will update their
// predictive strengths and histories.  

// Otherwise, if you are active, and have active owners of yourself, only 
// supress your inputs when you yourself are firstsupressed.
// if you are active and do not have any active owners, or only suspended
// owners, then you should also supress your inputs. 
  
  if ([self getRealActive])
    if (![self respondsTo: M(isUnary)] && ![self respondsTo: M(isTemporal)])
      [(NaryNode *) self supressInputs];    
  
  return self;
}



-requestExclusion: (id) node 
{
  // A node randomly decides if it does not want to be supressed. In this
  // case, the top nodes in the hierarchy above the node must be
  // nary supressed instead to prevent duplicates.  
  // If the top node has already received a request, the request is denied.

  id  terminalNode;
  int count = [proxyOwnerList getCount];

  //  if ([self respondsTo: M(isTemporal)])
  //  return self;

  // June 20 2002 - temporal and terminal nodes always 
  // refuse these requests. 
  // Note terminal nodes are not an owner of their input

  if ([self respondsTo: M(isTemporal)]) {
    if ([(TemporalNode *) self getTemporallyRealActive]
	&& [[[self getGroup] getTopGroup] getFinalGroup])
      [node requestDenied];
    else  { // if not temporallyrealactive, this request may be for your
      // terminalGroup which is not directly connected to its input.
      terminalNode = [[self getGroup] getTerminalNode];
      if (terminalNode != nil)
	 if ([terminalNode getRealActive] 
	     && ![terminalNode getSuspended])
	   [node requestDenied];
      return self;
    }
  }


  if (count > 0) {
    [proxyOwnerList forEach: M(requestExclusion:) : (id) node];
  }
  else {
    if (narySupressed) {
      [node requestDenied];
    }
    else {
      [proxyGroup setNarySupressed: True for: nil];
      narySupressed = True;
    }
  }
  return self;
}

-requestDenied 
{
  if ([agentModel getDebug])
    printf("\n Node %ld, requestDenied", nodeNumber);
  [proxyGroup setNarySupressed: True for: nil];
  narySupressed = True;
  return self;
}


-exclude
{
  [proxyGroup setNarySupressed: False for: nil];
  narySupressed = False;

  // Apr 17 2001
  // June 6 2001 - removed following line 
  //  if ((proxyOwnerList != nil)
  if ([[self getProxyOwnerList] getCount] > 0)
    [proxyOwnerList forEach: M(requestExclusion:) : (id) self];
  [[proxyGroup getSuspendedOwnerList] 
    forEach: M(requestExclusion:) : (id) self];
  
  
  return self;
}


-narySupressOneInput
{
  int index = 0;

  index = [uniformIntRand getIntegerWithMin: 0 
			  withMax: 1];

  if (index == 0) {
    [[[inputList getFirst] getNode] narySupress];
  }
  else {
    [[[inputList getLast] getNode] narySupress];
  }

   return self;
} 

-narySupressInputs
{
   [[[inputList getFirst] getNode] narySupress];
   [[[inputList getLast] getNode] narySupress];
   return self;
} 

-narySupress
{ 
  if ([agentModel getDebug])
    printf("\n node %ld setting nary supressed true", nodeNumber);

   [self setNarySupressed: True];
   [proxyGroup setNarySupressed: True for: [self getSupported]];
   if ([self getType] == 0)
      [self narySupressInputs];
  
   return self;
}

-(boolean) setNarySupressed: (boolean) aBoolean
{
   if (proxyGroup != nil)
      [proxyGroup setNarySupressed: aBoolean];
   narySupressed = aBoolean;
   return narySupressed;
}


-(boolean) getNarySupressed
{
   return narySupressed;
}


-checkTemporalSupress 
{
    return self;
}

-checkActiveTemporalSupress 
{
    return self;
}

-supressInputs
{
   [[[inputList getFirst] getNode] supress];
   [[[inputList getLast] getNode] supress];
   return self;
} 

-updateTemporalSupressInputs
{
   [[[inputList getFirst] getNode] updateTemporalSupress];
   [[[inputList getLast] getNode] updateTemporalSupress];
   return self;
} 


-temporalSupressInputs
{
   [[[inputList getFirst] getNode] temporalSupress];
   [[[inputList getLast] getNode] temporalSupress];
   return self;
} 


-temporalActiveSupressInputs
{
   [[[inputList getFirst] getNode] activeTemporalSupress];
   [[[inputList getLast] getNode] activeTemporalSupress];
   return self;
} 


-temporalSupress
{
   [self setTemporallySupressed: True];
   [proxyGroup setTemporallySupressed: True for: [self getSupported]];
   if (![self respondsTo: M(isUnary)])
        [self temporalSupressInputs];
   return self;
} 


-supress
{ 
   [self setSupressed: True];
   [proxyGroup setSupressed: True for: [self getSupported]];
   if ([self getType] == 0)
      [self supressInputs];
  
   return self;
}


-hypSupressInputs
{

   if ([[inputList getFirst] getOn] == 1)
       [[[inputList getFirst] getNode] hypSupress];
   if ([[inputList getLast] getOn] == 1)
       [[[inputList getLast] getNode] hypSupress];
   return self;
} 


-activeSupressInputs
{
   [[[inputList getFirst] getNode] activeSupress];
   [[[inputList getLast] getNode] activeSupress];
   return self;
} 

-hypActiveSupressInputs
{
   if ([[inputList getFirst] getOn] == 1)
       [[[inputList getFirst] getNode] hypActiveSupress];
   if ([[inputList getLast] getOn] == 1)
       [[[inputList getLast] getNode] hypActiveSupress];
   return self;
} 

-isNary
{
   return self;
}

-getInputList
{
   return inputList;
}

-setType: (int) aType
{
   type = aType;
   return self;
}

-(int) getType
{
   return type;
}

-getNodeGroup
{
   return nodeGroup;
}

-(boolean) resetMatched: (boolean) aBoolean
{
   matched = aBoolean;
   return matched;
}

-(boolean) setMatched: (boolean) aBoolean
{

  // If you are a proxyNode, set the group to matched, this is sent to all
  // nodes in the group.

   if (proxyGroup != nil)
   {
      [proxyGroup setMatched: aBoolean];    
      matched = aBoolean;
   }

   if ([agentModel getDebug])
     printf("\n node: %ld setting matched: %d", nodeNumber, aBoolean);

   matched = aBoolean;
   return matched;
}

-(boolean) setHypMatched: (boolean) aBoolean
{
  // overridden in Nary nodes to use groups

  // If you are a proxyNode, set the group to matched, this is sent to all
  // nodes in the group.

   if (proxyGroup != nil)
      [proxyGroup setHypMatched: aBoolean];    

   hypMatched = aBoolean;
   return hypMatched;
}

-(boolean) getMatched
{

  if ([agentModel getDebug]) {
    printf("\n Node: %ld getMatched: %d", nodeNumber, matched);
  }

   // overridden in Nary nodes to use groups
  return matched;
}

-(boolean) getHypMatched
{
  // overridden in Nary nodes to use groups
      return hypMatched;
}

-(boolean) setSupressed: (boolean) aBoolean
{
   if (proxyGroup != nil)
      [proxyGroup setSupressed: aBoolean];
   supressed = aBoolean;
   return supressed;
}


-(boolean) setTemporallySupressed: (boolean) aBoolean
{
   if (proxyGroup != nil)
      [proxyGroup setTemporallySupressed: aBoolean];
   lastTemporallySupressed = temporallySupressed;
   temporallySupressed = aBoolean;
   return temporallySupressed;
}


-(boolean) setHypSupressed: (boolean) aBoolean
{

   if (proxyGroup != nil)
      [proxyGroup setHypSupressed: aBoolean];
   hypSupressed = aBoolean;
   return hypSupressed;
}

-(boolean) getTemporallySupressed
{
   return temporallySupressed;
}

-(boolean) getSupressed
{
   return supressed;
}


-(boolean) getHypSupressed
{
   return hypSupressed;
}


-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean
{
   if (proxyGroup != nil)
       [proxyGroup setUpdateTemporalSupressed: aBoolean];
   updateTemporalSupressed = aBoolean;
   return updateTemporalSupressed;
}

-(boolean) getUpdateTemporalSupressed
{
   return updateTemporalSupressed;
}


-(boolean) setRealActive: (boolean) aBoolean
{
   // This applies only to proxyNodes which setrealActive based on whether 
   // or not they are matched

   realActive = aBoolean;
   return realActive;
}


-(boolean) setLastRealActive: (boolean) aBoolean
{
   // This applies only to proxyNodes which setrealActive based on whether 
   // or not they are matched

   lastRealActive = aBoolean;
   return lastRealActive;
}

-(boolean) setHypActive: (boolean) aBoolean
{
  // overridden in Nary nodes to use groups

  // If you are a proxy, send message to nodeGroup, copied to
  // all nodes in the group

   hypActive = aBoolean;
   return hypActive;
}

-(boolean) getRealActive
{
  // overridden in Nary nodes to use groups

   return realActive;
}

-(boolean) getHypActive
{
  // overridden in Nary nodes to use groups

   return hypActive;
}

-setSuspended: (boolean) aBoolean
{

   if (suspended == aBoolean)
      return self;

   // This was added for active counts, (otherwise should have
   // no effect except for efficiency),  terminal nodes were having 
   // suspended set to false when values were copied from other nodes
   // as this is applied to the whole group, when it was reset it
   // added nodes as active again. 

   if ((suspended == False) && (aBoolean == True))
     return self;

   suspended = aBoolean;

   if (aBoolean == False)
     if (![self respondsTo: M(isUnary)]) {
       if (![self respondsTo: M(isTerminal)]) {
	 if ((aBoolean == False) && (proxyGroup == nil)) 
	   [agentModel addActive: self];
       }
       else 
	   [agentModel addActive: self];
     }

   if (nodeGroup != nil)
     // Nov 23 - to allow group to be !suspended if any node has reached
     // activationThreshold, based on fact that most successful nodes
     // will be activated more often anyway: && !copy) 
     [nodeGroup setSuspended: aBoolean];
   return self;
}

-(boolean) getSuspended
{
   return suspended;
}

-getActiveOwnerList
{
   return activeOwnerList;
}

-(boolean) getSubordinated
{
   return subordinated;
}

-setSubordinated: (boolean) aBoolean
{
   subordinated = aBoolean;
   return self;
}

-getSuspendedOwnerList
{ 
    return suspendedOwnerList;
}

-setInputsMoved: (boolean) aBoolean
{
   inputsMoved = aBoolean;
   return self;
}

-copyNew: (id) aZone;
{

// If anode receives this message it may need to create a node group and 
// pass that back in place of itself
   
   id newNode;
 
   newNode = [self copy: aZone];

   if (nodeGroup != nil)
      [nodeGroup addNode: newNode];
   else
      [proxyGroup addNode: newNode];

// we belong to this group

   if (nodeGroup != nil)
      [newNode addGroup: nodeGroup];
   else   
      [newNode addGroup: proxyGroup];   

   if ([agentModel getDebug])
      printf("\n Finished Copy new");   

   return newNode;
} 

-createGroup
{
   id  tempGroup;

   if (nodeGroup == nil)
   {
      if ([agentModel getDebug])    
         printf(" \n in Create group: nodeGroup is nil"); 

      tempGroup = [NodeGroup createBegin: [agentModel getZone]];
      [tempGroup setAgentModel: agentModel];
      [tempGroup setNodeNumber: [agentModel getNextNodeNumber: tempGroup]];
      tempGroup = [tempGroup createEnd];
      [agentModel addNode: tempGroup]; 
      [tempGroup buildObjects];

      [tempGroup setTimeCreated: getCurrentTime()];

      [tempGroup setNode: self];

  // need to use tempGroup to this point, as the nodegroup must be zero      
  // alternatively, provide a different getPredictorList method to use 
  // and use this in nodeGroup::movepredictors

      [self addGroup: tempGroup];

      if ([agentModel getDebug])    
	printf(" \n in Create group: default setMatched and realActive");
      //  June 11 - change for temporal
 
      if ([[nodeGroup getProxyNode] respondsTo: M(isTemporal)]) {
	[nodeGroup setRealActive: True];
      } else {
	[nodeGroup setMatched: matched];
	[nodeGroup setRealActive: realActive];
      }
   }

   return self;
}

-copy: (id) aZone
{
   NaryNode * node;
   int count;
   int index; 
  
   node = [NaryNode createBegin: aZone];
   [node setGrid: grid];
   [node setX: x Y: y];
   [node setColor: color];
   [node setModel: agentModel];
   [node setType: type];                  // 0 is AND
   [node setNodeNumber: [agentModel getNextNodeNumber: node]];  
   node = [node createEnd]; 

   [node buildObjects];

   [node setMatched: matched];
   [node setSupressed: supressed];
   [node setNarySupressed: narySupressed];
   [node setTemporallySupressed: temporallySupressed];
   [node setSuspended: [[nodeGroup getFirstNode] getSuspended]];
   [node setSteadyState: [[nodeGroup getFirstNode] getSteadyState]];
   count = [inputList getCount];

   for (index=0;index<count;index++)
      [node addInput: [[inputList atOffset: index] getNode]
            AsOn: [[inputList atOffset: index] getOn]];

// CAREFUL - this adds as active to the lower node, if suspended 
//           is used ask self if suspended or active, then add

   for(index=0;index<count;index++)
      if ([node getSuspended])
          [[[inputList atOffset: index] getNode] addSuspendedOwner: node]; 
      else  
          [[[inputList atOffset: index] getNode] addActiveOwner: node]; 

   [node setPrediction: prediction];

   [node setSupported: supported];
   [agentModel addNode: node];
      
   return node;
}


-setCorrectCount: (int) anInt
{
   correctCount = anInt;
   return self;
}


// Assumes at least one input exists

-(double) getHighestSimilarInputValue
{
  if (([self getFirstSimilarInput] == nil)
      && ([self getSecondSimilarInput] != nil))
      return [[self getSecondSimilarInput] getCompareValue];

  if (([self getSecondSimilarInput] == nil)
    && ([self getFirstSimilarInput] != nil))
      return [[self getFirstSimilarInput] getCompareValue];

 if ([[self getFirstSimilarInput] getCompareValue] >
      [[self getSecondSimilarInput] getCompareValue])
    return [[self getFirstSimilarInput] getCompareValue];

 return [[self getSecondSimilarInput] getCompareValue];
   
}

// return some very small value for temporal and terminal nodes 
// Should really not check this for temporal nodes.

-(double) getCompareValue {

  // June 18 2002 - removed:
  // July 16 2002 - added back:
  if ([self respondsTo: M(isTemporal)])
  //    || [self respondsTo: M(isTerminall)])
    return 0.0;
      
  return [self getIndependentValue];
}

// This uses the method written for terminal nodes

-getFirstSimilarInput
{
  if ((inputList == nil) || ([inputList getCount] == 0))
    return nil;

  return [[[[inputList getFirst] getNode] getGroup]
	  findSimilarTerminalNode: self];
}

// This uses the method written for terminal nodes

-getSecondSimilarInput
{

  if ((inputList == nil) || ([inputList getCount] == 0))
    return nil;

  return [[[[inputList getLast] getNode] getGroup]
	  findSimilarTerminalNode: self];
}


-(double) getFirstInputRatio
{
  return [[[inputList getFirst] getNode] getAbsIndependentValue]; 
}

-(double) getSecondInputRatio
{
  return [[[inputList getLast] getNode] getAbsIndependentValue];
}

-getInputFor: (id) aNode
{
  if ([[inputList getFirst] getNode] == aNode)
    return [[inputList getFirst] getNode];
  
  if ([[inputList getLast] getNode] == aNode)
    return [[inputList getLast] getNode];
  
  printf("\n Warning: no input for node +++++++++++++++++++");
  
  return nil;      
}       

-(void) die
{
  if (removed)
    { 
      [inputList drop];
      [super die];
    }
}

-drawSelfOn: (Raster *) aRaster
{
  //	[aRaster drawPointX: x Y: y Color: color];
	return self;
}

-printPredictors
{
  printf("\n =========== node %ld printing predictors", nodeNumber );
  [predictorList forEach: M(printOn)]; 
  return self;  
}

-printId
{

  if (nodeGroup != nil)
    printf("\nNary owner node number: %ld group: %ld", nodeNumber, 
	   [nodeGroup getNodeNumber]);
  else
    printf("\nNary owner node number: %ld group: %ld", nodeNumber,
	   [proxyGroup getNodeNumber]);
  return self;
}


-printOn
{
    int groupNumber = -1;
    int position = 99;
    long number = 0;

    if (nodeGroup != nil)
       groupNumber = [nodeGroup getNodeNumber];
    else {
      if (proxyGroup != nil) {
	printf("\nProxy node: ");
	groupNumber = [proxyGroup getNodeNumber];
      }
    }

    if (supported != nil)
      position = [supported getPosition];

    if (prediction != nil)
      number = [prediction getNodeNumber]; 

//  Note: average strength used as real strength before it is updated


    if ([self respondsTo: M(isTemporal)])
        printf("\nTemporal node number: %ld, disc: %f", nodeNumber, 
	       [(TemporalNode *) self getDiscountedTerminalValue]);
    else {
        printf("\nNary node number: %ld", nodeNumber);
	printf("\nisImproved ====== %d", isImproved);  
    }

    if ([self getGroup] != nil) {
      printf("\nAverage reward: %f Average return: %f", 
	     [[self getGroup] getAverageReward],
	     [[self getGroup] getAverageReturn]);
    }

   printf("\n\tNary owners: %d Nary predictors: %d depValue: %f indepValue: %f \mngroup: %d, copy: %d prediction node: %ld. \n\t  suspended: %d, temporallySuspended: %d \n\t steadyState: %d, maxGroupValue: %f activationCount: %ld trend: %d, \n correctCount: %ld, dependentAccuracy: %f, rewardStrength: %f \nEffector: %d, hyp strength: %f, temporallySuspended: %d",
	   ([[self getActiveOwnerList] getCount] 
	    + [[self getSuspendedOwnerList] getCount])
	   ,[predictorList getCount], [self getDependentValue], 
	   independentValue, 
	   groupNumber, copy,
	   number,  
	   [self getSuspended],temporallySuspended,
	   steadyState, [self getMaxDependent],
	   activationCount, [trendForThis trendExistsForThis], ownCorrectCount,
	   [self getDependentAccuracy], rewardStrength, 
	   position, 
	   hypStrength, [self getTemporallySuspended]);
   if ([self respondsTo: M(isTemporal)])
        printf("\n Discounted Terminal Value: %f", 
	       [(TemporalNode *) self getDiscountedTerminalValue]);
    if (!copy) {
	 [inputList forEach: M(printOn)];
    }
// Sep 19 2001 - added this printout
    printf("\n this trend:");
    [trendForThis printThisTrendOn];
    
    printf("comparewithinput: ");
    [trend printOn];

    if (([self getFirstSimilarInput] != nil)
	&& ([self getSecondSimilarInput] != nil)) {
      printf("\n\t First input ratio: %f",
	     [[self getFirstSimilarInput] getAbsIndependentValue]);
      printf("\n\t Second input ratio: %f",
	     [[self getSecondSimilarInput] getAbsIndependentValue]);
    }
          
    fflush(stdout);
    return self;
}

-summaryOn {
  printf("\n Node is: %ld Group is: %ld removed: %d", nodeNumber,
	 [[self getGroup] getNodeNumber], removed);
}

-printAsRule {
  if (isImproved) {
    printf("\n\t Node Number: %ld, strength: %f, indep: %f effector: %s improved: %d, 1st: %f, %f. 2nd: %f, %f",
	   nodeNumber, dependentValue, independentValue,
	   [[agentModel lookUpEffectorName: [supported getPosition]] getC],
	   isImproved, 
	   [[[inputList getFirst] getNode] getIndependentValue],
	   [[[inputList getFirst] getNode] getDependentValue],
	   [[[inputList getLast] getNode] getIndependentValue],
	   [[[inputList getLast] getNode] getDependentValue]);
    [trend printOn];
  }
  return self;
}

-hypMatch: (boolean) aBoolean
{

   // Once both inputs have been recieved, if this nary node is activated
   // Pass this message to predictors who will update predictive strength 
   // if boolean is True, and reward  strength based on the reward. 
   // Predictive nodes call connect to make connections based on correctness  
   // or incorrectness or predictors

   // if a nodes inputs have been removed it becomes a copy
   // and is matched by the proxynode.

   if (copy)
      return self;

   if ((hypActivePredictorCount > 0) || (hypSuspendedPredictorCount > 0))
   {
      [self setHypMatched: True];
      hypTestMatch = True;
      if ([[self getActiveOwnerList] getCount] > 0)
         [[self getActiveOwnerList] forEach: M(hypMatch:) :(void *) 
                              hypTestMatch];
      if ([[self getSuspendedOwnerList] getCount] > 0)
         [[self getSuspendedOwnerList] forEach: M(hypMatch:) :(void *) 
                              hypTestMatch];
      if ([[self getProxyOwnerList] getCount] > 0)
         [[self getProxyOwnerList] forEach: M(hypMatch:) :(void *) hypTestMatch];
   }
   else
   if (hypMatchCount == 2) 
   {
      hypTestMatch = True;

      [inputList forEach: M(checkHypMatched:) : (void *) &hypTestMatch];   

      if (hypTestMatch)
      {
         [self setHypMatched: True];
      }          
      else
      {
          if  (type == 1)
              [self setHypMatched: False];    
      }  

      if ([[self getActiveOwnerList] getCount] > 0)
         [[self getActiveOwnerList] forEach: M(hypMatch:) :(void *) 
                              hypTestMatch];
      if ([[self getSuspendedOwnerList] getCount] > 0)
         [[self getSuspendedOwnerList] forEach: M(hypMatch:) :(void *) 
                              hypTestMatch];
      if ([[self getProxyOwnerList] getCount] > 0)
         [[self getProxyOwnerList] forEach: M(hypMatch:) :(void *) hypTestMatch];

      hypMatchCount = 0;
   }
   return self;
}

-hypActivate
{
   [super hypActivate];
   return self;
}

-hypDeactivate
{

  hypMatchCount=0;

  [super hypDeactivate];

  return self;
}

-(boolean) getImproved {
  return isImproved;
}

-(boolean) getActivated {

  if (activated)
    return True; // once activated always activated

  if ((![trendForThis trendExistsForThis] 
       && [trendForThis enoughObservations]))
      //  || (higherValue && [trend enoughObservations]))
    activated = True;

  return activated;
}

// This is for temporal nodes to determine
// if the group should be removed.

-(boolean) getReadyForRemoval {

  if ((![trendForThis trendExistsForThis] 
       && [trendForThis enoughObservations]
       && ![trendForThis isTrendUp]))
    if (!higherValue || [trend enoughObservations]) 
      return True;

  return False;
}

-(boolean) isImproved {
  return isImproved;
}

-getHighestAction: (float) highestValue {
  
  // June 10 2002 - don't send return or support until had enough trials


  if ([self respondsTo: M(isTerminal)]) {
    if (ownActivationCount < [agentModel getTemporalActivationThreshold])
      return self;
  }
  else {
    if (ownActivationCount < [agentModel getActivationThreshold])
      return self;
  }

  if ((highestValue < dependentValue)
      && (independentValue >
	  [[nodeGroup getHighestActionNode] getIndependentValue]))
    {
      highestValue = dependentValue;
      [nodeGroup setHighestAction: [supported getPosition] node: self];
    }
  
  return self;
}

@end

















