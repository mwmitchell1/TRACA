#define noType 0
#define suspendedType 1
#define activeType 2
#define passiveType 3
