#import <collections.h>
#import <objectbase.h>				  // we inherit swarm objects
#import <objectbase/SwarmObject.h>
#import <space.h>	
#import "Node.h"
#import "PredictorNode.h"
#import "boolean.h"

@interface Sorter : SwarmObject
{

}

+createBegin: (id) aZone;
-createEnd;
-sort: (id) returnList;
-reverseSort: (id) returnList;
@end
























