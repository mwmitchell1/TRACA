#import "EnvironmentSwarm.h"
#import "Cell.h"
#import "Position.h"
#import <collections.h>
#define __USE_FIXED_PROTOTYPES__   // for gcc headers
#include <stdio.h>
#include <strings.h>

#define STRLENGTH 19

@implementation EnvironmentSwarm

+createBegin: (id) aZone
{
   EnvironmentSwarm * obj;
   id <ProbeMap> probeMap;
 
   obj = [super createBegin: aZone];
   obj->reward=0;
   obj->bumpPenalty = 0;

   obj->gridXSize=5;
   obj->gridYSize=5;

   obj->on=1;
   obj->correctCount=0;
   obj->incorrectCount=0;
   obj->predictionCount=0;
   obj->inputString = [String create: aZone];
   obj->lastInputString = [String create: aZone];
 
   obj->agentXpos=0;
   obj->agentYpos=0; 
   obj->rewardXpos=0;
   obj->rewardYpos=0;
   
   obj->problemFile = [String create: aZone];

   probeMap = [EmptyProbeMap createBegin: aZone];
   [probeMap setProbedClass: [self class]];
   probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameter
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridXSize"
         			     inClass: [self class]]];
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridYSize"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentXpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentYpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "printOn"
	 		     inClass: [self class]]
			setHideResult: 1]];
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "resetAgentPosition"
			     inClass: [self class]]
			setHideResult: 1]];
   [probeLibrary setProbeMap: probeMap For: [self class]];

   return obj;
}

-setString: (char *) aString
{
   [inputString setC: aString];
   return self;
}

-setAgent: (id) anAgent
{
   agentModel = anAgent;
   return self;
}

-createEnd
{
   return [super createEnd];
}

-buildObjects {
  Position * temp;
  int x = 0;

  [super buildObjects];

  [self loadFile];

  grid = [Grid2d createBegin: [self getZone]];
  [grid setSizeX: gridXSize Y: gridYSize];
  grid = [grid createEnd];

  [self setUpDisplay];

  // set up agent in first position

  if (relocatePosition == 0) {
    agentPosition = [uniformIntRand getIntegerWithMin: 0 
				    withMax: ([resetList getCount] - 1)];
    temp = [resetList atOffset: agentPosition];
    x = 0;
    for(x = 0; [positionArray atOffset: x] != temp; x++)
	  ;
    agentPosition = x;
  }
  else
    agentPosition =  (relocatePosition - 1);
  
  [[positionArray atOffset: agentPosition] setOccupied: True];
  return self;
}


-setUpDisplay 
{

  int x, y;

  cellCount =  (gridXSize * gridYSize);

  printf("\n cell count: %d", cellCount);
  cellArray = [Array create: [self getZone] setCount: cellCount];
  
  for (x = 0; x < gridXSize; x++) 
    for (y = 0; y < gridYSize; y++)
      { 
	Cell * cell;
	
	// Create the cell, set the creation time variables
	cell = [Cell createBegin: [self getZone]];
	[cell setGrid: grid];
	[cell setX: x Y: y];
	[cell setModel: self];
	cell = [cell createEnd];
	
	[cell buildObjects];
	
	[cellArray atOffset: (y + x * gridYSize) put: cell];
	printf("\n creating cell x: %d y: %d location: %d", x, y,
	       (y + x * gridYSize));
	[(Position *) [gridPositionArray atOffset: (y + x * gridYSize)] 
		      setCell: cell];
      }
  
  outputfp = fopen("agent.out","w");
  if (outputfp == NULL)
    printf("\n WARNING:  output file not opened");   
  fflush(stdout);
  
  return self;
}

-loadFile 
{

  float lineRead[9] = {0,0,0,0,0,0,0,0,0};
  Position * position;
  int index=0;
  int end=0;

  problemfp = fopen([problemFile getC], "r");

  if (problemfp == NULL) {
     printf("\n WARNING:  problem file not opened");   
     fflush(stdout);
  }

  // read in first line - grid size
  if ([self readLine: lineRead] == 0) {
     printf("\n WARNING: first line in problem file invalid");   
     fflush(stdout);
  }
  else {
    gridXSize = (int) lineRead[0];
    gridYSize = (int) lineRead[1];
    enumerative = (int) lineRead[2];
    relocatePosition = (int) lineRead[3];
    bumpPenalty = lineRead[4];
    positionArray = [Array create: [self getZone] 
			   setCount: (gridXSize * gridYSize)];
    // This is a bit of a cheat, parallel arrays are used the first
    // is to make it easier to associate cells with positions
    // the second for reference using position indexes.
    gridPositionArray = [Array create: [self getZone] 
			   setCount: (gridXSize * gridYSize)];
    // The reset list is used to select positions to place
    // the agent when reseting it position. This list is used
    // if the random replace option is turned on in the 
    // input file. Blocked positions and reward positions are excluded.
    resetList = [List create: [self getZone]]; 
  }

  // Read in subsequent lines for each position

  index = 0;
  end = [self readLine: lineRead];
  while (end != 0) { // Perhaps more reward lines to read
    position = [Position createBegin: [self getZone]];
    // first in array is index position
    [position setX: (int) lineRead[1] Y: (int) lineRead[2]];
    [position setLabel: lineRead[3]];
    if (end > 4) { // unoccupiable cells have not transitions
      [position setWest: (int) lineRead[4]];
      [position setNorth: (int) lineRead[5]];
      [position setEast: (int) lineRead[6]];
      [position setSouth: (int) lineRead[7]];
    }
    if (end == 9) {  // 9th item is reward 
      if (lineRead[8] != -99)  // Dummy reward to exclude as restart pos.
          [position setReward: (float) lineRead[8]];
      // exclude negative reward positions (other than -99)
      // from relocatable positions
      if ((relocatePosition == 0) && (lineRead[8] != -99) 
	  && (lineRead[8] <= 0)) 
	// it is occupiable
	[resetList addFirst: position];
    }
    else
      if ((relocatePosition == 0) && ([position getWest] != -1))
	  // it is occupiable
	[resetList addFirst: position];
    [position setModel: self];
    position = [position createEnd];    
    [position buildObjects];      

    [gridPositionArray atOffset: (int) (lineRead[2] + lineRead[1] * gridYSize) 
		   put: position];
    [position setPositionArray: positionArray];

    [positionArray atOffset: index put: position];
    index++;
    end = [self readLine: lineRead];
  }
  return self;
}

// read line reads in line of single character separated integers
// into an array. 
// It returns the array size in terms teh number fo data items read

-(int) readLine: (float[]) array
{
 
  char c = ' ';
  int end = 0;
  int index = 0;
  char bytes[256];

  // initialise arrays
  for (end=0; end < 256; end++)
    bytes[end] = 0;
  for (end=0; end < 9; end++)
    array[end] = 0;

  // read in a line (newline placed in array)  
  end = (int) fgets(bytes, 256, problemfp);
  if ((end == 0) || (end == -1))
    return 0;

  // Skip comment lines
  while ((bytes[0] == '/') && (end != 0)) {
    end = (int) fgets(bytes, 256, problemfp);
  }
  
  // Pull out values (index returned starts at 1)
  index = 0;
  if ((end != 0) && (end != -1)) {
    end = sscanf(bytes,"%f%c%f%c%f%c%f%c%f%c%f%c%f%c%f%c%f",
		 &array[0],&c,&array[1],&c,&array[2],&c,
		 &array[3],&c,&array[4],&c,&array[5],&c,
		 &array[6],&c,&array[7],&c,&array[8]);
    if (array[3] == 0)
      // a zero here indicates an unoccupiable cell
      index = 4;
    else
      if (array[8] != 0)
	index = 9;
      else 
	index = 8;
  }

  //  fputs(bytes, stdout);
  // fflush(stdout);

  return index;
}


-buildActions {

  [super buildActions];

  return self;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  return [self getSwarmActivity];
}


-getCellArray
{
   return cellArray;
}

-update
{ 
 //  must get the position of the selected action from the agent, then update
 //  environment accordingly.   A new input string is then passed 
 //  to the agent along with the reward from the last action.

   [inputString setC: ""];

// note add 1 to x and y positions to overcome zero input

   if (enumerative)
     [self convertEnumFrom: [[positionArray atOffset: agentPosition] getLabel]
	   to: inputString length: STRLENGTH];
   else
     [self convertFrom: [[positionArray atOffset: agentPosition] getLabel]
	   to: inputString length: STRLENGTH];

   return self;
}

-step
{
   if (on == 1)  // first input
   {
       on = 0;
       reward = 0;
       [self update];
   }
   else
       [self answer];
   if ([agentModel getDebug]) {
     printf("\n--------------------------------------------------------");
     printf("\n ENVIRONMENT: Input String is :%s", [inputString getC]);     
   }
   [agentModel setDetectorInput: inputString Reward: reward];
   [lastInputString setC: [inputString getC]];
   return self;    
}

-answer
{

   effectorAction = [agentModel getLastAction]; 

   switch (effectorAction)
   {
      case 0:
         agentPosition = [[positionArray atOffset:agentPosition]
			   moveAgentSouth];
         break;
      case 1:
         agentPosition = [[positionArray atOffset:agentPosition]
			   moveAgentNorth];
         break; 
      case 2:
         agentPosition = [[positionArray atOffset:agentPosition]
			   moveAgentEast];
         break;
      case 3:
         agentPosition = [[positionArray atOffset:agentPosition]
			   moveAgentWest];
         break;
      default:
            printf("\n Error: EnvironmentSwarm::answer Unspecified action");
   }

   [self update];

   reward = 0;    
   
   reward = [(Position *) [positionArray atOffset: agentPosition]
			  getReward];
       
   if ([agentModel getUseStrength])
       predictionCount++;
 
   if ([agentModel getDebug])
     printf("\n\t\t ENVIRONMENT: Action Selected %d received reward %f", effectorAction, reward);
   
   if (reward > 0)
   {
      if ([agentModel getUseStrength])
         correctCount++;
      if ([agentModel getDebug])
	printf("\n\t\t              Goal achieved");
      if ([agentModel getTest])
          reward = 0;
   }
   else
   {
      incorrectCount++;
      if ([agentModel getDebug])
	printf("\n\t\t ENVIRONMENT: No Goal Achieved %d", effectorAction);
   }

   if ((reward < 0) && ([inputString compare: lastInputString] == 0)) {
     reward = bumpPenalty;
   }

  [inputString setC: ""];

// note add 1 to x and y positions to overcome zero input

   if (enumerative)
     [self convertEnumFrom: [[positionArray atOffset: agentPosition] getLabel]
	   to: inputString length: STRLENGTH];
   else
     [self convertFrom: [[positionArray atOffset: agentPosition] getLabel]
	   to: inputString length: STRLENGTH];

   [agentModel setDetectorInput: inputString Reward: reward];

   if (![agentModel getExplore])
   {
     if ([agentModel getDebug])
       fprintf(outputfp,"Total moves: %d, Times goal achieved: %d", 
	       predictionCount, correctCount);
   }

   return self;
}


// Coverts directly to binary representation

-(void) convertFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "0000000000000000000"; 
    char temp1[STRLENGTH] = "";
    int x;

    for (x = 0; x<STRLENGTH;x++)
      temp[x] = '0';

    if (anInt >= 128)
    {
        temp[7] = '1';
        anInt = anInt - 128;
    }

    if (anInt >= 64)
    {
        temp[6] = '1';
        anInt = anInt - 64;
    }  

    if (anInt >= 32)
    {
        temp[5] = '1';
        anInt = anInt - 32;
    }
    
    if (anInt >= 16)
    {
        temp[4] = '1';
        anInt = anInt - 16;
    }

    if (anInt >= 8)
    {
        temp[3] = '1';
        anInt = anInt - 8;
    }

    if (anInt >= 4)
    {
        temp[2] = '1';
        anInt = anInt - 4;
    }

    if (anInt >= 2)
    {
        temp[1] = '1';
        anInt = anInt - 2;
    }
     
    if (anInt == 1)
    {
        temp[0] = '1';
    }
    else
        if (anInt > 0)    
           printf("\nWarning - 
                   EnvironmentSwarm::convertInt unable to convert integer");
    
    strncat(temp1,temp,length);
    [aString setC: temp1];
}    


// Converts to enumerative representation

-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "0000000000000000000"; 
    char temp1[STRLENGTH] = "";
    int x;

    for (x = 0; x<STRLENGTH;x++)
      temp[x] = '0';

    temp[anInt - 1] = '1';

    strncat(temp1,temp,length);
    [aString setC: temp1];
}    

-getGrid
{
  return grid;
}

-getString
{
   return inputString;
}

-(float) getPredictiveAccuracy
{
  float tempPredictionCount=0;
  float tempCorrectCount = 0;
  float accuracy=0;

  if (predictionCount > 0)
  {
     tempPredictionCount = predictionCount;
     tempCorrectCount = correctCount; 
     accuracy = ((100.0/tempPredictionCount) * tempCorrectCount);
  }
  if ([agentModel getDebug])
    printf("\n predictionCount, %d, correctCount, %d, accuracy: %f",
                   predictionCount, correctCount, accuracy);
  return accuracy;
}

-(int) getIncorrectCount
{
   return incorrectCount;
}

-printOn
{
   printf("\n Environment String: %s", [inputString getC]);
   return self;
}


-resetAgentPosition
{
  Position * temp = 0;
  int x = 0;

  [[positionArray atOffset: agentPosition] setOccupied: False];

  if (relocatePosition == 0) {
    agentPosition = [uniformIntRand getIntegerWithMin: 0 
				    withMax: ([resetList getCount] - 1)];
    temp = [resetList atOffset: agentPosition];
    x = 0;
    for(x = 0; [positionArray atOffset: x] != temp; x++)
	  ;
    agentPosition = x;
  }
  else
    agentPosition =  (relocatePosition - 1);

  [[positionArray atOffset: agentPosition] setOccupied: True];

  on = 1;
  return self;
}

-setProblem: (char *) fileName epochs: (int) epochs
{
  [problemFile setC: fileName];
  return self;
}

-timeOut {
  // not required
  return self;
}

@end






















