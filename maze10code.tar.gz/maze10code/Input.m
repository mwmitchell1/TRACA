#import "Input.h"
#import "Node.h"
#import "PredictorNode.h"
#import "TemporalNode.h"

@implementation Input 

+createBegin: (id) aZone
{
        Input * obj;
	obj = [super createBegin: aZone]; 	
	return obj; 
}

-setNode: (id) aNode
{
  node = aNode;
  return self;
}

-getNode;
{
  return node;
}

-(boolean) getOn
{
   return on;
}
 
-setOn: (boolean) aBoolean
{
   on = aBoolean;
   return self;
}

-createEnd
{
   return [super createEnd];
}

-removeSelf: (id) owner
{
    [node removeOwner: owner];
    return self;
} 

-checkActive: (boolean *) aBoolean
{
  // this expects aBoolean to be true.  If the NaryNode calling this is to
  // fire aBoolean must still be true when all inputs have been asked.

   
   if (*aBoolean == False)
       return self;

   if ([node getRealActive])
   {
       if (on == False)
          *aBoolean = False;
   } 
   else
   {
       if (on == True)
          *aBoolean = False;
   }

   return self; 
}   

-addOwnerShare: (double *) aDouble
{
   [node addOwnerShare: (double *) aDouble];
   return self;
}

-checkMatched: (boolean *) aBoolean
{
  // this expects aBoolean to be true.  If the NaryNode calling this is to
  // fire aBoolean must still be true when all inputs have been asked.

  // In this case matched is true when the node has reached activation level 3
  // i.e its prediction was correct.

   if (*aBoolean == False)
       return self;

   // June 2 2002 - added for temporal nodes.

   if ([node respondsTo: M(isTemporal)]) {
     if ([(TemporalNode *) node getTemporallyMatched])
       *aBoolean = True;
     else
       *aBoolean = False;
   } else {
     if ([node getMatched])
       *aBoolean = True;
     else
       *aBoolean = False;
   }

   return self; 
}   

-(boolean) checkMatched
{

   // June 2 2002 - added for temporal nodes.

  if ([node respondsTo: M(isTemporal)]) {
     if ([node getTemporallyMatched])
       return True;
     else
       return False;
  } else {
    if ([node getMatched])
      return True;
    else
      return False;
  }
}   

-printOn
{
   printf("\n\t InputNode number: %ld, On: %d, matched %d, group: %ld", 
                 [node getNodeNumber], on, [node getMatched], 
                 [[node getGroup] getNodeNumber]);

   return self;
}

@end





