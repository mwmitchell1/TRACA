#import "Trend.h"

@implementation Trend

// This implements the cox-stuart test for trend

// NOTE: this can in fact be made far more efficient since we are only using a small
// number of cases.  Given the number of cases and the significance level we are 
// interested in, we just need to count the number of pluses and minus and see if they
// are above the minimum number needed to be significant for the parameters we are
// working with (i.e number of cases, significance). 

+createBegin: aZone;
{
   return [super createBegin: aZone];
}

-setAgentModel: (id) aModel
{
  agentModel = aModel;
  return self;
}

// This is n; the number of elements in the array - not the 
// number of pairs.  Also a trend will be reported until the number
// max number of cases reached.

-setMaxObservations: (int) obs {
  maxObservations = obs;
  return self;
}

// We use a two-sided test - so significance will be divided by 2.

-setSignificance: (double) aDouble {
  significance = aDouble / 2;
  return self;
}

-createEnd
{
  return [super createEnd];
}

-buildObjects
{

  trendExists = True;
  observations = [Array create: [self getZone] 
			setCount: maxObservations];
  inputObservations = [Array create: [self getZone] 
			setCount: maxObservations];
  observationCount = 0;
  totalObservations = 0;
  totalInputObservations = 0;
  changed = False;
  printing = False;
 
  signif = 0;
  minus = 0;
  plus = 0;

 
  arrayStart = 0;

  return self;
}

// Do this for trendForThis after buildobjects

-calculateMiddle {

  if ((maxObservations % 2) != 0) {
    middleCount = (maxObservations + 1) / 2;
    maxObservations--; // we discard the middle case
  }
  else
    middleCount = maxObservations / 2;

  return self;
}


// Since observations are in fact pairs - until we get to our observationCount
// we are only adding one element of the observation pair.

// This is also used to see if the current node has an upward trend in its 
// value as an alternative to a fixed activationCount.


-addObservation: (double) obs
{
  Double * obs1 = nil;

  if ([agentModel getLearning] == 0)  // 2021
    return self;

  // June 2 2002 - truncate obs to be within variance

  obs = [self getTruncatedObs: obs];

  obs1 = [Double createBegin: [self getZone]];
  [obs1 setValue: obs];
  [obs1 buildObjects];
  obs1 = [obs1 createEnd];

  totalObservations++;
  changed = True;

  if (observationCount < maxObservations) {
    [observations atOffset: observationCount put: obs1];
    observationCount++;
  }
  else {
    if (totalObservations > maxObservations)
      [[observations atOffset: arrayStart] drop];
    [observations atOffset: arrayStart put: obs1];
    if (arrayStart == (maxObservations - 1)) {
      arrayStart = 0;
    }
    else
      arrayStart++;
  }
  return self;
}

-addInputObservation: (double) obs
{
  Double * obs1 = nil;

  if ([agentModel getLearning] == 0)  // 2021
    return self;

  obs = [self getTruncatedObs: obs];

  obs1 = [Double createBegin: [self getZone]];
  [obs1 setValue: obs];
  [obs1 buildObjects];
  obs1 = [obs1 createEnd];

  totalInputObservations++;

  if (observationCount < maxObservations) {
    [inputObservations atOffset: observationCount put: obs1];
  }
  else {
    if (totalInputObservations > maxObservations)
      [[inputObservations atOffset: arrayStart] drop];
    [inputObservations atOffset: arrayStart put: obs1];    
  }

  return self;
}


-(boolean) enoughObservations {
  if (observationCount >= maxObservations)
    return True;
  return False;
}

// in the following we always do a two-sided test (for both up or down trend)
// this means we must divide prob by 2.  
// We use a circular array, so more recent cases displace earlier ones.
// use this method to see if a node's value is increasing.

-(boolean) trendExistsForThis
{
  int x = 0;
  int plusCount = 0;
  int minusCount = 0;
  int totalCount = 0;
  int leastFrequent = 0;
  int pointerOne = 0;
  int pointerTwo = 0;

  if (removed)
    return False;

  // Don't use trend if activationThreshold set
  //  if ([agentModel getActivationThreshold] > 0)
  //  return True;

  // Once no trend exists - always return false.
  // if (!trendExists)
  //  return False;

  // if we call this prematurely - assume no trend exists as we cannot 
  // determine otherwise.

  // Jun 15 2001 - changed to False from true

  if (observationCount < maxObservations)
    return False;
 
  // count the pluses and minuses

  pointerOne = arrayStart;
  pointerTwo = arrayStart + middleCount;
  if (pointerTwo >= observationCount) {
    pointerTwo = ((arrayStart + middleCount) - observationCount);
  }

  for (x = 0; x < (maxObservations / 2);x++) {
    if (pointerOne == observationCount)
      pointerOne = 0;
    if (pointerTwo == observationCount)
      pointerTwo = 0;

    if ([(Double *) [observations atOffset: pointerTwo] getValue] >
	[(Double *) [observations atOffset: pointerOne] getValue]) {
      if ([agentModel getDebug]) {
	printf("\n %f", [(Double *) [observations atOffset: pointerTwo] getValue]);
	printf(" %f, +", [(Double *) [observations atOffset: pointerOne] getValue]);
      }
      plusCount++;
    }
    if ([(Double *) [observations atOffset: pointerTwo] getValue] <
	[(Double *) [observations atOffset: pointerOne] getValue]) {
      if ([agentModel getDebug]) {
	printf("\n %f", [(Double *) [observations atOffset: pointerTwo] getValue]);
	printf(" %f, -", [(Double *) [observations atOffset: pointerOne] getValue]);
      }
      minusCount++; 
    }
    if ([(Double *) [observations atOffset: pointerTwo] getValue] !=
	[(Double *) [observations atOffset: pointerOne] getValue])
      totalCount++;
    pointerOne++;
    pointerTwo++;
  }

  // For a two sided test - test for the probablity of the 
  // least frequently occuring sign occuring given the sample size
  // 

  if (plusCount > minusCount)
    leastFrequent = minusCount;
  else
    leastFrequent = plusCount;
  
  plus = plusCount;
  minus = minusCount;

  // The following two lines are for printOn only
  //  if ([agentModel getDebug]) {
    signif = [self cumulativeBinomial: leastFrequent totalObs: totalCount 
		   prob: 0.5];
    // }

  // Check if the probability of having k occurances in n samples
  // being less than 0.5 is less than or equal to our significance.

  if ([self cumulativeBinomial: leastFrequent totalObs: totalCount 
	    prob: 0.5] <= significance) {
    return True;
  }
  else {
    trendExists = False;
    return False;
  }
}  


-(boolean) trendExists
{
  int x = 0;
  int plusCount = 0;
  int minusCount = 0;
  int totalCount = 0;
  int leastFrequent = 0;
  int pointerOne = 0;
  int pointerTwo = 0;

  if (removed)
    return False;

  // Don't use trend if activationThreshold set
  //  if ([agentModel getActivationThreshold] > 0)
  //  return True;

  // Once no trend exists - always return false.
  // if (!trendExists)
  //  return False;

  // if we call this prematurely - assume no trend exists as we cannot 
  // determine otherwise.

  // Jun 15 2001 - changed to False from true

  if (observationCount < maxObservations)
    return False;
 
  if (printing)
    printf("\n Counting: ");

  // count the pluses and minuses

  pointerOne = arrayStart;

  //  for (x = 0; x < (maxObservations / 2);x++) {
  for (x = 0; x < maxObservations;x++) {
    if (pointerOne == observationCount)
      pointerOne = 0;

    if ([(Double *) [observations atOffset: pointerOne] getValue] >
	[(Double *) [inputObservations atOffset: pointerOne] getValue]) {
      if ([agentModel getDebug]) {
	printf("\n %f", [(Double *) [inputObservations atOffset: pointerOne] getValue]);
	printf(" %f, +", [(Double *) [observations atOffset: pointerOne] getValue]);
      }
      if (printing)
        printf(" plus ");
      plusCount++;
    }
    if ([(Double *) [observations atOffset: pointerOne] getValue] <
	[(Double *) [inputObservations atOffset: pointerOne] getValue]) {
      if ([agentModel getDebug]) {
	printf("\n %f", [(Double *) [observations atOffset: pointerOne] getValue]);
	printf(" %f, -", [(Double *) [observations atOffset: pointerOne] getValue]);
      }
     if (printing)
        printf(" minus ");
      minusCount++; 
    }
    if ([(Double *) [inputObservations atOffset: pointerOne] getValue] !=
	[(Double *) [observations atOffset: pointerOne] getValue])
      totalCount++;
    pointerOne++;
    pointerTwo++;
  }

  if (printing)
    printf(" total cases: %d ", totalCount);

  // For a two sided test - test for the probablity of the 
  // least frequently occuring sign occuring given the sample size
  // 

  if (plusCount > minusCount)
    leastFrequent = minusCount;
  else
    leastFrequent = plusCount;
  
  plus = plusCount;
  minus = minusCount;

  // The following two lines are for printOn only
  //  if ([agentModel getDebug]) {
    signif = [self cumulativeBinomial: leastFrequent totalObs: totalCount 
		   prob: 0.5];
    // }

  // Check if the probability of having k occurances in n samples
  // being less than 0.5 is less than or equal to our significance.

  if ([self cumulativeBinomial: leastFrequent totalObs: totalCount 
	    prob: 0.5] <= significance) {
    return True;
  }
  else {
    trendExists = False;
    return False;
  }
} 

-(boolean) isTrendUp
{
  if (removed)
    return False;

  if (plus > minus)
    return True;
  return False;
}

// If the node is always correct, the trend and trendForThis
// will continue until it reaches 1.0 which could take some time.

-(boolean) isConverging {
  if ((observationCount == maxObservations)
      && (minus == 0))
    return True;
  return False;
}

// For efficiency we pass in the factorial of total obs

-(double) binomial: (int) obs totalObsFac: (double) totalObsFac 
	  totalObs: (int) totalObs prob: (double) aProb 
{
  int otherObs = 0;
  double binomial = 0.0;

  otherObs = totalObs - obs;
  binomial = totalObsFac / ([self factorial: otherObs] 
					* [self factorial: obs]);

  binomial = binomial * [self power: aProb to: (double) obs]
    * [self power: (1 - aProb) to: (double) otherObs];

  return binomial;
}

-(double) cumulativeBinomial: (int) obs totalObs: (int) totalObs
			prob: (double) aProb 
{
  double cumulativeBinomial = 0;
  int x = 0;
  double totalObsFac =0 ;

  totalObsFac= [self factorial: totalObs];

  for(x = 0;x <= obs; x++) {
    cumulativeBinomial = cumulativeBinomial + [self binomial: x 
	       totalObsFac: totalObsFac totalObs: totalObs prob: aProb];
  }
  return cumulativeBinomial;
}

-(double) factorial: (double) n
{

  if (n <= 1.0)
    return 1.0;
  else
    return (n * [self factorial: (n - 1.0)]);
}

-(double) power: (double) mantissa to: (double) exponent
{
  int x = 0;
  double result = 0;

  result = mantissa;
  for (x = 1; x < exponent; x++)
    result = result * mantissa;

  return result;
}

-printOn
{
  boolean tempTrendExists;
  int x = 0;

  if (removed) {
    printf("\n Trend object removed");
    return self;
  }

  printing = True;

  tempTrendExists = trendExists;
  trendExists = True;
  [self trendExists]; // to calculate pluses
  trendExists = tempTrendExists;

  // if (changed) {
    printf("\n Trend Observations at %d: start: %d middle: %d obs: %d totalObs: %d\n\t", 
	   0 , arrayStart, middleCount, observationCount, totalObservations);
    printf("\n pluses: %d, minus: %d, signif: %f significance: %f\n", 
	   plus, minus, signif, significance); 

    for (x = 0;x < observationCount ;x++) {
      if ([observations atOffset: x] != nil)
        printf("%f,", [(Double *) [observations atOffset: x] getValue]);
      else
        printf("N,");
    }
 
    printf("\n inputs: ");
    for (x = 0;x < observationCount ;x++)  {
      if ([inputObservations atOffset: x] != nil)
        printf("%f,", [(Double *) [inputObservations atOffset: x] getValue]);
      else
        printf("N,");
    }

    // temporarily reset trendExists so method will execute  
    tempTrendExists = trendExists;
    trendExists = True;
    printf("\n Trend Exists: %d isup: %d", [self trendExists], 
	   [self isTrendUp]);
    trendExists = tempTrendExists;

    printf("\n end comparisons: ");
    changed = False;
    printing = False;
    // }
  return self;
}

// Sep 19 2001 - added this method

-printThisTrendOn
{

  boolean tempTrendExists;

  int x = 0;

  if (removed) {
    printf("\n Trend object removed");
    return self;
  }

  // if (changed) {
    printf("\n Trend Observations at %d: start: %d middle: %d obs: %d totalObs: %d\n\t", 
	   0 , arrayStart, middleCount, observationCount, totalObservations);
    printf("\n pluses: %d, minus: %d, signif: %f significance: %f\n", 
	   plus, minus, signif, significance); 
    for (x = 0;x < observationCount ;x++) {
      if ([observations atOffset: x] != nil)
        printf("%f,", [(Double *) [observations atOffset: x] getValue]);
      else
        printf("N,");
    }

    tempTrendExists = trendExists;
    trendExists = True;
    printf("\n Trend Exists: %d ", [self trendExistsForThis]);
    trendExists = tempTrendExists;

    printf("\n end comparisons: ");
    changed = False;
    // }
  return self;
}

-(int) getTotalObservations
{
  return totalObservations;
}

-removeSelf
{
  removed = True;

  [inputObservations forEach: M(drop)];
  [inputObservations drop];
  [observations forEach: M(drop)];
  [observations drop];
  
  return self;
}

-(double) getTruncatedObs: (double) obs {
  if (obs > 1.0)
    return 1.0;
  return obs;
}


@end








