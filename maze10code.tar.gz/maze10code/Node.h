#import <objectbase.h>				  // we inherit swarm objects
#import <objectbase/SwarmObject.h>
#import <space.h>				  // we use Space features
#import "boolean.h"

@interface Node : SwarmObject
{

  // Accumulated strength from rewards

        double rewardStrength;
        double Qreturn;
        double hypQreturn;

	// hypothetical variables
        double hypStrength;

        id hypPredictorList;
	id hypActivePredictorList;
        id hypSuspendedPredictorList;
        id hypPassivePredictorList;
        boolean hypActiveSupressed;
        boolean hypSupressed;
        boolean hypLastActiveSupressed;  
        int hypActivePredictorCount;
        int hypSuspendedPredictorCount;
        boolean hypMatched;
	boolean hypActive;
 
	boolean realActive;
	boolean lastRealActive;
	boolean previousRealActive;
        boolean matched; 
	boolean activeActionSupressed;
	boolean lastActiveActionSupressed;
        
        boolean removed;
        boolean copy;

	id predictorList;
	id activePredictorList;
        id suspendedPredictorList;
        id passivePredictorList;
	id activeOwnerList;
	id finalTerminalOwnerList;

// proxy stuff
        id proxyOwnerList;
	id temporalOwnerList;
        id proxyGroup;

   // At this stage the passiveOwnerList is not used, may never be.

        boolean suspended;
        boolean supressed;
        boolean narySupressed;
        boolean updateTemporalSupressed;
        boolean activeSupressed;
        boolean activeTemporallySupressed;
        boolean lastActiveTemporallySupressed;
        boolean temporallySupressed;
        boolean lastTemporallySupressed;
        boolean lastActiveSupressed;
        boolean temporallyActiveSupressed;
        boolean lastTemporallyActiveSupressed;

        id suspendedOwnerList;

        id nodeGroup;    // DetectorNodes don't need this

	long  nodeNumber;
        int activePredictorCount;
        int suspendedPredictorCount;
        int predictorCount;
       
	int x, y, color;
	id grid;
        id <Raster> raster; 
        id agentModel;
}

+createBegin: (id) aZone;
-(boolean) setNodeNumber: (long) aNumber;
-createEnd;
-buildObjects;
-(long) getNodeNumber;
-realDeactivate;
-clearPredictors;
-match: (boolean) aBoolean;
-sendPredictorsReturn;
-temporalConnect;
-connect;
-temporalConnectActive;
-connectAndActive;
-connectTemporal: (id) tempList;
-connectAnd: (id) tempList;
-connectTemporal: (id) node1 And: (id) node2; 
-extendTemporal: (id) node1;
-connect: (id) node1 And: (id) node2;
-(boolean) addPredictor:  (id) aNode;
-getPredictorList;
-(boolean) removePredictor: (Node *) aNode;
-(boolean) activePredictedBy: (Node *) aNode;
-(boolean) passivePredictedBy: (Node *) aNode;
-(boolean) suspendedPredictedBy: (Node *) aNode;
-getActiveOwnerList;
-getSuspendedOwnerList;
-(boolean) clearActivePredictor: (Node *) aNode;
-(boolean) clearPassivePredictor: (Node *) aNode;
-(boolean) clearSuspendedPredictor: (Node *) aNode;
-addActiveOwner: (Node *) aNode;
-addFinalTerminalOwner: (id) anOwner;
-removeFinalTerminalOwner: (id) anOwner;
-getFinalTerminalOwnerList;
-addSuspendedOwner: (id) aNode;
-(boolean) removeOwner: (Node *) aNode;
-removeSuspendedOwner: (id) aNode;
-removeActiveOwner: (id) aNode;
-removeSuspended;
-(boolean) isSuspended;
-(boolean) setSupressed: (boolean) aBoolean;
-(boolean) setNarySupressed: (boolean) aBoolean;
-(boolean) resetActiveSupressed: (boolean) aBoolean;
-(boolean) resetActiveActionSupressed: (boolean) aBoolean;
-(boolean) setActiveSupressed: (boolean) aBoolean;
-setActiveActionSupressed: (boolean) aBoolean for: (id) anEffector;
-(boolean) setUpdateTemporalSupressed: (boolean) aBoolean;
-(boolean) setTemporallySupressed: (boolean) aBoolean;
-(boolean) getTemporallySupressed;
-(boolean) getUpdateTemporalSupressed;
-(boolean) getSupressed;
-(boolean) getNarySupressed;
-(boolean) getActiveSupressed;
-(boolean) getActiveActionSupressed;
-(boolean) getLastActiveSupressed;
-(boolean) getLastActiveActionSupressed;
-(boolean) getActiveTemporallySupressed;
-(boolean) getLastActiveTemporallySupressed;
-(boolean) resetActiveTemporallySupressed: (boolean) aBoolean;
-(boolean) setActiveTemporallySupressed: (boolean) aBoolean;
-addProxyOwner: (id) aNode;
-removeProxyOwner: (id) aNode;
-getProxyOwnerList;
-addTemporalOwner: (id) aNode;
-removeTemporalOwner: (id) aNode;
-getTemporalOwnerList;
-getActivePredictorList;
-getSuspendedPredictorList;
-getPassivePredictorList;
-(boolean) setX: (int) newX Y:(int) newY;
-setModel: (id) aModel;
-getModel;
-temporalUpdate;
-temporalCorrect;
-(boolean) getMatched;
-(boolean) setMatched: (boolean) aBoolean;
-(boolean) getRealActive;
-(boolean) getLastRealActive;
-(boolean) setPreviousRealActive: (boolean) aBoolean;
-(boolean) getPreviousRealActive;
-(boolean) setRealActive: (boolean) aBoolean;
-setRaster: (id <Raster>) aRaster;
-setGrid: (id) aGrid;
-(id <Grid2d>) getGrid;
-incrementPredictorCount;
-printMatched;
-printOwners;
-printNodeNumber;
-(int) getActivePredictorCount;
-setColor: (int) aColor;
-(void) die;
-getProxyGroup;
-setProxyGroup: (id) aGroup;
-drawSelfOn: (id <Raster>) aRaster;
-(boolean) reset;
-(boolean) getCopy;
-getGroup;
-printOn;

-hypPayPredictors;
-hypSendPredictorsReturn;
-getHypActivePredictorList;
-getHypSuspendedPredictorList;
-getHypPassivePredictorList;
-(boolean) hypActivePredictedBy: (Node *) aNode;
-(boolean) hypPassivePredictedBy: (Node *) aNode;
-(boolean) hypSuspendedPredictedBy: (Node *) aNode;
-(boolean) clearHypActivePredictor: (Node *) aNode;
-(boolean) clearHypPassivePredictor: (Node *) aNode;
-(boolean) clearHypSuspendedPredictor: (Node *) aNode;
-clearHypPredictors;
-(double) getHypStrength;
-(boolean) setHypSupressed: (boolean) aBoolean;
-(boolean) setHypActiveSupressed: (boolean) aBoolean;
-(boolean) getHypSupressed;
-(boolean) getHypActiveSupressed;
-(boolean) getHypMatched;
-(boolean) setHypMatched: (boolean) aBoolean;
-(boolean) hypActivate;
-(boolean) setHypActive: (boolean) aBoolean;
-(boolean) getHypActive;
-(boolean) hypDeactivate;
-hypReset;
@end
























