#import "UnaryNode.h"
#import "NaryNode.h"
#import "NodeGroup.h"
#import "Trend.h"

/* Must set family of unary node in create phase 

   node addInput and removeInput are redifined here, although the predictor 
   class methods could be used this is more effecient as unary nodes have only    one input. It also allows for type checking, as UnaryNodes input must be a
   DetectorNode (Note: the prediction must also be a DetectorNode, but no type
   checking is used here). 
*/

@implementation UnaryNode

+createBegin: (id) aZone
{
   return [super createBegin: aZone];
}

-createEnd
{
   if (family <= 0)
       [InvalidCombination raiseEvent: "Unary node family not set"];
	
   return self;
}

-buildObjects
{
   [super buildObjects];
   steadyState = False;
   suspended = True;
   [agentModel addSubordinated];

   return self;
}

-realDeactivate
{

  // This was added for tasks which end a set point. The Unary nodes at the 
  // end point have no predictive nodes, so nodes which predict them cannot
  // determine if their prediction was matched or not. Really it only matters
  // when suspendLastCorrect is selected, but could also speed learning 
  // (by one trial) anyway. 

  if ([agentModel getDebug])
    printf("\n Unary Group: %d Node %ld realDeactivate", 
	   [[self getGroup] getNodeNumber],
	   nodeNumber);

  [super realDeactivate];

// This next piece of code could be made more efficient by only doing it once
// nodes have fired.  In this it may be better to move some of the code
// into the owner ( and maybe move this bit) because otherwise, if the input
// node is a not connection, their could be a delay in setting the owner to 
// active

   return self;
}

-match: (boolean) aBoolean
{
   // Pass this message to owners who will update predictive strength 
   // if boolean is True, and reward strength based on the reward. 
   // Predictive nodes call connect to make connections based on correctness  
   // or incorrectness or predictors

   if (proxyGroup == nil)
      return self;

   if ([agentModel getDebug])
     printf("\n Unary node %ld matching", nodeNumber);
 
   [self setMatched: aBoolean];

   if ([agentModel getDebug]) {
     printf("\n Unary node %ld finished matching", nodeNumber);
     printf("\n Sending match:by: to proxyOwners");
   }

   if ([[self getProxyOwnerList] getCount] > 0)
       [[self getProxyOwnerList] forEach: M(match:by:) 
 			:(void *) aBoolean :(void *) self];

   if ([agentModel getDebug])
     printf("\n proxyOwnerCount: %d", [[self getProxyOwnerList] getCount]);

   if (nodeGroup == nil) {
     if (aBoolean)  // Don't send these messages to group
                    // they are handled by proxy
     {      
        [activePredictorList forEach: M(correct)];
	// May 19 2000 Uncommented line below 
	[passivePredictorList forEach: M(correct)];
        [suspendedPredictorList forEach: M(correct)];
     }
     else
     {
        [activePredictorList forEach: M(incorrect)];
	// May 19 2000 Uncommented line below 
	[passivePredictorList forEach: M(incorrect)];
        [suspendedPredictorList forEach: M(incorrect)];
     }
   }
      
  return self;
}
	
-(boolean) addInput: (DetectorNode *) anInput
{
   if (anInput == nil)
      return False;
   inputDetector = anInput;
   return True;
}

-removeSelf: (id) aNode
{
   id tempActiveList;
   id tempSuspendedList;
   id tempPredictorList;  

   if ([agentModel getDebug])
     printf("\n removing Unary node: %ld", nodeNumber);

   if (!removed)
   {
       removed = True;

       if (proxyGroup == nil) {
	 if ([nodeGroup getMostFrequentPositive: self] == self) 
	   [nodeGroup setMostFrequentPositive: self to: nil];
	 
	 if ([nodeGroup getMostFrequentNegative: self] == self)
	   [nodeGroup setMostFrequentNegative: self to: nil];
       }

       [(AgentModelSwarm *) agentModel removeNode: self];
       if (proxyGroup == nil)
          [prediction removePredictor: self];
     
       if (nodeGroup != nil)
          [(NodeGroup *) nodeGroup removeNode: self]; 
       else 
       {
           tempPredictorList = [predictorList copy: [self getZone]];
           [tempPredictorList forEach: M (removeSelf:) : (id) nil];
           [tempPredictorList drop];    
       }

       [inputDetector removeOwner: self]; 

       tempActiveList = [[self getActiveOwnerList] copy: [self getZone]];
       tempSuspendedList = [[self getSuspendedOwnerList] copy: [self getZone]];

       if ([tempActiveList getCount] > 0)
	 [tempActiveList forEach: M(removeSelf:) :(id) nil];
       if ([tempSuspendedList getCount] > 0)
	 [tempSuspendedList forEach: M(removeSelf:) :(id) nil];

       [tempActiveList drop];
       [tempSuspendedList drop];

       [[agentModel getDropList] addLast: self];

    }
    return self;
}


-(boolean) removeInput: (DetectorNode *) anInput
{
    if (anInput == nil)
	return False;
    inputDetector = nil;
    return True;
}


-narySupress
{

  if ([agentModel getDebug])
    printf("\n node %ld setting nary supressed true", nodeNumber);

   [self setNarySupressed: True];

   /*
   if (nodeGroup != nil)
       [nodeGroup setNarySupressed: True for: [self getSupported]];
   else
   */
   [proxyGroup setNarySupressed: True for: [self getSupported]];

   return self;
}

-supress
{

   [self setSupressed: True];

   if (nodeGroup != nil)
       [nodeGroup setSupressed: True for: [self getSupported]];
   else
       [proxyGroup setSupressed: True for: [self getSupported]];

   return self;
}

-temporalSupress
{

  if ([agentModel getDebug])
    fprintf(stdout, "\n Unary node %ld setting temporalSupressed to True", 
	    nodeNumber);

   [self setTemporallySupressed: True];

   if (nodeGroup != nil)
       [nodeGroup setTemporallySupressed: True for: [self getSupported]];
   else
       [proxyGroup setTemporallySupressed: True for: [self getSupported]];

   return self;
}

-hypSupress
{

   [self setSupressed: True];

   if (nodeGroup != nil)
       [nodeGroup setHypSupressed: True for: [self getSupported]];
   else
       [proxyGroup setHypSupressed: True for: [self getSupported]];

   return self;
}

-updateTemporalSupress
{

   [self setUpdateTemporalSupressed: True];
   [proxyGroup setUpdateTemporalSupressed: True for: [self getSupported]];
   [inputDetector setUpdateTemporalSupressed: True];

   return self;
}

-activeSupress
{
  if ([agentModel getDebug])
    fprintf(stdout, "\n Unary node %ld setting activeSupressed True", 
	    nodeNumber);

   [self setActiveSupressed: True];
   [proxyGroup setActiveSupressed: True for: [self getSupported]];

   return self;
}

-activeTemporalSupress
{

  if ([agentModel getDebug])
    fprintf(stdout, "\n Unary node %ld setting activeTemporalSupressed True",
	    nodeNumber); 

  [self setActiveTemporallySupressed: True];
  [proxyGroup setActiveTemporallySupressed: True for: [self getSupported]];

   return self;
}


-hypActiveSupress
{

   [self setHypActiveSupressed: True];
   [proxyGroup setHypActiveSupressed: True for: [self getSupported]];

   return self;
}


-(boolean) setFamily: (int) aFamily
{
   if (aFamily <= 0)
       return False;
   family = aFamily;
   return True;
}

-isUnary
{
   return self;
}


-copy: (id) aZone
{
   UnaryNode * node;
  
   node = [UnaryNode createBegin: aZone];
   [node setGrid: grid];
   [node setX: x Y: y];
   [node setColor: color];
   [node setModel: agentModel];
   [node setFamily: family];
   if (nodeGroup != nil) {
     [node setSuspended: [[nodeGroup getProxyNode] getSuspended]];
     [node setSteadyState: [[nodeGroup getProxyNode] getSteadyState]];
   }
   [node setSuspended: [self getSuspended]];
   [node setSteadyState: [self getSteadyState]];
   [node setNodeNumber: [agentModel getNextNodeNumber: node]];
   node = [node createEnd]; 
   
   [node buildObjects];
   
   [node addInput: inputDetector];

   [node setSupressed: supressed];
   [node setNarySupressed: narySupressed];
   [node setTemporallySupressed: temporallySupressed];
   [node setMatched: matched];

   [node setPrediction: prediction];

   if ([agentModel getDebug]) {
     printf("\n Adding node %ld as owner to input detector", 
	    [node getNodeNumber]);
     [node printOn];
   }

   if ([self isSuspended])
      [inputDetector addSuspendedOwner: node]; 
   else
      [inputDetector addActiveOwner: node];  

   [node setSupported: [agentModel getSelectedEffector]];
   [agentModel addNode: node];

   return node;
}

-getInputDetector
{
   return inputDetector;
}

-(void) die
{
   if (removed)
      [super die]; 
}

-drawSelfOn: (id <Raster>) aRaster 
{
   [aRaster drawPointX: x Y: y Color: color];
   return self;
}

-printOn
{
  // First Unary nodes in each group do not have a supported effector.

  int position = 99;
  long predicted = 99;
  long group = 99;

  if (supported != nil)
    position = [supported getPosition];
  if (prediction != nil)
    predicted = [prediction getNodeNumber];
  if (nodeGroup != nil)
    group = [nodeGroup getNodeNumber];
  if (proxyGroup != nil)
    group = [proxyGroup getNodeNumber];

//  Note: average strength used as real strength before it is updated

    printf("\nUnary node family: %d, number: %ld, depValue: %f indepValue: %f, \n group: %ld, \n copy: %d\nNary owners: %d, Nary predictors: %d, \n prediction (Node No.): %ld.  \n suspended: %d, temporallySuspended: %d, \n\t steadyState: %d, maxValue: %f activationCount: %ld\n correctCount: %ld, predictiveAccuracy: %f, avgRewardStrength: %f  \nEffector: %d, matched: %d, realActive: %d, correct: %d, Hyp strength: %f , temporallySuspended: %d", 
               family, nodeNumber, dependentValue,
                independentValue, group, copy,
              ([[self getActiveOwnerList] getCount] + 
                [[self getSuspendedOwnerList] getCount])
              , [predictorList getCount], predicted, 
                [self getSuspended],temporallySuspended,
              steadyState, [self getMaxDependent],
	      ownActivationCount,ownCorrectCount,
              [self getDependentAccuracy], rewardStrength,
              position, matched,realActive,correct,
               hypStrength, [self getTemporallySuspended]);

    [trendForThis printThisTrendOn];

    fflush(stdout);

    return self;
}


-hypMatch: (boolean) aBoolean
{
   // Pass this message to owners who will update predictive strength 
   // if boolean is True, and reward strength based on the reward. 
   // Predictive nodes call connect to make connections based on correctness  
   // or incorrectness or predictors

   if ((hypActivePredictorCount > 0) || (hypSuspendedPredictorCount > 0))
   {    
      [self setHypMatched: aBoolean];

      if ([[self getActiveOwnerList] getCount] > 0)
        [[self getActiveOwnerList] forEach: M(hypMatch:) :(void *) aBoolean];

      if ([[self getSuspendedOwnerList] getCount] > 0)
       [[self getSuspendedOwnerList] forEach: M(hypMatch:) :(void *) aBoolean];

      if ([[self getProxyOwnerList] getCount] > 0)
         [[self getProxyOwnerList] forEach: M(hypMatch:) :(void *) aBoolean];
   }
    
  return self;
}

-(boolean) hypDeactivate
{

   [super hypDeactivate];

   return True;
}


-(boolean) getActivated {
  if (activated)
    return True; // once activated always activated
  if (![trendForThis trendExistsForThis] && [trendForThis enoughObservations])
    activated = True;
  return activated;
}

@end




