#import "AgentModelSwarm.h"
#import "Cell.h"
#import "Node.h"
#import "stdio.h"
#import "boolean.h"

@interface EnvironmentSwarm  : Swarm
{
	id inputString;
	id lastInputString;
	id problemFile;
	
	id positionArray;
	id gridPositionArray;
	id resetList;

        id agentModel;
        double reward;
	double bumpPenalty;
        int effectorAction;
        id <Grid2d> grid;			     // objects representing 
        int cellCount;
        id cellArray;
        int gridXSize, gridYSize;
        int correctCount, predictionCount, incorrectCount;

        FILE *problemfp, *outputfp;

        int agentXpos;
        int agentYpos;

        int rewardXpos;
        int rewardYpos;
	int relocatePosition;
	boolean enumerative;  
	int agentPosition;
	int on;
}

+createBegin: (id) aZone;
-setAgent: (id) anAgent;
-setString: (char *) aString;
-createEnd;
-buildActions;
-setUpDisplay;
-loadFile;
-(int) readLine: (float[]) array;
-activateIn: (id) swarmContext;
-getGrid;
-getCellArray;
-step;
-update;
-answer;
-(void) convertFrom: (int) anInt to: (id) aString length: (int) length;
-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length;
-getString;
-(float) getPredictiveAccuracy;
-printOn;
-resetAgentPosition;
-setProblem: (char *) fileName epochs: (int) epochCount;
-timeOut;
@end






