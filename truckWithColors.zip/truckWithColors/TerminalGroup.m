#import "TerminalGroup.h" 
#import "NodeGroup.h" 
#import "AgentModelSwarm.h"

@implementation TerminalGroup

// a nodegroup has a node to implement some of its functionality
// in this case the nodeGroup acts as a proxy for the node.  The node here 
// is not added to the agentModel node list, so it does not get sent
// meaningless messages

+createBegin: (id) aZone
{
  TerminalGroup * obj;
  
  obj = [super createBegin: aZone]; 
  
  obj->predictionPassedFlag = 0;

  return obj; 	
}
      
-createEnd
{
   return [super createEnd];
}

-setPredictionPassedFlag: (boolean) aBoolean
{

  if (nodeNumber == 149)
    printf("\n Group 149 setting prediction passed flag to : %d", aBoolean);

  predictionPassedFlag = aBoolean;

  // Feb 21 2001 - increment the predictionPassedCount
  // this count was added as if a teacher is being used, the chain
  // may not be correct after the addition of a link, depending on the
  // length of the chain and the length of the corridor.
  // this problem would be avoided during random learning due to
  // the exploratory actions allowing the traversal of a variety of
  // goals to the end state.
  
  // The prediction passed flag allows the chain to be extended 
  // even though the activationCount has not reached its threshold
  // (in fact has not been incremented at all)
  // it is reset once this threshold is reached, and when the
  // chain has been extended (the same conditions for which the 
  // chainActivationCount is reset).

  return self;
}

-(boolean) getPredictionPassedFlag 
{
  return predictionPassedFlag;
}

// Nov 22 2000 - this is to overcome the unfortunate design error
// which means the first node of a terminal group is a dummy node.
// this replaces that node with the real first node

-setFirstNode: (id) aNode
{
  firstNode = aNode;
  return self;
}

-setTopGroup: (id) aGroup
{

  int count = 0;

  // use the following counter to check that a temporal chain
  // has been correct at least once.

  chainCorrectCount = 0;

  // In this case. tell the topGroup it is topGroup (because of when chain
  // is extended in Node.m extendTemporal.
  [(NodeGroup *) aGroup setTopGroup: True];
  // Tell each terminal node about the new top Group
  
  [(TerminalNode *) proxyNode setTopGroup: aGroup];
  count = [nodeList getCount];
  while (count > 0) {
    count--;
    if ([agentModel getDebug])
      printf("\n In node group setTopGroup: Setting top group for node: %ld, to %ld", 
	     [(TerminalNode *) [nodeList atOffset: count] getNodeNumber], 
	     [aGroup getNodeNumber]);
    [(TerminalNode *) [nodeList atOffset: count] setTopGroup: aGroup];
  }
  
  return self;
}

-(int) getChainCorrectCount 
{
  return chainCorrectCount;
}

-incrementChainCorrectCount
{
  chainCorrectCount++;
  return self;
}

// Feb 21 2001 - when the chain is matched and the terminalNode is
// correct, the actions can be determined for the previous groups.
-notifyPreviousGroupsChainCorrect: (boolean) aBoolean {

  [temporalGroup chainCorrect: aBoolean];

  return self;
}

-getTopGroup
{
  return [firstNode getTopGroup];
}

// Sept 28 2000 - remove the top group without removing the chain so another
// group can be tried. If we haven't exceeded our activationcount (detected in
// checkSuspendedInputs.)


-removeTopGroup {

  [(NodeGroup *) [firstNode getTopGroup] removeTemporal];
  // increment chain correct count or shortened chain will  
  // be removed
  [self incrementChainCorrectCount];
  return self;
}

-setTemporalGroup: (id) aGroup
{
  temporalGroup = aGroup;
  return self;
}

-getTemporalGroup
{
  return temporalGroup;
}

-buildObjects
{
    [super buildObjects];
    return self;
}

-setNode: (id) aNode
{
    firstNode = aNode;

    [nodeList addLast: aNode];
    [self createTerminalProxy: aNode];

    [proxyNode setProxyGroup: self];
    [aNode addPredictor: self];
    
    return self;
}     


-payPredictors
{
  // this is different from pay below, which passes node
  // payments to other nodes, this passes rewards to predictor nodes
  
  double paymentEach;
  
  // replaced comment code below with this
  if (!matched || activeSupressed) 
    return self;
  
  if ([agentModel getDebug])
    fprintf(stdout, "\n TerminalGroup: %ld paying predictors, matched: %d, \n activeSupressed %d, Strenght: %f", 
	    nodeNumber, matched, activeSupressed, strength);
  
  paymentEach = strength; 
  [self pay: &paymentEach];
  
  strength = 0;
  
  return self;
}


-pay: (double *) paymentEach
{

  // This receives the payments from a node in the group and redistributes 
  // it across the real predictors of the node.
  // Note: this will be called a number of times as the nodes in the group
  // pass back the pay message.
  
  [[temporalGroup getNodeList] forEach: M(pay:) 
			       : (void *) paymentEach];  
  return self;
}

-addToConnectList
{

  // March 26 2001 - allow terminal groups to have nodes copied but only
  // if firstNode's prediction is matched.

  // June 10 - ok allow terminal nodes to be copied for all 
  // groups regardless of action, but only once chain is complete
  // otherwise we may copy it for groups that never occur on completion
  // of the final chain.

  // June 11 - allow terminal nodes to be copied for other predictions
  // and for those to be able to set the chain to !suspended

  // June 11 2002 - check realActive

 if ([self getRealActive]
     && !lastActiveSupressed
   // June 12 2002 - Added this back in - only copy for
   // one path - June 18 2002 - until final group!!
     && ((![[self getTopGroup] getFinalGroup] 
	  && [firstNode getRealActive] 
	  && [firstNode getCorrect])
	 || [[self getTopGroup] getFinalGroup]))
     { 
       if ([agentModel getDebug])
	 printf("added nodegroup: %ld to predictorlist", nodeNumber);
       [[agentModel getPredictorList] addLast: self];
     }

    return self;
}

// This is a bit messy, first sendTemporalReturn is sent to 
// terminal groups, then it is sent again to all groups,
// but is intended really for only temporal groups
// terminal groups will respond again, but 
// don't need to.
// sendTemporalReturn is implemented slightly differently
// for temporal groups (in NodeGroup).


-sendTemporalReturn
{
  // Send payments to previous nodes in temporal chain.
  // Applies only to Terminal and Temporal Groups 
  // (determined by proxynode type) 
  // Exclude top nodes as they have no previous 
  
  int predictors = 0;
  double paymentEach;
  double groupReturn = 0;  

  // Feb 21 2001 - changed matched to realActive
  // Mar 26 2001 - changed back

  if (!matched) 
    return self;

  if ([agentModel getDebug])
    printf("\n Terminal group %ld about to send temporal return, matched: %d, \n activeSupressed: %d, activeTemporallySupressed: %d", nodeNumber,
	   [self getMatched], activeSupressed, activeTemporallySupressed); 

   // Nov 23 2000 - return the value of higher temporal nodes if their
   // are any and they have a higher value.

  // July 2 2002 - removed following:
  //   groupReturn = [self getGroupDependentReturn];
  //   if (groupReturn > temporalQreturn)
  ///  temporalQreturn = groupReturn;

   predictors = [[self getPreviousNodeList] getCount];
   
   if ([agentModel getDebug])
     printf("\n node group %ld sending temporal return: %f, \n predictors: %d", nodeNumber, temporalQreturn, predictors);
   
   if (predictors > 0) {
     paymentEach = temporalQreturn;
     [self payTemporalPreviousReturn: &paymentEach];
   }

   temporalQreturn = 0;
  
   return self;
}


/* Oct 12 2000 - Here is where we control whether our predicted group
   can create a new temporal chain. 
   
*/

// Ok - while a chain is developing, its prediction should not
// create any new chains if the prediction has just been passed.
// A prediction should never create a new chain once the chain has just fired

// NOTE: The following depends on matchReset which only sets prediction
//  passed flag if it is a homo chain which was reset.

-preventTemporalConnect
{
  int count = 0;
  
  // Oct 12 2000 - if this terminal group has its input matched and
  // the temporal group associated with it has its first input as realActive
  // don't allow our prediction to create any new temporal chains

  // Nov 15 2000 - don't prevent temporal connect once chain 
  // is final.   

  // Mar 20 2002 - changing this so it only prevents new chains
  // if its temporal group is realactive - this takes into account
  // the action and allows other chains along different paths, but with
  // same inputs - to be created.
    
  // May 16 2002 - prevent any new temporal nodes being created
  //               when the group is not final.  Once final
  //               send message to all predictions to prevent
  //  3,4-8  3,4-9  when 3,4-(8,9)                   
                                      
  if ([[self getTopGroup] getRealActive]
    //June 10 2002 - prevent other chains forming if this one
    // matched regardless of terminal action taken.
      && [firstNode getFired]
      && [firstNode getCorrect]) {
    if (![[self getTopGroup] getFinalGroup]) {
      if ([agentModel getDebug])
	printf("\n NONFinal realactive Node Group %ld, setting createTemporalOk to false",
	       nodeNumber); 
      [agentModel setCreateTemporalOk: False];
    }
    else {
      if ([agentModel getDebug])
	printf("\n Final Node Group %ld, setting createTemporalOk to false",
	       nodeNumber); 
      [agentModel setCreateTemporalOk: False];
    }     
  }
    
  // need to change this so as 3,3->8 does not stop 16,3-8 in ring 4x4
  // task. Perhaps if only first node is matched rely on supression
  // of input to prevent repeat chains rather than preventing create. 

  if (![[self getTopGroup] getFinalGroup]
      && (predictionPassedFlag == True))
    {
      if ([agentModel getDebug])
	printf("\n Final Homo Group %ld, setting createTemporalOk to false",
	       nodeNumber); 
      [agentModel setCreateTemporalOk: False];
    }
  
  return self;
}

/* Here is where we allow chains to be added to the front of other chains
   by allowing terminal nodes to be added to the extend list.

   We also allow chains to extend back to other chains.
*/

-addToTemporalConnectList
{

  if ([agentModel getDebug])
    fprintf(stdout,"\n Adding terminal group %ld to temporalConnectList, \nrealActive: %d, activeSupressed: %d, supressed: %d \n topGroupLRA: %d", 
	    nodeNumber, realActive, lastActiveSupressed, 
	    lastActiveTemporallySupressed,
	    [[self getTopGroup] getLastRealActive]);
  
  // Sept 21 2000 - Added check for final group. Only copy terminal
  // nodes once their chain is finalised -changed back

  // Sept 28 - added matched.

  if ([[self getTopGroup] getLastRealActive]
      && !lastActiveSupressed
      && [[self getTopGroup] getFinalGroup])
    // Nov 28 2000 - allow suspended and matched chains to have terminal 
    // nodes copied,
    // - but only if the first node's prediction is matched.
      // June 10 2002 - see addtoconectlist.

      //      && ([firstNode getRealActive] && [firstNode getCorrect]))
    {
      [[agentModel getTemporalPredictorList] addLast: self];
    }

    return self;
}

-createTerminalProxy: (id) aNode
{
  proxyNode = [TerminalNode createBegin: [self getZone]];
  [proxyNode setModel: agentModel];
  [proxyNode setType: [(TerminalNode *) aNode getType]];
  // 0 is AND
  [proxyNode setNodeNumber: nodeNumber];      // this groups number  
  proxyNode = [proxyNode createEnd]; 
  
  [proxyNode buildObjects];
  [proxyNode setProxyGroup: self];
  
  // Add this newly created group to the list of TerminalNodes so
  // it can be copied to predict other nodes.
  [agentModel addTerminalGroup: self];
  
  // NB: the inputs for proxies are now added when the group is created
  // in Node.m
  
  return self;
}


-(boolean) setMatched: (boolean) aBoolean
{
  int count;
  
  if ([agentModel getDebug])
    printf("\n in set matched for Terminal Group: %ld aBoolean: %d count: %d", 
	   nodeNumber, aBoolean, [nodeList getCount]);

  matched = aBoolean;    
  
  count = [nodeList getCount];
  
  while (count > 0)
    {
      count--;
      [[nodeList atOffset: count] setMatched: aBoolean];
    }
  
  return matched;
}

-setSuspended: (boolean) aBoolean
{
   int count = [nodeList getCount];

   if (suspended == aBoolean)
     return self;

   suspended = aBoolean;
   [(PredictorNode *) proxyNode setSuspended: aBoolean];
   while (count > 0)  
   {
      count--;
      [(TerminalNode *)[nodeList atOffset: count] setSuspended: aBoolean];
   }
   return self;
}

-inhibitInputNodes
{
  // Nodes are inhibited when they are inputs to a TerminalGroup
  // which has not established a final node.
  // Once it has, they are temporallySuspended
  if (matched && ![[self getTopGroup] getFinalGroup])
    [[[[[proxyNode getInputList] getFirst] getNode] getGroup] 
      inhibitNodes: True];
    return self;
}

-setInputsSuspended
{
  // This is called by NodeGroup setCorrect: True. The terminal node will
  // now remove any nodes in its input group which make this prediction.
  // This relies on the finalGroup determining its final state
  // at the point that the chain's prediction has just been correctly
  // predicted. To ensure this, the terminalGroup will wait until the
  // finalGroup is established, then once the chain has completed,
  // will use the correctly predicted node to determine the nodes
  // which need to be removed (not really removed, turned off).

  // June 21 - removed to allow faster learning
  //  [[[[[proxyNode getInputList] getFirst] getNode] getGroup] 
  //  setNodesSuspended];
  
  return self;

}

-sendPreviousReturn
{
    // this is different from pay below, which passes node
   // payments to other nodes, this passes rewards to predictor nodes
   int predictors = 0;
   double groupReturn = -9999;
   double paymentEach;

   // Feb 21 2001 - if not realActive don't send a return.

   // June 18 2002 - removed:
   //  if (![self getMatched])
   //  return self;

   if ([agentModel getDebug])
     // if (nodeNumber == 1041)
     printf("\n Terminal group %ld about to send previous return matched: %d, \nactiveSupressed: %d, activeTS %d", nodeNumber, matched, 
	    activeSupressed,
	    activeTemporallySupressed);
   // June 14 2000
   // June 18 2002 - added again:

   if ([self getMatched] && (!activeSupressed) 
       && !activeTemporallySupressed)
     {
       
       // Nov 23 2000 - return the value of higher temporal nodes if there
       // are any and they have a higher value.
       
       //       groupReturn = [self getGroupDependentReturn];
       
       //if (groupReturn > Qreturn)
       //	 Qreturn = groupReturn;
       
       predictors = [[self getPreviousNodeList] getCount];
       if ([agentModel getDebug])
	 printf("\n Terminal group %ld sending previous return: %f, \n predictors: %d", nodeNumber, Qreturn, predictors); 
       
       if (predictors > 0)
	 {
	   paymentEach = Qreturn;
	   
	   // Don't pay returns and rewards at same time - May 15 2000
	   // Must still send returns for temporal threshold though
	   // June 23 - removed following
	   // if ([agentModel getReward] != 0)
	   //  paymentEach = 0; 
	   [self payPreviousReturn: &paymentEach];
	 }   
     }

   return self;
}

// Return the highest actual dependent return for  
// any non-suspended TEMPORAL owners the group has.


-(double) getGroupDependentReturn
{
  double max = -10000;
  double temp = 0;
  int count = 0;

  count = [[proxyNode getActiveOwnerList] getCount];
  
  while (count > 0)
    {
      count--;
      if ([[[proxyNode getActiveOwnerList] atOffset: count]
	respondsTo: M(isTemporal)] 
	&& [(TemporalNode *) [[proxyNode getActiveOwnerList] atOffset: count]
	     getFirstInputMatchedNow])
	temp = [(NodeGroup *)[[[proxyNode getActiveOwnerList] atOffset: count]
		  getGroup] getActualDependentReturn];
      if (temp > max)
	max = temp;
    }
  
  return max;
}

// Nov 20 2000 - used in updateValue estimate - TerminalNodes
// with higher chains need to get returns from second link in these 
// chains as a return. 

-(double) getTemporalOwnerReturn
{
  double max = -10000;
  double temp = 0;
  int count = 0;

  count = [[proxyNode getActiveOwnerList] getCount];
  
  while (count > 0)
    {
      count--;

      if ([[[proxyNode getActiveOwnerList] atOffset: count]
	respondsTo: M(isTemporal)] 
	&& [[[[[proxyNode getActiveOwnerList] atOffset: count]
	       getGroup] getProxyNode] getFirstInputMatchedLast]) {
	temp = [(NodeGroup *) [[[proxyNode getActiveOwnerList] atOffset: count]
		  getGroup] getQreturn];
	if ([agentModel getDebug])
	  printf("\n owner node found temp: %f", temp);
      }
      if (temp > max)
	max = temp;
    }
  
  return max;
}

-isTerminalGroup 
{
  return self;
}

-remove {

  if (!removed)
    {
      removed = True;
      
      [(AgentModelSwarm *) agentModel removeNode: self];
      [agentModel removeTerminalGroup: self];
      [[agentModel getDropList] addLast: self];
      
      // add self to agentModel dropList
      if ([agentModel getDebug]) {
	printf("\n Added group to droplist: %ld", nodeNumber);
      }
    }
  
  return self;
}



-removeSelf: (id) aNode
{

  // this piece of code is for temporal nodes.
  // Once a node in chain of temporal nodes falls
  // below a threshold strength value, the entire chain is 
  // removed, including the other temporal nodes in the chain. 
  
  // The first node's input should be the firstnode of the
  // previous temporal group in the chain. Don't remove 
  // groups, if they are Nary, as this is the end of the chain.
  // In this case just remove the terminal group

  // This will remove all the nodes in the group.
  
  if (removed == True)
    return self;
  removed = True;
  
  [agentModel removeTerminalGroup: self];
  [self removeNode: nil];
  
  if ([agentModel getDebug]) {
    printf("\n finished remove for terminal group: %ld", nodeNumber);
  }
  
  [[agentModel getDropList] addLast: self];
  
  // add self to agentModel dropList
  if ([agentModel getDebug]) {
    printf("\n Added terminal group to droplist: %ld", nodeNumber);
  }  
  
  return self;
}


@end




