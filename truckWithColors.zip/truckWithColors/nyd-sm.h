/* Interface to the New York Driving sensory-motor system.
   Andrew McCallum <mccallum@cs.rochester.edu> 1995
   */

#ifndef __nyd_sm_h
#define __nyd_sm_h 1

#include "nyd.h"


/* Enable/disable various sensory-motor features" */

/* can see if there's a truck behind gaze truck, in the same lane */
#define USING_2TRUCK_VIEW 0

/* can perceive imminent crash in perif. */
#define USING_PERIF_CRASH_DIM 0
/* can perceive difference between "crash in 1" and "crash in 2" time steps */
#define USING_PERIF_CRASH2 0

/* has action for gazing backwards */
#define USING_GAZE_BACKWARD 1

/* can hear horn from tailgating faster truck */
#define USING_HORN 1

/* can see color of truck, (a useless perc dim that should be ignored) */
#define USING_GAZE_COLOR_DIM 1
#define USING_SEPARATE_ROAD_AND_SHOULDER_COLOR 0
#if !USING_SEPARATE_ROAD_AND_SHOULDER_COLOR 
#define NUM_ROAD_COLORS 3
#endif /* USING_SEPARATE_ROAD_AND_SHOULDER_COLOR */


/* the actions */

enum actions
{
 GAZE_FORWARD_LEFT,
 GAZE_FORWARD_CENTER,
 GAZE_FORWARD_RIGHT,
#if USING_GAZE_BACKWARD
 GAZE_BACKWARD,
#endif
 CONTINUE,		/* This now implies shift-where-looking */
 NUMACTIONS
};

#if 0
/* Other possible actions to consider */
 GAZE_BACKWARD_CENTER
 SLOW
 LANE_SHIFT_RIGHT_SLOW
 LANE_SHIFT_LEFT_SLOW
#endif


/* perceptions */
/* CAREFUL: The distance dimensions depend on num_positions. */
/* REMEMBER: The order of these dimensions affects the performance of U-Tree */

enum perception_dimensions
{
#if USING_GAZE_COLOR_DIM
  GAZE_COLOR_DIM,
#endif /* USING_GAZE_COLOR_DIM */
#if USING_2TRUCK_VIEW
  GAZE_2TRUCK_DIM,
#endif /* USING_2TRUCK_VIEW */
  GAZE_DISTANCE2_DIM,
  GAZE_DISTANCE_DIM,
#if USING_GAZE_BACKWARD
  GAZE_SPEED_DIM,
  GAZE_DIRECTION_DIM,
#endif /* USING_GAZE_BACKWARD */
  GAZE_SIDE_DIM,
  GAZE_OBJECT_DIM,
#if USING_HORN
  HEAR_HORN_DIM,
#endif /* USING_HORN */
#if USING_PERIF_CRASH_DIM
  PERIF_CRASH_DIM,
#endif /* USING_PERIF_CRASH_DIM */
  NYD_SM_NUM_PERCEPTION_DIMENSIONS
};

enum gaze_color
{
                               /* defined in HighwayWorld.h */
  GAZE_COLOR_MAX_TRUCK_COLOR = (NYD_NUM_TRUCK_COLORS-1),
#if USING_SEPARATE_ROAD_AND_SHOULDER_COLOR
  GAZE_COLOR_ROAD_AND_SHOULDER,
#endif /* USING_SEPARATE_ROAD_AND_SHOULDER_COLOR */
  SIZEOF_GAZE_COLOR_DIM
};

enum perif_crash
{
 PERIF_CRASH_NO,
 PERIF_CRASH_IMMINENT,
#if USING_PERIF_CRASH2
 PERIF_CRASH_IMMINENT2,
#endif /* USING_PERIF_CRASH2 */
 SIZEOF_PERIF_CRASH_DIM
};

enum gaze_2truck
{
 GAZE_2TRUCK_NO,
 GAZE_2TRUCK_YES,
 SIZEOF_GAZE_2TRUCK_DIM
};

enum gaze_distance2
{
 GAZE_DISTANCE2_FARHALF,
 GAZE_DISTANCE2_CLOSEHALF,
 SIZEOF_GAZE_DISTANCE2_DIM
};

enum gaze_distance
{
 GAZE_DISTANCE_NOSE,
 GAZE_DISTANCE_NEAR,
 GAZE_DISTANCE_FAR,
 SIZEOF_GAZE_DISTANCE_DIM
};

enum gaze_direction
{
 GAZE_DIRECTION_FRONT,
 GAZE_DIRECTION_BACK,
 SIZEOF_GAZE_DIRECTION_DIM
};

enum hear_horn
{
 HEAR_HORN_NO,
 HEAR_HORN_YES,
 SIZEOF_HEAR_HORN_DIM
};

/* This order is significant.  See [HighwayWorldSM -getPerception:forAgent:] */
enum gaze_side
{
 GAZE_SIDE_LEFT,
 GAZE_SIDE_CENTER,
 GAZE_SIDE_RIGHT,
 SIZEOF_GAZE_SIDE_DIM
};

enum gaze_object
{
 GAZE_OBJECT_ROAD,
 GAZE_OBJECT_TRUCK,
 GAZE_OBJECT_SHOULDER,
 SIZEOF_GAZE_OBJECT_DIM
};

/* GAZE_SPEED_DIM */
enum gaze_speed
{
 GAZE_SPEED_LOOMING,
 GAZE_SPEED_RECEDING,
 SIZEOF_GAZE_SPEED_DIM
};


/* Global variables */

extern int nyd_sm_gaze_lane, nyd_sm_gaze_position;
extern int nyd_sm_last_action_illegal;
extern int nyd_sm_last_action_overt;
extern int nyd_sm_collision_count;
extern float nyd_sm_reward_noise_range;

void nyd_sm_init ();
float nyd_sm_reward ();
float nyd_sm_max_reward ();
float nyd_sm_min_reward ();
void nyd_sm_get_percept_vector (int *vector);
void nyd_sm_perform_action (int action);

const int *nyd_sm_perception_dimensions ();
const char *nyd_sm_name_for_action (int action);
const char *nyd_sm_name_for_perception_dimension (int dimIndex);
const char *nyd_sm_name_for_perception (int perception, int dimIndex);

#endif /* __nyd_sm_h */
