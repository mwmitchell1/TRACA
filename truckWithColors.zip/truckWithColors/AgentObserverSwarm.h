// Copyright (C) 1996 Matthew Mitchell.
//
// This is the Observer Level for simulations using the learning agent.
// To models exist within this observer: the agent model and the environment
// model.


#import <objectbase.h>
#import <space.h>
#import <activity.h>
#import <gui.h>
#import <random.h>
#import <analysis.h>
#import <simtoolsgui.h>
#import <simtools.h>
#import <simtoolsgui/GUISwarm.h> 
#import "AgentModelSwarm.h"
#import "EnvironmentSwarm.h"

//  include the environment model
// #import "SimModelSwarm.h"

@interface AgentObserverSwarm : GUISwarm {

  int displayFrequency;				  // one parameter: update freq
  int detectorCount;
  int effectorCount;
  int stopAt;

  boolean randomSeed;
  char * problemFileName;

  id displayActions;				  // schedule data structs
  id displaySchedule;
  id modelActions;
  id modelSchedule;
  boolean classify;
  boolean maze;
  boolean nyd;
  boolean reset;

  EnvironmentSwarm * environmentSwarm;
  AgentModelSwarm * agentModelSwarm;	         // the Swarm we're observing

  // Lots of display objects. First, widgets
  id <Colormap> colormap;				 // allocate colours
  id <ZoomRaster> agentRaster, worldRaster;	 // 2d display widget
  
  id <Graph> triggerGraph, triggerGraphA, triggerGraphB, triggerGraphC;
  id <GraphElement> triggerData, deltaTriggerData, deltaTriggerDataA, 
               deltaTriggerDataB, 
               triggerDataA, gammaTriggerData, gammaTriggerDataA,
               gammaTriggerDataB, gammaTriggerDataC, gammaTriggerDataD,
               gammaTriggerDataE, triggerDataF, gammaTriggerDataH;

  id <ActiveGraph> triggerGrapher, deltaTriggerGrapher, deltaTriggerGrapherA,
              deltaTriggerGrapherB,               
              triggerGrapherA, gammaTriggerGrapher, gammaTriggerGrapherA,
              gammaTriggerGrapherB, gammaTriggerGrapherC,
              gammaTriggerGrapherD, gammaTriggerGrapherE,
              triggerGrapherF, gammaTriggerGrapherH;
	
  // Now, higher order display and data objects
  id <Object2dDisplay> agentDisplay, worldDisplay; // display the agent + world

}

// Methods overriden to make the Swarm.
+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-setProblem: (char *) problemString;
-buildActions;
-activateIn: (id) swarmContext;
-resetAgentPosition;
-setReset: (boolean) aBoolean;
-(boolean) getClassify;
-(boolean) getMaze;
-(boolean) getReset;
-getEnvironment;
-checkToStop;
-timeOut;
-stop;
@end









