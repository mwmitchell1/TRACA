#import "EnvironmentSwarm.h"
#import <objectbase/SwarmObject.h>

@interface Double : SwarmObject
{
  double value;
}

+createBegin: aZone;
-setValue: (double) aDouble;
-createEnd;
-buildObjects;
-(double) getValue;
@end
