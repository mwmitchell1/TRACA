#import "NaryNode.h"
#import "TemporalNode.h"
#import "boolean.h"

@interface TerminalNode : NaryNode
{
   id topGroup;  
}

+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-setTopGroup: (id) aGroup;
-getTopGroup;
-(boolean) checkMatched;
-(boolean) checkSuspended;
-(double) getImprovementFactor;
-(void) checkSuspendedInputs;
-checkRemove;
-removeIfUnfinished;
-removeSelf: (id) aNode;
-match: (boolean) aBoolean by: (Node *) aNode;
-match: (boolean) aBoolean;
-correct;
-incorrect;
-checkSupress; 
-checkNarySupress; 
-checkTemporalSupress; 
-resetTemporallyActivated;
-supress;
-(boolean) compareInputs;
-temporalSupress;
-supressInput;
-narySupressInputs;
-temporalSupressInput;
-checkMatchSupress;
-checkUpdateTemporalSupress;
-updateTemporalSupress;
-updateTemporalSupressInput;
-checkActiveSupress;
-checkActiveActionSupress;
-checkActiveTemporalSupress;
-(id) ownerListsContainTemporalGroup;
-activeSupress;
-activeTemporalSupress;
-activeSupressInput;
-activeActionSupressInput;
-activeTemporalSupressInput;
-(boolean) getTemporallyActivated;
-sendPreviousReturn;
-sendTemporalReturn;
-copyNew: (id) aZone;
-createGroup;
-copy: (id) aZone;
-(boolean) setMatched: (boolean) aBoolean;
-(boolean) setMatched: (boolean) aBoolean by: (Node *) aNode;
-setCorrectCount: (int) anInt;
-isTerminal;
-findSimilarInputNode;
-printOn;
@end
