// Copyright (C) 1996 Matthew Mitchell.
//
// This is the Observer Level for simulations using the learning agent.
// To models exist within this observer: the agent model and the environment
// model.

#import <objectbase.h>
#import <space.h>
#import <activity.h>
#import <gui.h>
#import <random.h>
#import <analysis.h>
#import <simtoolsgui.h>
#import <simtools.h>
#import <simtoolsgui/GUISwarm.h> 

#import <objectbase.h>

#import "AgentModelSwarm.h"
#import "EnvironmentSwarm.h"

@interface AgentBatchSwarm : Swarm {


  char * problemFileName;
  int detectorCount;
  int effectorCount;
  boolean timeSeedRandom;
  boolean reset;
  boolean classify;
  boolean maze;
  int seed;
  int run;

  id modelActions;
  id modelSchedule;

  id runCount;
  int epochCount;

  EnvironmentSwarm * environmentSwarm;
  AgentModelSwarm * agentModelSwarm;	         // the Swarm we're observing

}

// Methods overriden to make the Swarm.
+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-setProblem: (char *) problemString epochs: (char *) epochString run: (char *) runString seed: (char *) seedString;
-buildActions;
-activateIn: (id) swarmContext;
-resetAgentPosition;
-setReset: (boolean) aBoolean;
-(boolean) getClassify;
-(boolean) getMaze;
-(boolean) getReset;
-stop;
-timeOut;
-go;
@end









