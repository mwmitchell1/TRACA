#import "Sorter.h"
#import "Node.h"


@implementation Sorter

+createBegin: (id) aZone
{
	return [super createBegin: aZone];
}

-createEnd
{
	return self;
}

-sort: (id) returnList
{
   // takes an inputlist and sorts it
 
   int counter=0, span=0, target=0, right=0, left = 0 ;
   id hold;
   boolean passDone=False;
   int size=0;

//   id returnList = [inputList copy: [self getZone];   

   size = [returnList getCount];

   span = size / 2;
   while (span > 0)
   {
      counter = 1;
      target = size - span;
      while (counter <= target)
      {    
         left = counter - 1;
         passDone = False;
         while (passDone == False)
         {
            right = left + span;
            if ([[returnList atOffset: left] getSortStrength] <
              [[returnList atOffset: right] getSortStrength])
               passDone = True;
            else
            {
               hold = [returnList atOffset: right];
               [returnList atOffset: right put: [returnList atOffset: left]];
               [returnList atOffset: left put: hold];
               if (left > span)
                  left = left - span;
               else
                  passDone = True;   
            }
         }
         counter++;
      }    
      span = span / 2;
    }
  
    return self;
}

-reverseSort: (id) returnList
{
      id tempList;
      int count;
 
      tempList = [returnList copy: [self getZone]]; 
      [self sort: tempList];
            
      [returnList removeAll];

      count = [tempList getCount];
      while (count > 0)
      {
         count--;
         [returnList addLast: [tempList getLast]];
         [tempList removeLast];
      }

  return self;      
}
      


@end






