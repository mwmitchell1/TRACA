#import "EnvironmentSwarm.h"
#import <objectbase/SwarmObject.h>
#import "boolean.h"
#import "stdio.h"
#import <gui.h>
#import <collections.h>
#include <strings.h>

// This would be far more efficient in a Java type interface 
// The fields could be set as static finals.
// The calculated fields could be initialised when the class
// was loaded. Would need a helper class to read from file though
// if wanted to not have hardcoded values.
// i.e:  interface NYDConstants {
//              String numberLanes = 
//                  LoadConstants.getNextString(NYDConstants.numberLanes);
//       }
// The existing class could also have some functionality
//  replaced by a Properties file

@interface NYDConstants : SwarmObject
{

  // From nyd.c and nyd.h (Actually, these aren't used, the version in nyd.c are.
   int maxTruckSpeed;
   int minTruckSpeed;
   float fastTruckProbability;
   float newTruckProbability;
   float doubleTruckProbability;

   //
   int numberTruckColors;
   int numberLanes;
   int numberPositionsInLane;
   
   boolean usingTwoTruckView;
   boolean usingPerifCrashDimension;
   int perifCrashDistance; // can be 1 or 2
   boolean usingGazeBackwards;
   boolean canHearHorn;
   boolean canSeeColor;
   boolean canSeeShoulder;
   // The following fields should not be defined, but provided  by methods.
   int numberRoadColors;  // This will be zero if canSeeShoulder
                          // is 0 or 3 otherwise
   int numberOfActions; // this will be five if usingGazeBackwards > 0 
                        // and 4 otherwise. 

   // I am not sure how the move_left and move_right actions fit in 
   // with these. I think you move towards the gaze_position?
   int gazeForwardLeft;
   int gazeForwardCenter;
   int gazeForwardRight;
   int gazeBackwards;
   int continueOn;  // CONTINUE

   // Perceptual dimensions From nyd-sm.h
   // These are all calculated and gaze except for horn and crash perception  
   int colorDimension;
   int twoTruckDimension;
   int distanceTwoDimension;
   int distanceDimension;
   int speedDimension;
   int directionDimension;
   int sideDimension;
   int objectDimension;
   int hearHornDimension;
   int perifCrashDimension;

   int numberPerceptualDimensions;
   
   // Gaze color 
   int maxTruckColor; // numberTruckColors - 1
   int roadAndShoulderColor;
   int numberOfColorDimensions;

   // Perif crash

   int perifNoCrashImminent;
   int perifCrashImminent;
   int perifCrashImminentInTwo;  // if using perifCrashDistance == 2
   int numberOfPerifCrashDimensions;

   // Gaze 2 truck

   int gazeToTruckNo;
   int gazeToTruckYes;
   int numberOfGazeToTruckDimensions;

   // Gaze distance to

   int gazeDistanceToFarHalf;
   int gazeDistanceToCloseHalf;
   int numberOfGazeDistanceToDimensions;

   // Gaze distance 

   int gazeDistanceNose;
   int gazeDistanceNear;
   int gazeDistanceFar;
   int numberOfGazeDistanceDimensions;

   // Gaze Direction

   int gazeDirectionFront;
   int gazeDirectionBack;
   int numberOfGazeDirectionDimensions;

   // Hear horn

   int hearHornYes;
   int hearHornNo;
   int numberOfHearHornDimensions;

   // Gaze size - order of these significant

   int gazeLeftSide;
   int gazeCenter;
   int gazeRightSide;
   int numberOfGazeSideDimensions;

   // Gaze Object

   int gazeAtRoad;
   int gazeAtTruck;
   int gazeAtShoulder;
   int numberOfGazeAtDimensions;

   // Gaze Speed Dimensions
   
   int gazeSpeedLooming;
   int gazeSpeedReceeding;
   int numberOfGazeSpeedDimensions;
   
   // from nyd-sc.h
   float crashReward;
   float hornReward;
   float noCrashReward;

   float tempFloat;  // used for parameter passing
  
}

+createBegin: aZone;
-createEnd;
-buildObjects;
-loadConstantsFromFile: (char *) aFile;
-init: (char *) method with: (char *) value;
-updateCalculatedValues;
-(float) getCrashReward;
-(float) getHornReward;
-(float) getNoCrashReward;
-(int) getMaxTruckSpeed;
-(int) getMinTruckSpeed;
-(float) getFastTruckProbability;
-(float) getNewTruckProbability;
-(float) getDoubleTruckProbability;
-(int) getNumberTruckColors;
-(int) getNumberLanes;
-(int) getNumberPositionsInLane;
-(boolean) getUsingTwoTruckView;
-(boolean) getUsingPerifCrashDimension;
-(int) getPerifCrashDistance;
-(boolean) getUsingGazeBackwards;
-(boolean) getCanHearHorn;
-(boolean) getCanSeeColor;
-(boolean) getCanSeeShoulder;
-(int) getNumberRoadColors;
-(int) getNumberOfActions;

-(int) getGazeForwardLeft;
-(int) getGazeForwardCenter;
-(int) getGazeForwardRight;
-(int) getGazeBackwards;
-(int) getContinueOn;  // CONTINUE

-(int) getColorDimension;
-(int) getTwoTruckDimension;
-(int) getDistanceTwoDimension;
-(int) getDistanceDimension;
-(int) getSpeedDimension;
-(int) getDirectionDimension;
-(int) getSideDimension;
-(int) getObjectDimension;
-(int) getHearHornDimension;
-(int) getPerifCrashDimension;
-(int) getNumberPerceptualDimensions;
-(int) getMaxTruckColor;
-(int) getRoadAndShoulderColor;
-(int) getNumberOfColorDimensions;
-(int) getPerifNoCrashImminent;
-(int) getPerifCrashImminent;
-(int) getPerifCrashImminentInTwo;
-(int) getNumberOfPerifCrashDimensions;
-(int) getGazeToTruckNo;
-(int) getGazeToTruckYes;
-(int) getNumberOfGazeToTruckDimensions;
-(int) getGazeDistanceToFarHalf;
-(int) getGazeDistanceToCloseHalf;
-(int) getNumberOfGazeDistanceToDimensions;
-(int) getGazeDistanceNose;
-(int) getGazeDistanceNear;
-(int) getGazeDistanceFar;
-(int) getNumberOfGazeDistanceDimensions;
-(int) getGazeDirectionFront;
-(int) getGazeDirectionBack;
-(int) getNumberOfGazeDirectionDimensions;
-(int) getHearHornYes;
-(int) getHearHornNo;
-(int) getNumberOfHearHornDimensions;
-(int) getGazeLeftSide;
-(int) getGazeCenter;
-(int) getGazeRightSide;
-(int) getNumberOfGazeSideDimensions;
-(int) getGazeAtRoad;
-(int) getGazeAtTruck;
-(int) getGazeAtShoulder;
-(int) getNumberOfGazeAtDimensions;
-(int) getGazeSpeedLooming;
-(int) getGazeSpeedReceeding;
-(int) getNumberOfGazeSpeedDimensions;
-setCrashReward: (float) aFloat;
-setHornReward: (float) aFloat;
-setNoCrashReward: (float) aFloat;
-setCrashRewardObj: (id) object;
-setHornRewardObj: (id) object;
-setNoCrashRewardObj: (id) object;
-setMaxTruckSpeed: (int) anInt;
-setMinTruckSpeed: (int) anInt;
-setFastTruckProbability: (float) aFloat;
-setNewTruckProbability: (float) aFloat;
-setDoubleTruckProbability: (float) aFloat;
-setNumberTruckColors: (id) anInt;
-setNumberLanes: (int) anInt;
-setNumberPositionsInLane: (int) anInt;
-setUsingTwoTruckView: (boolean) aBoolean;
-setUsingPerifCrashDimension: (boolean) aBoolean;
-setUsingGazeBackwards: (boolean) aBoolean;
-setPerifCrashDistance: (int) anInt;
-setCanHearHorn: (boolean) aBoolean; 
-setCanSeeColor: (boolean) aBoolean;
-setCanSeeShoulder: (boolean) aBoolean; 
-setNumberRoadColors: (int) anInt;
-setNumberOfActions: (int) anInt;
-setGazeForwardLeft: (int) anInt;
-setGazeForwardCenter: (int) anInt;
-setGazeForwardRight: (int) anInt;
-setGazeBackwards: (int) anInt;
-setContinueOn: (int) anInt;
-setColorDimension: (int) anInt;
-setTwoTruckDimension: (int) anInt;
-setDistanceTwoDimension: (int) anInt;
-setDistanceDimension: (int) anInt;
-setSpeedDimension: (int) anInt;
-setDirectionDimension: (int) anInt;
-setSideDimension: (int) anInt;
-setObjectDimension: (int) anInt;
-setHearHornDimension: (int) anInt;
-setPerifCrashDimension: (int) anInt;
-setNumberPerceptualDimensions: (int) anInt;
-setMaxTruckColor: (int) anInt;
-setRoadAndShoulderColor: (int) anInt;
-setNumberOfColorDimensions: (int) anInt;
-setPerifNoCrashImminent: (int) anInt;
-setPerifCrashImminent: (int) anInt;
-setPerifCrashImminentInTwo: (int) anInt;
-setNumberOfPerifCrashDimensions: (int) anInt;
-setGazeToTruckNo: (int) anInt;
-setGazeToTruckYes: (int) anInt;
-setNumberOfGazeToTruckDimensions: (int) anInt;
-setGazeDistanceToFarHalf: (int) anInt;
-setGazeDistanceToCloseHalf: (int) anInt;
-setNumberOfGazeDistanceToDimensions: (int) anInt;
-setGazeDistanceNose: (int) anInt;
-setGazeDistanceNear: (int) anInt;
-setGazeDistanceFar: (int) anInt;
-setNumberOfGazeDistanceDimensions: (int) anInt;
-setGazeDirectionFront: (int) anInt;
-setGazeDirectionBack: (int) anInt;
-setNumberOfGazeDirectionDimensions: (int) anInt;
-setHearHornYes: (int) anInt;
-setHearHornNo: (int) anInt;
-setNumberOfHearHornDimensions: (int) anInt;
-setGazeLeftSide: (int) anInt;
-setGazeCenter: (int) anInt;
-setGazeRightSide: (int) anInt;
-setNumberOfGazeSideDimensions: (int) anInt;
-setGazeAtRoad: (int) anInt;
-setGazeAtTruck: (int) anInt;
-setGazeAtShoulder: (int) anInt;
-setNumberOfGazeAtDimensions: (int) anInt;
-setGazeSpeedLooming: (int) anInt;
-setGazeSpeedReceeding: (int) anInt;
-setNumberOfGazeSpeedDimensions: (int) anInt;
-(float) getTempFloat;
@end





