#import <collections.h>
#import "Node.h"
#import "Effector.h"
#import "boolean.h"
#import "PredictionType.h"

extern float PSTRENGTH;
extern float PHISTORY;

@interface PredictorNode : Node
{

  //  note: predictive update rate defined temporarily in boolean.h
  //  ************************************************************

  // average strength is the strength before the most recent payment
  // for bidding, it is used for printOn only as it gives a better
  // idea of the strength of nodes.

        double averageStrength;

	double maxQreturn;
        double maxReward;

	boolean higherValue;

	id prediction;
	id trend;
	id trendForThis;

// Used to store the type of prediction the node will make in fire

        int predictionType;

        int hypPredictionType;
        boolean hypFired;
	boolean receivedReward;

// Predictive strength is used in bidding, it starts off high to allow nodes
// to get tested, however, predicitive history is used to determine how the
// node has been going so far, it starts at 0.  Passive nodes keep testing
// this until they find their predictive strength is greater than one of their
// inputs, in this case they can start to create owners of their own.
// a Node which has a passive owner will not accept any more owners until it is// active.  If the predicitive strength falls below the predicitive strength
// of the owned node it is removed and deleted.

        double dependentAccuracy;
        double independentAccuracy;
        double timeComparison;
        double temporalTimeComparison;
        boolean fired;
        boolean sentSupport;
        boolean lastSentSupport;
        double lastPayment;
        boolean steadyState;
 
// passive is used to distinguish nodes which fire but 
// make passive predictions. Defined in Node, but only used for NaryNodes

        boolean correct;
        boolean lastCorrect;
        boolean incorrectOnce;

	// To disable nodes below terminal node
	boolean temporallySuspended;
	boolean inhibited;
	boolean lastInhibited;
        
// Only for Unary nodes;
        int family;

        double independentValue;
        double dependentValue;

        long activationCount;
        long ownActivationCount;
        long lifetimeCount;
        long predictionActiveCount;
        long correctCount;
        long ownCorrectCount;
        long firedCount;
        int thresholdCount;    
        int latestActivationCount;
        int latestCorrectCount;
        int totalActivationCount;
        int totalCorrectCount;
        double reward;

	Effector * supported;
}
+createBegin: (id) aZone;
-createEnd;
-buildObjects;
-(boolean) setPrediction: (id) aNode;
-getPrediction;
-preFire;
-checkUpdateTemporalSupress;
-addToExtendList: (id) extendList;
-fire;
-pay: (double *)  paymentPtr;
-payReturn: (double *)  paymentPtr;
-updateValueEstimate;
-(double) getAlpha;
-(double) getAbs: (double) aDouble;
- (boolean) getPerformingAtBest;
-(boolean) setSupported: (id) aSupported;
-(boolean) removeSupported;
-(id) getSupported;
-(boolean) removePredictor:  (id) aNode;
-sendActivePredictiveSupport;
-setSuspended: (boolean) aBoolean;
-createGroup;
-addGroup: (id) aGroup;
-moveSuspendedOwner: (id) anOwner;
-(boolean) getSuspended;
-(boolean) getTemporallySuspended;
-setTemporallySuspended: (boolean) aBoolean;
-(int) getPredictionType;
-setPredictionType: (int) aType;
-(int) getFamily;
-setLastCorrect;
-realDeactivate;
-(boolean) getGroupCorrect;
-active;
-correct;
-incorrect;
-(boolean) compareInputs;
-(boolean) getLastCorrect;
-(boolean) containsTerminalNode;
- (boolean) getInhibited;
-setInhibited: (boolean) aBoolean;
-(boolean) getFired;
-(double) getDependentAccuracy;
-(double) getMaxDependent;
-(double) getMaxIndependent;
-(double) getActualMaxIndependent;
-(double) getMaxIndependentAccuracy;
-(boolean) setFired: (boolean) aBoolean;
-setCorrect: (boolean) aBoolean;
-(boolean) getCorrect;
-(boolean) getGroupCorrect;
-(boolean) getSteadyState;
-(boolean) getIncorrectOnce;
-isPredictor;
-getInput: (id) owner;
-probeSelf: (int) number;
-setCopy;
-sendFrequency;
-incrementLifetimeCount;
-copyValues: (id) aNode; 
-setDependentAccuracy: (double) aDouble;
-setIndependentAccuracy: (double) aDouble;
-setRewardStrength: (double) aDouble;
-(double) getRewardStrength;
-(double) getQreturn; 
-(double) getAbsIndependentValue;
-(double) getAbsDependentValue;
-(double) getIndependentAccuracy;
-(long) getOwnCorrectCount; 
-setOwnCorrectCount: (long) aLong;
-(long) getCorrectCount;
-setCorrectCount: (long) aLong; 
-(long) getActivationCount;
-setActivationCount: (long) aLong;  
-(long) getOwnActivationCount; 
-setOwnActivationCount: (long) aLong; 
-setDependentValue: (double) aDouble;
-(double) getDependentValue;
-(double) getIndependentValue;
-(double) getDependentSpecificity;
-(double) getIndependentSpecificity;
-setIndependentValue: (double) aDouble;
-setSteadyState: (boolean) aBoolean;
-(void) die;
-setSentSupport: (boolean) aBoolean;
-drawSelfOn: (id <Raster>) aRaster;
-printPredictors;
-printOn;
-checkHypSupress;
-checkHypActiveSupress; 
-hypPayReturn: (double *)  paymentPtr;
-hypPreFire;
-hypFire;
-hypPay: (double *)  paymentPtr;
-(boolean) getHypFired;
-(boolean) setHypFired: (boolean) aBoolean;
-(boolean) hypDeactivate;
-(boolean) hypActivate;
-hypUpdateValueEstimate;
-lookahead;
@end

















