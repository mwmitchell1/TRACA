#define False 0
#define True 1
typedef int boolean;

#define MAZE
//#define NYD - do one or the other
