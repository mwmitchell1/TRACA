#import "Node.h"
#import "PredictorNode.h"
#import "AgentModelSwarm.h"
#import "Input.h"
#import "NodeGroup.h"
#import "TerminalNode.h"
#import "TerminalGroup.h"
#import <collections.h>
#import "Trend.h"

@implementation TerminalNode

/*  Note: the family must be set to some integer > 0, and the node number in the 
    createBegin stage 

    Also X and Y coordinates need to be set, this is not checked for in createEnd.
*/

+createBegin: (id) aZone
{
  TerminalNode * obj;
  
  obj = [super createBegin: aZone]; 	
  return obj;
}

-createEnd
{	
  return [super createEnd];
}

-buildObjects
{
  [super buildObjects];
  topGroup = nil;


  
  return self;
}

-setTopGroup: (id) aGroup
{
  // This records the group currently at the top of the chain
  // for this terminal node. Once the terminal node has
  // high enough strength it will set this group as the end of the chain.

  topGroup = aGroup;

  // Oct 16 2000 - now when a top group is added - reset accuracy
  // and value estimates. Other wise they will be biased by the
  // previous chain length.

  // Nov 14 2000 - removed
  // unless value estiamtes are also updates this leads to comparisons
  // being based on values that are too low.
  // eg value = 89.0 (actual 100.0 - but has not yet converged) and
  //     accuracy = 1.0 = 89 as comparison to 100 with compared.
  //  independentAccuracy = 1.0;
  // dependentAccuracy = 1.0;
  //timeComparison = 0.0;
  //  dependentValue = 0;
  //independentValue = 0;

  return self;
}

-getTopGroup 
{
   return topGroup;
}

-(boolean) checkMatched
{
  if ([agentModel getDebug])
    printf("\n Terminal node: %ld Matched: %d", nodeNumber, 
	   [topGroup getMatched]);
  
  if ([topGroup getMatched])
    return True;
  else
    return False;
}

-(boolean) checkSuspended
{

// Because of NaryNode realdeactivate, this is only executed for 
// a non-copy terminal node.

  id inputProxy = nil;

  if (nodeGroup == nil)
     return False;

  if ([agentModel getDebug]) {
    printf("\n In terminal node check suspended: %ld, \n this strength: %f, prediction avg strength: %f,\n inputsGreater: %d, isImproved: %d, realActive: %d, lastRealActive : %d previousRealActive: %d lpbnfc: %d, pbnfc: %d, cc: %d",
	   nodeNumber, ([self getIndependentValue] 
			* (1 + [agentModel getTemporalImprovementFactor])),
	   ([prediction getAverageReturn] + [prediction getAverageReward]),
	   [self compareInputs], isImproved, realActive, lastRealActive,
	   previousRealActive, 
	   [prediction getLastPredictedByNonFinalisedChain],
	   [prediction getPredictedByNonFinalisedChain],
	   [[self getGroup] getChainCorrectCount]);
    //  [[(NaryNode *) self getFirstSimilarInput] getDependentAccuracy]); 

    printf("\n first node: %ld input last: %d, previous:%d", 
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getFirst] getNode] getNodeNumber],
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getFirst] getNode] getLastRealActive],
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getFirst] getNode] getPreviousRealActive]);

    printf("\nlast node: %ld input last: %d, previous:%d",
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getLast] getNode] getNodeNumber],
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getLast] getNode] getLastRealActive],
	   [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getLast] getNode] getPreviousRealActive]);
    [trend printOn];
  }

  // Nov 20 any node can set to final - others just add to improvement
  // count  

    // Jan 19 2001 - distinguish between corridor (cyclic) and
    // non-corridor tasks.  Base distinction on whether first 
    // input was active in last 2 time steps. If a corridor task,
    // must reach the value of the prediction, otherwise, must
    // just improve on input node. 

	// Feb 2 2001 - changed following condition, need to 
	// check if both inputs have been active for both timesteps
	// to determine a corridor task. 
	
  if ([agentModel getDebug])
    printf("\nprimary node: %ld higherValue: %d, lastRealActive: %d trend: %d isUp: %d improved: %d value: %f", 
	   [[[self getGroup] getFirstNode] getNodeNumber],
	   higherValue,
	   lastRealActive, [trend trendExists], [trend isTrendUp],
  (([self getIndependentValue] 
    * (1.0 + [agentModel getTemporalImprovementFactor])) >= 1.0),
	   ([self getIndependentValue]
	    * (1.0 + [agentModel getTemporalImprovementFactor])));

  if (higherValue
      // Jan 31 2001 - added following line so not done when lastRealActive
      && lastRealActive)
	{
	  if ([[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		  getLast] getNode] getLastRealActive]
	      && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		     getFirst] getNode] getPreviousRealActive]
	      && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		     getLast] getNode] getPreviousRealActive]
	      && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		     getFirst] getNode] getLastRealActive])
	    {
	      // July 15 2002 - firstNode here should really be called
	      // primary node
	      if ([[self getGroup] getFirstNode] == self) {
		if ((([self getIndependentValue]
		      * (1 + [agentModel getTemporalImprovementFactor]))
		     >= 1.0) 
		    && (([(NaryNode *) self getFirstSimilarInput] == nil)
			|| ([self getIndependentValue] >=
			    [[(NaryNode *) self getFirstSimilarInput]
			      getDependentAccuracy]))
		    && !isImproved)
		  {
		    // If fact, there will only be one improved terminal node
		    // unless we move this outside the suspended check.
		    if ([agentModel getDebug]) {
		      printf("\n Corridor task identified");
		      printf("\n realactive: %d, lastCorrect: %d, node: %ld TTC: %f",
			     realActive, lastCorrect, nodeNumber, temporalTimeComparison);
		    }
		    [nodeGroup incrementImprovedNodeCount];
		    isImproved = True;
		  }
	      }
	      else {
		if ((([self getIndependentValue] 
		      * (1 + [agentModel getTemporalImprovementFactor]))
		     < 1.0) 
		    && (([self getFirstSimilarInput] == nil)
			||  ([self getIndependentValue] <
			     [[(NaryNode *) self getFirstSimilarInput]
			       getDependentAccuracy])) 
		    && isImproved) {
		  isImproved = False;

		  if ([agentModel getDebug]) {
		    printf("\n Corridor decrement");
		    printf("\n lastrealactive: %d, lastCorrect: %d, node: %ld TTC: %f",
			   lastRealActive, lastCorrect, nodeNumber, temporalTimeComparison);
		  }
		  [nodeGroup decrementImprovedNodeCount];
		}
	      }
	    }
	  else 
	    {	      
	      if (isImproved
		  && ((![trend trendExists] 
		       || ([trend trendExists] && ![trend isTrendUp]))))
		{
		  isImproved = False;
		  if ([agentModel getDebug]) {
		    printf("\n NONCorridor decrement");
		    printf("\n lastrealactive: %d, lastCorrect: %d, node: %ld TTC: %f",
			   lastRealActive, lastCorrect, nodeNumber, temporalTimeComparison);
		  }
		  [nodeGroup decrementImprovedNodeCount];
		}
	      else {
		if (!isImproved
		    && (([trend trendExists] && [trend isTrendUp])))
		  {
		    if ([agentModel getDebug]) {
		    printf("\n NONCorridor increment");
		    printf("\n lastrealactive: %d, lastCorrect: %d, node: %ld TTC: %f",
			   lastRealActive, lastCorrect, nodeNumber, temporalTimeComparison);
		  }
		    [nodeGroup incrementImprovedNodeCount];
		    isImproved = True;
		  }
	      }
	    }
	}
    

  // Feb 11 2000 - moved the following, used to check if suspended
  // once node activation threhold reached, now sets suspended
  // when improves on inputs

    // This stuff here is critical to the temporal chains working

  if (!steadyState && suspended
      // Jan 31 2001 - do this once lastRealActive so we can
      // see whether the prediction was predicted by an already completed
      // chain.
      && lastRealActive

      // Dec 20 2000 - suspended doesn't really mean much for terminal node
      // now that the temporalActivationCount is only updated once the
      // prediction is matched.
      // unless you want to wait until all nodes in terminal group have
      // reached activationCount which is a bit tricky
      //  OLD (PRE MAR 2002) :-

      && isImproved)
    {
      // Jan 31 2001 - if the prediction is already predicted
      // by a final group, do not set as final but discard
      // the topGroup and try again, this allows multiple chains 
      // along similar paths, but without duplicates.
  
      if ([prediction getLastPredictedByFinalisedChain]) {
	// Remove chain

	[(NodeGroup *) topGroup removeSelf: nil];
	/* June 18 2002 - removed following - just remove group!
	if ([agentModel getDebug])
	  printf("\n Node %ld removing top group because prediction already
                     predicted by final group", nodeNumber);
	[[self getGroup] removeTopGroup];
	if (removed) { // if first link in chain, it will not be removed
	  // Need to set second input matched now and waitingOnSecond
	  // Nov 20 2000
	  inputProxy = [[[[[[self getGroup] getProxyNode]
			    getInputList] getLast] getNode] getGroup];
	  if ([[inputProxy getProxyNode] respondsTo: M(isTemporal)])
	    [inputProxy ownerRemoved];
	}	
	*/
      }
      else {
      	if ([agentModel getDebug])
             printf("\n Terminal node: %ld, group: %ld, lastPBFC: %d, PBFC: %d time: %ld",
	     nodeNumber, [nodeGroup getNodeNumber],
	     [prediction getLastPredictedByFinalisedChain],
	     [prediction getPredictedByFinalisedChain],
	     getCurrentTime());

	if ([agentModel getDebug])
	  printf("\n Terminal node reached steadyState node: %ld,\n top: %ld\n finalGroup %d, this value: %f, prediction value: %f",
		 nodeNumber, 
		 [topGroup getNodeNumber],
		 [topGroup getFinalGroup],
		 [self getIndependentValue],
		 [prediction getAverageReinforcement]);
	
	[self setSuspended: False]; 
	[self setSteadyState: True];
	// We only do the following once when the first node reaches
	// steadyState
	if (![(NodeGroup *) topGroup getFinalGroup]) {
	  [(NodeGroup *) topGroup setFinalGroup: True];
	  [(NodeGroup *) topGroup setSuspended: False];
	}	    
      }
    }

  return True;
}

// The following is used to determine if a temporalGroup has
// improved sufficiently on an input to decide that it has uncovered hidden
// state.  If it is decided incorrectly that this is true, we have
// a problem as it will never uncover it properly.
// If it is decided incorrectly that it has not ncovered hidden-state,
// the chain will be extended further than it should.

// 23 Nov 2000 
// This may not work as you suspect: here is the run down:

// When getting the value of the input node we include the 
// specificity, that means the value of the input node is in fact
// the value of the return (not the average return) received from
// it s prediction. In fact we could get this from the prediction
// itself.  The use of the improvement factor is a tolerance on how
// close we must get to that value for this terminal node without
// including the specificity in the calculation.


// Jan 20 2001 - return a number that will decrease the relative value
// of this node, so it must provide an improvement on the input.
-(double) getImprovementFactor 
{
 return 1.0 - [agentModel getImprovementFactor];
}


// returns true if inputs have higher value
/* Use Nary node type version -  Oct 6 2000
   changed back to use this Nov 13 2000 - only compare with same node
 */

// Nov 14 2000 - compare actual value to (value * specificity of input)
// if close (within tolerance) then set top group final.

// Nov 23 2000 - the specificity of a terminal group will drop if
// random actions are being taken so that the chain does not complete.
// However, we should be updating the strength of the chain based on 
// the strength of temporal nodes which extend the chain when we are
// wrong.  This will work better with lower learning rates and 
// randomEffectorRates, as otherwise,
// the independent Accuracy will fall too low before we have had a chance
// to extend the chain forward.

-(boolean) compareInputs 
{
  // double difference = 0;

  if ([self findSimilarInputNode] == nil)
    return True;

  if ([agentModel getDebug])
    printf("\n compare inputs for node: %ld, this: %f, input: %f: compare: %d",
	   nodeNumber,
	   [self getIndependentValue],
	   ([[self findSimilarInputNode] getIndependentValue] * [self getImprovementFactor]),  ([self getIndependentValue] <=
	   ([[self findSimilarInputNode] getIndependentValue] * [self getImprovementFactor]))); 

  if (!suspended) {
    // Jan 23 2001 - don't use improvementFactor here, as for
    // non cyclic tasks the inputs value and this nodes value
    // will converge to the same once !suspended. 

    if (([self getIndependentValue]
	<  [[self findSimilarInputNode] getIndependentValue])
	|| ([self getIndependentValue] < (0.0 + [agentModel getVariance]))) 
      return True;
  }
  else {
    // Jan 23 2001 increase the input if 
    // !suspended as this is used primarily for
    // non cyclic situations where the values will be close.
    if (([self getIndependentValue] * [self getImprovementFactor])
	<= [[self findSimilarInputNode] getIndependentValue]) {    
      return True;
    }
  }

  return False;
}


-(void) checkSuspendedInputs
{

   // Feb 2, don't let proxy nodes determine when to remove groups

   if (nodeGroup == nil)
     return;

   // Only terminal nodes that were correct should compare with inputs
   // note that for terminal nodes all nodes are eligible to compare inputs
   // not just the first node as for nary nodes/

   // Feb 11 2000 (all nodes can compare if they have same prediction as 
   //          first node).

   if (([self getSuspended] == False) && (inputsMoved == False))
     {
       inputsMoved = True;
       [[[inputList getFirst] getNode] moveSuspendedOwner: self];
     }         

   // The following condition is unlikely in the test experiments,
   // but could ccur if the input appears in situations where
  // the chain does not need to be followed or can be deviated from.
   // Feb 11 2000 - added this note. 

  /* April 4 2002 - removed following:

 
   if (!removed 
       // Mar 28 2001 - added realActive below
       && realActive) {
     // Nov 30 2000 - keep a count of the number of nodes
     // which have improved on their inputs.
     // Once this count drops to zero (and final) remove self.
     if (isImproved)
       {

       if ([[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
	       getLast] getNode] getRealActive]
	   && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		  getFirst] getNode] getLastRealActive]
	   && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		  getLast] getNode] getLastRealActive]
	   && [[[[[[nodeGroup getTemporalGroup] getProxyNode] getInputList] 
		   getFirst] getNode] getRealActive])
	 { 
	   // If a corridor task, must not only improve on inputs,
	   // but must reach value of prediction (as just extending
	   // increases strength by reducing frequency of incorrect predictions
	   if ((![trend trendExists] 
		|| ([trend trendExists] && ![trend isTrendUp]))
	       || (([self getIndependentValue] 
		    * (1 + [agentModel getTemporalImprovementFactor])) < 1.0))	       
	     {
      	       if ([agentModel getDebug]) {
		 if ([self findSimilarInputNode])
		   printf("\n Inputs realactive Terminal node %ld decrementing improved count 
                          compareInputs: %d, 
                          timeComparison: %f,
                          this value: %f,
                          other value: %f, TTC: %f", 
			  nodeNumber,
			  [self compareInputs],
			  timeComparison,
			  ([self getAbsIndependentValue] 
			   * (1 + [agentModel getImprovementFactor])), 
			  [prediction getAverageReinforcement],
			  temporalTimeComparison);
		 else
		   printf("\n Terminal node decrementing improved count 
                          has first input > self node: %ld 
                          thisMaxQ: %f, otherMaxQ: node not found", 
			  nodeNumber,
			  [self getAbsIndependentValue]);
	       }
	       isImproved = False;
	       [nodeGroup decrementImprovedNodeCount];
	     }
	 }
       else
	 {
	   if (![trend trendExists] 
	       || ([trend trendExists] && ![trend isTrendUp]))
	     {
	       if ([agentModel getDebug]) {
		 if ([self findSimilarInputNode])
		   printf("\n Terminal node %ld decrementing improved count 
                          compareInputs: %d, 
                          timeComparison: %f,
                          this value: %f,
                          other value: %f", 
			  nodeNumber,
			  [self compareInputs],
			  timeComparison,
			  ([self getIndependentValue] 
			   * [self getImprovementFactor]),
			  [prediction getAverageReinforcement]);
		 else
		   printf("\n Terminal node decrementing improved count 
                          has first input > self node: %ld 
                          thisMaxQ: %f, otherMaxQ: node not found", 
			  nodeNumber,
			  [self getAbsIndependentValue]);
	       }
	       isImproved = False;
	       [nodeGroup decrementImprovedNodeCount];
	     }
	 }
      }
   }
  */
 
   // June 20 - changed this, if a finalChain falls below input
   // remove it.
 
}

-checkRemove 
{

  id dummyNode = nil;

  if ([agentModel getLearning]  
      && !removed 
      && realActive) {
    if ([(NodeGroup *) topGroup getFinalGroup])
      {
	if ([nodeGroup getImprovedNodeCount] <= 0)
	  {
	    if ([agentModel getDebug]) 
	      printf("\n Terminal node %ld removing self \n has zero or less improved nodes, Time: %ld", 
		     nodeNumber, getCurrentTime());
	      dummyNode = nil;
	      [(NodeGroup *) topGroup removeSelf: nil];
	  }
      }
    // Mar 1 2002 - removing following to see what happens - I am
    // not sure we need this and it seems to stop
    // the driving task developing temporal chains.
    else {      
      if ([[topGroup getFirstNode] getReadyForRemoval]) {
	if ([topGroup getTemporalActivationCount] >= 
	    ((double) [agentModel getTemporalActivationThreshold]
	     * [agentModel getRemovalFactor]))
	  {
	  if ([agentModel getDebug]) 
	    printf("\n Terminal node %ld removing because not extended \n time: %ld", nodeNumber, getCurrentTime());
	  if ([agentModel getDebug])
	    printf("\n Terminal node removing self \nhas temporalActivationCount > max: %ld \n activationCount: %ld", 
		   nodeNumber,
		   [topGroup getTemporalActivationCount]);
	    dummyNode = nil;
	    [(NodeGroup *) topGroup removeSelf: nil];
	    return self;
	  } 
      }
    }
  }
  return self;
}

// Jan 21 2001 - remove if unfinished and prediction has an owner
// which is the topgroup in a finished chain.

-removeIfUnfinished
{
  if (![[self getTopGroup] getFinalGroup])
    [(NodeGroup *) [self getTopGroup] removeSelf: nil];
  return self;
}

-removeSelf: (id) aNode
{
  id tempActiveList;
  id tempSuspendedList;
  id tempPredictorList;     
  
  if (removed == True)
    return self;

   // This stops the node being removed multiple times
  removed = True;
  
  if ([agentModel getDebug])
    fprintf(stdout,"\n Terminal node: %ld removing self", nodeNumber);
  
  // Remove the rest of the temporal chain
  // April 13 added this, so only when last node is removed is chain
  // removed (called by NodeGroup remove).
  if (proxyGroup != nil)
    [(NodeGroup *) topGroup removeSelf: nil];
  else {
    if (supported != nil) {
      if ([nodeGroup getMostFrequentPositive: self] == self) 
	[nodeGroup setMostFrequentPositive: self to: nil];
      
      if ([nodeGroup getMostFrequentNegative: self] == self)
	[nodeGroup setMostFrequentNegative: self to: nil];
    }
  }  

  if ([agentModel getDebug])  
    [self printOn];
  
  if (proxyGroup == nil) {
    [(AgentModelSwarm *) agentModel removeNode: self];
    [agentModel removeFromList: self];
  }
  else {
    [proxyGroup remove];
  }
  
  // Unlike other groups, the first node in a terminal group has
  // been added as a predictor but has a nodeGroup == 0 and proxyGroup
  // != 0
  if (proxyGroup == nil) {
	[prediction removePredictor: self];
  }
  if (nodeGroup != nil)
    {
      if (aNode == nil) // prevent call back to node group removeNode.
	[(NodeGroup *) nodeGroup removeNode: self]; 
    }
  else 
    {
      tempPredictorList = [predictorList copy: [self getZone]];
      [tempPredictorList forEach: M (removeSelf:) : (id) nil];
      [tempPredictorList drop];    
    }
  
  // Remove from extend list

  [[agentModel getExtendList] remove: self];
  [[agentModel getLastExtendList] remove: self];

  if (!copy)
    {
      
      [[[inputList getFirst] getNode] removeOwner: self];
      
      if ([agentModel getDebug])
	printf("\n Terminal node removed from input");
      
      tempActiveList = [[self getActiveOwnerList] copy: [self getZone]];
      tempSuspendedList = [[self getSuspendedOwnerList] 
			    copy: [self getZone]];
      
      [tempActiveList forEach: M(removeSelf:) :(id) nil];
      [tempSuspendedList forEach: M(removeSelf:) :(id) nil];
      
      [tempActiveList drop];
      [tempSuspendedList drop];
      
      if ([agentModel getDebug])
	printf("\n Terminal node removed owners");
    }
  else
    { 
      [[[inputList getFirst] getNode] removeOwner: self];
      
      if ([agentModel getDebug])
	printf("\n Terminal node removed from input");
      
      tempActiveList = [[self getActiveOwnerList] copy: [self getZone]];
      tempSuspendedList = [[self getSuspendedOwnerList] 
			    copy: [self getZone]];
      
      [tempActiveList forEach: M(removeSelf:) :(id) nil];
      [tempSuspendedList forEach: M(removeSelf:) :(id) nil];
      
      [tempActiveList drop];
      [tempSuspendedList drop];
      
      if ([agentModel getDebug])
	printf("\n Terminal node removed owners");
      
    }
 
  if (trend != nil)
    [trend removeSelf];
  if (trendForThis != nil) 
     [trendForThis removeSelf];

  if ([agentModel getDebug]) {
    printf("\n finished remove for terminal node: %ld", nodeNumber);
  }
  
  [[agentModel getDropList] addLast: self];
  
  // add self to agentModel dropList
  if ([agentModel getDebug]) {
    printf("\n Added terminal node to droplist: %ld", nodeNumber);
  }
  
  return self;
}

/* Once trend has enough observations, if we haven't enough observations
   we should extend ourselves.
*/

-(boolean) getTemporallyActivated {
    
    if ([agentModel getDebug])
     printf("nodeGroup HV: %d, tft enoughObs: %d, tft trendexists: %d,\n  tft converging: %d, t enoughObs: %d, higherValue: %d",
	     [nodeGroup getHigherValue],
	     [trendForThis enoughObservations], 
	     [trendForThis trendExistsForThis],
	     [trendForThis isConverging],
	     [trend enoughObservations],
	     higherValue);

  // NOTE: for this to work for homogeneous corridors must not
  // check for highervalue 
  if ((![nodeGroup getHigherValue]
       && [trendForThis enoughObservations] 
       && ((![trendForThis trendExistsForThis] ||
	    ([trendForThis trendExistsForThis] && ![trendForThis isTrendUp]))
	   || [trendForThis isConverging]))
      || ([trend enoughObservations] // Only useful for non-cyclic tasks
	  && higherValue)) { 
    /*    
    if ([agentModel getDebug])
     printf("nodeGroup HV: %d, tft enoughObs: %d, tft trendexists: %d,
             tft converging: %d, t enoughObs: %d, higherValue: %d",
	     [nodeGroup getHigherValue],
	     [trendForThis enoughObservations], 
	     [trendForThis trendExistsForThis],
	     [trendForThis isConverging],
	     [trend enoughObservations],
	     higherValue);
    */
    return True;
  }
  return False;
}

-resetTemporallyActivated {

  [trendForThis removeSelf];

  trendForThis = [Trend createBegin: [self getZone]];
  [trendForThis setAgentModel: agentModel];
  [trendForThis setMaxObservations: 
		  [agentModel getTemporalActivationThreshold]];
  [trendForThis setSignificance: [agentModel getCoxStuartSignificance]];
  trendForThis = [trendForThis createEnd];
  [trendForThis buildObjects];
  [trendForThis calculateMiddle]; 

  [trend removeSelf];

  trend = [Trend createBegin: [self getZone]];
  [trend setAgentModel: agentModel];

  [trend setMaxObservations: ([agentModel getTemporalCoxStuartCaseCount])];
  [trend setSignificance: [agentModel getCoxStuartSignificance]];
  trend = [trend createEnd];
  [trend buildObjects];


  return self;
}

-match: (boolean) aBoolean by: (Node *) aNode
{
  // terminal nodes receive their matched messages from the 
  // topGroup in the temporal chain
  
  return self;
}


-match: (boolean) aBoolean
{
   return self;
}

// updates chain correct count then calls super correct
// Oct 9 2000

-correct 
{
  if (!fired || ([agentModel getSelectedEffector] != supported)) {
      return self;
  }

  if ([nodeGroup getFirstNode] == self) {
    if ([agentModel getDebug])
      printf("\n Terminal node: %ld incrementing chain correct count",
	     nodeNumber);
    [nodeGroup incrementChainCorrectCount];
    [nodeGroup notifyPreviousGroupsChainCorrect: True];
    correct = True;
  }

  return [super correct];
}

// Added Oct 16 2000
-incorrect
{

  if (!fired || ([agentModel getSelectedEffector] != supported)) {
      return self;
    }


 if ([nodeGroup getFirstNode] == self) {
    [nodeGroup notifyPreviousGroupsChainCorrect: False];
    correct = False;
  }

  [super incorrect];
  
  return self;
}

-checkSupress 
{

  // Don't do this for temporal chains.

  return self;
}

-checkNarySupress 
{

  // Unlike nary nodes, terminal nodes always narySupress their input.
  // April 10 2002 - Don't do this unless !suspended - prevents joins forming

   if ([agentModel getDebug])
      printf("\nTerminal Node: %ld received checkNarySupress, realActive: %d suspended: %d as: %d, ats: %d",
	     nodeNumber, [self getRealActive], suspended,
	     activeSupressed, activeTemporallySupressed);

  if ([self getRealActive] && !suspended) {
    if (activeSupressed
	|| activeTemporallySupressed)
      return self; // Not a top node, return.
    [(TerminalNode *) self narySupressInputs];    
  }
  return self;
}

-checkTemporalSupress 
{

// What this is doing is controlling the connections made by passive predictors
// If you are suspended, then supress your inputs. In this case, all the nodes
// beneath you (except your inputs without active owners) will update their
// predictive strengths and histories.  
// Otherwise, if you are active, and have active owners of yourself, only 
// supress your inputs when you yourself are firstsupressed.
// if you are active and do not have any active owners, or only suspended
// owners, then you should also supress your inputs. 

  if ([agentModel getDebug])
    printf("\n Terminal node %ld received temporalSupress realActive: %d",
                  nodeNumber, realActive);
  
  if ([agentModel getDebug])
    printf("\n Terminal Group: %ld, fired: %d, correct: %d",
	   [[self getGroup] getNodeNumber], [[self getGroup] getFired],
	   [[[[self getGroup] getTemporalGroup] getFirstNode] getCorrect]);

  if ([[self getGroup] getFired]
      && [[[[self getGroup] getTemporalGroup] getFirstNode] getCorrect])
    [self temporalSupressInput];
  
  return self;
}

-narySupressInputs
{

  //  printf("narysupressinputs inputs is: %ld",
  //	 [[[inputList getFirst] getNode] getNodeNumber]);

   [[[inputList getFirst] getNode] narySupress];
   return self;
} 

-supress
{ 
  [self setSupressed: True];
  [proxyGroup setSupressed: True for: [self getSupported]];
  if ([self getType] == 0)
    [self supressInput];
  
  return self;
}

-temporalSupress
{ 
   [self setTemporallySupressed: True];
   [proxyGroup setTemporallySupressed: True for: [self getSupported]];
   if ([self getType] == 0)
      [self temporalSupressInput];
  
   return self;
}

-supressInput
{
  [[[inputList getFirst] getNode] supress];
  
  return self;
} 

-temporalSupressInput
{
   [[[inputList getLast] getNode] temporalSupress];
 
   return self;
} 

// while the above prevents predicted nodes making connections usign their 
// predictors, the following two affect which nodes are copied for the 
// initial predictors.  Note: that the above is done after an action
// has been selected while, these are done after matching is complete
 

-checkMatchSupress
{
   return self;
}

-checkUpdateTemporalSupress
{

// All nodes which are matched matchsupress their input nodes
// nodes which are not matched supressed are added to the predictor list
// However, if the node at the top is suspended, it may be 
// removed 

  if (matched)
    [self updateTemporalSupressInput];    
  return self;
}

-updateTemporalSupress
{
   [self setUpdateTemporalSupressed: True];
   [proxyGroup setUpdateTemporalSupressed: True for: [self getSupported]];
   [self updateTemporalSupressInput];
   return self;
}

-updateTemporalSupressInput
{
  [[[inputList getFirst] getNode] updateTemporalSupress];
  return self;
} 

-checkActiveSupress
{

// this can be cleaned up, basically, the nodes which have just fired
// for an effector activesupress their inputs, so they are not used
// in new  connections, otherwise they are.

// Changed this so that it activeSupresses nodes, if they have an
// activeOwner which is matched rather than just suspended owners
 
  if ([agentModel getDebug])
    fprintf(stdout, "\n terminal node: %ld, activeSupress, matched: %d, \n suspended: %d", nodeNumber, matched, suspended);

  if ([[self getGroup] getMatched]
      && [topGroup getFinalGroup])
    //      && [[[[self getGroup] getTemporalGroup] getFirstNode] getCorrect])
    [(TerminalNode *) self activeSupressInput];
  
  return self;
}

-checkActiveActionSupress
{

  // prevent subordinates with same action from sending support

// Changed this so that it activeSupresses nodes, if they have an
// activeOwner which is matched rather than just suspended owners
 
  if ([agentModel getDebug])
    fprintf(stdout, "\n terminal node: %ld, activeActionSupress, matched: %d, \n suspended: %d", nodeNumber, matched, suspended);

 if ([[self getGroup] getMatched]
     && [topGroup getFinalGroup])
    [(TerminalNode *) self activeActionSupressInput];
  
  return self;
}

// ok - prevent groups under a finalised terminal group
// from being used in new joins when the temporal chain
// has just executed.

-checkActiveTemporalSupress
{
   
  if ([agentModel getDebug])
    printf("\n Terminal Group: %ld, fired: %d, correct: %d",
	   [[self getGroup] getNodeNumber], [[self getGroup] getFired],
	   [[[[self getGroup] getTemporalGroup] getFirstNode] getCorrect]);

  if ([[self getGroup] getMatched]
      && [topGroup getFinalGroup])
    [self activeTemporalSupressInput];
  
  return self;
}


-activeSupress
{
  if ([agentModel getDebug])
    fprintf(stdout,"\n Terminal node: %ld received active supress", 
	    nodeNumber);
  [self setActiveSupressed: True];
  [self activeSupressInput];
  [proxyGroup setActiveSupressed: True for: [self getSupported]];
  return self;
}


-activeTemporalSupress
{
  [self setActiveTemporallySupressed: True];
  [self activeTemporalSupressInput];
  // Nov 15 2000 - removed following already done in self setActTempSupressed
  //  [proxyGroup setActiveTemporallySupressed: True for: [self getSupported]];
  return self;
}

-activeSupressInput
{
  if ([agentModel getDebug])
    fprintf(stdout, "\n Terminal Node: %ld active supressing input: %ld",
	    nodeNumber,  [[[inputList getFirst] getNode] getNodeNumber]);
  
  [[[inputList getFirst] getNode] activeSupress];
  
  return self;
} 


-activeActionSupressInput
{
  if ([agentModel getDebug])
    fprintf(stdout, "\n Terminal Node: %ld active action supressing input: %ld",
	    nodeNumber,  [[[inputList getFirst] getNode] getNodeNumber]);
  
  [[[inputList getFirst] getNode] 
    activeActionSupress: [(PredictorNode *) [[self getGroup] 
					      getFirstNode] getSupported]];
  
  return self;
} 

-activeTemporalSupressInput
{
  [[[inputList getFirst] getNode] activeTemporalSupress];
  
  return self;
} 

-copyNew: (id) aZone
{

  // If anode receives this message it may need to create a node group and 
  // pass that back in place of itself
  
  id newNode;
  
  newNode = [self copy: aZone];
  
  if (nodeGroup != nil)
    [nodeGroup addNode: newNode];
  else
    [proxyGroup addNode: newNode];
  
  // we belong to this group
  
  if (nodeGroup != nil)
    [newNode addGroup: nodeGroup];
  else   
    [newNode addGroup: proxyGroup];   
  
  if (nodeGroup != nil)
    [(TerminalNode *)newNode setTopGroup: 
		       [[nodeGroup getProxyNode] getTopGroup]];

  if ([agentModel getDebug])
    printf("\n Finished Copy new");   
  
  return newNode;
} 

-createGroup
{
  id  tempGroup;
  
  if (nodeGroup == nil)
    {
      if ([agentModel getDebug])    
	printf(" \n in Create Terminal group: nodeGroup is nil"); 
      
      tempGroup = [TerminalGroup createBegin: [agentModel getZone]];
      [tempGroup setAgentModel: agentModel];
      [tempGroup setNodeNumber: nodeNumber];
      tempGroup = [tempGroup createEnd];
      [agentModel addNode: tempGroup]; 
      [tempGroup buildObjects];
      
      if ([agentModel getDebug])
	printf(" \n in Finished Terminal Group buildObjects"); 
      
      [tempGroup setNode: self];
      
      // need to use tempGroup to this point, as the nodegroup must be zero 
      // alternatively, provide a different getPredictorList method to use 
      // and use this in nodeGroup::movepredictors

      [self addGroup: tempGroup];
      [nodeGroup setMatched: matched];
      [nodeGroup setRealActive: realActive];

      [[nodeGroup getProxyNode] addInput: 
				  [[[[inputList getLast] getNode]
				     getGroup] getProxyNode] 
				AsOn: True];

      if ([agentModel getDebug])
	printf(" \n in Finished Terminal Create Group"); 
      
    }
  return self;
}

-copy: (id) aZone
{
   TerminalNode * node;
   int count;
   int index; 
  
   node = [TerminalNode createBegin: aZone];
   [node setGrid: grid];
   [node setX: x Y: y];
   [node setColor: color];
   [node setModel: agentModel];
   [node setType: type];                  // 0 is AND
   [node setNodeNumber: [agentModel getNextNodeNumber: node]];  
   node = [node createEnd]; 

   [node buildObjects];

   [node setMatched: matched];
   [node setSupressed: supressed];
   [node setNarySupressed: narySupressed];
   [node setSuspended: suspended];
   [node setSteadyState: steadyState];

   count = [inputList getCount];

   for (index=0;index<count;index++)
      [node addInput: [[inputList atOffset: index] getNode]
            AsOn: [[inputList atOffset: index] getOn]];

// CAREFUL - this adds as active to the lower node, if suspended 
//           is used ask self if suspended or active, then add

   for(index=0;index<count;index++)
      if ([self getSuspended])
          [[[inputList atOffset: index] getNode] addSuspendedOwner: node]; 
      else  
          [[[inputList atOffset: index] getNode] addActiveOwner: node]; 

   [agentModel addNode: node];

   [node setPrediction: prediction];

   [node setSupported: supported];

   return node;
}

-(boolean) setMatched: (boolean) aBoolean 
{

  // If you are a proxyNode, set the group to matched, this is sent to all
  // nodes in the group.

   if ([agentModel getDebug])
	printf("\n Terminal Node %ld setMatched %d, suspended: %d",
	       nodeNumber, aBoolean, suspended);

   if (proxyGroup != nil)
     [proxyGroup setMatched: aBoolean];    

   matched = aBoolean;
  
   return matched;
}

// This should only be sent to proxy nodes

-(boolean) setMatched: (boolean) aBoolean by: (Node *) aNode
{

  // If you are a proxyNode, set the group to matched, this is sent to all
  // nodes in the group.

   if ([agentModel getDebug])
	printf("\n Terminal Node %ld matched:by: %d, suspended: %d",
	       nodeNumber, aBoolean, suspended);

   if (proxyGroup != nil)
     [proxyGroup setMatched: aBoolean];    

   matched = aBoolean;
   
   // May 3 2000 - terminal nodes did not send matched to owners.
   // July 20 2000 - proxy nodes have TemporalOwners, other nodes Nary
   // added code below for other nodes.
   if (proxyGroup != nil)
     if ([[self getProxyOwnerList] getCount] > 0)
       [[self getProxyOwnerList] forEach: M(match:by:)  
				 :(void *) matched :(void *) self];

   return matched;
}

// This is used to send back payments to 
// previous groups in chain for action selection purposes.
// Is is similar to sendTemporalReturn, but does not
// take into account specificity.

-sendPreviousReturn
{
    double payment=0;

// Share in strength is passed back to previous nodes.  This is done through 
// the node group which predicts the nodes in itself.  First the strength
// is set in the group, similar to getReward, only for each node in the group.
// This strength is then divided among nodes predicting the group.

    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    if (nodeGroup == nil)
        return self;

    payment = dependentValue;

    // July 4 2002 - added following:

    if ([(PredictorNode *) self getOwnActivationCount] 
	< [agentModel getActivationThreshold])
      return self;

     if ([agentModel getDebug])
      printf("\n Terminal node %ld group: %ld sending previous return: %f, \n\t  matched: %d, activeSupressed: %d, activeTS: %d",
	     nodeNumber, [[self getGroup] getNodeNumber], 
	     payment, [self getMatched], activeSupressed,
	     activeTemporallySupressed);
 
     // June 18 2002 - replaced realActive with matched:
    if ([self getMatched])
      {
	if ([agentModel getDebug])
	  printf("\n Terminal node %ld group: %ld sending return: %f \n activeSupressed: %d", nodeNumber, 
		 [nodeGroup getNodeNumber], payment, activeSupressed);
	// Feb 21 2001 - if firstnode in group did not predict its
	// prediction correctly, all nodes pay zero
	//	if (![[[self getGroup] getFirstNode] getCorrect])
       //	  payment = 0;
	[nodeGroup setReturnStrength: &payment];
      }
    
    return self;
}

// This is used to pass back the return used to determine if the chain
// is extending too far - Nov 14 2000.  thos payment includes
// specificity to allow for low predictive accuracies until 
// chain is complete.  Including specificity indicates the potential
// return achieveable if we can predict something accurately.
// However, it may be deceiving, as it doesn't take into account
// stochastism.

-sendTemporalReturn
{
    double payment=0;

// Share in strength is passed back to previous nodes.  This is done through 
// the node group which predicts the nodes in itself.  First the strength
// is set in the group, similar to getReward, only for each node in the group.
// This strength is then divided among nodes predicting the group.

    // In fact, each node will have a maximum of one predictor, as
    // it is predicted by the node group.

    if (nodeGroup == nil)
        return self;

    // Nov 17 2000 - only do this if you are the first node for the group
    // to only consider the first prediction for the terminal group.

    if ([nodeGroup getFirstNode] != self)
      return self;

    // Nov 17 2000 - send back averageReturn and reward from prediction
    // Nov 20 - could possibly use dependentReturn * specificity here?

    payment = [prediction getAverageReinforcement]; 

    if ([agentModel getDebug])
          printf("\n Terminal node %ld group: %ld sending temporal return: %f, \n\t  matched: %d, activeSupressed: %d, activeTS: %d",
		 nodeNumber, [[self getGroup] getNodeNumber], 
		 payment, [self getMatched], activeSupressed,
		 activeTemporallySupressed);
 
    if ([self getMatched])
      {
	if ([agentModel getDebug])
	  printf("\n Terminal node %ld group: %ld sending terminal return: %f \n activeSupressed: %d", nodeNumber, 
		 [nodeGroup getNodeNumber], payment, activeSupressed);
	
	[nodeGroup setTemporalReturnStrength: &payment];
	
      }
    
    return self;
}

-(id) ownerListsContainTemporalGroup
{
  int count = 0;
 
  count = [activeOwnerList getCount];
  while (count > 0) {
    count--;
    if ([[activeOwnerList atOffset: count] respondsTo: M(isTemporal)])
      return [[activeOwnerList atOffset: count] getGroup];
  }

  count = [suspendedOwnerList getCount];
  while (count > 0) {
    count--;
    if ([[suspendedOwnerList atOffset: count] respondsTo: M(isTemporal)])
      return [[suspendedOwnerList atOffset: count] getGroup];
  }

  // Otherwise no temporal owners.
  return nil;
}


-setCorrectCount: (int) anInt
{
   correctCount = 1;
   return self;
}

-isTerminal
{
   return self;
}


-findSimilarInputNode
{
  return [[[[inputList getFirst] getNode] getGroup]
	   findSimilarTerminalNode: self];
}

-printOn
{
  int groupNumber = -1;
  int position = 99;
  long number = 0;

  if (nodeGroup != nil)
    groupNumber = [nodeGroup getNodeNumber];
  else {  
    if (proxyGroup != nil)
      groupNumber = [proxyGroup getNodeNumber];
  }

  if (supported != nil)
    position = [supported getPosition]; 

  if (prediction != nil) {
    number = [prediction getNodeNumber];
    printf("\nisImproved ====== %d", isImproved);  
    printf("\nTerminal node number: %ld, predictionValue: %f this (* improvement): %f", nodeNumber,  
	   [prediction getAverageReinforcement],
	   ([self getAbsIndependentValue] 
	    * [self getImprovementFactor])
	    // + [agentModel getVariance]
	   );
    if (topGroup != nil)
      printf("\t Top group number: %ld ", [topGroup getNodeNumber]);     
  }
  else {
    
      printf("\nTerminal Proxy Node number: %ld", nodeNumber);  
    }

  printf("\n\tNary owners: %d. Nary predictors: %d depValue: %f indepValue: %f \n group: %d, copy: %d prediction node: %ld.\n\t  suspended: %d, subordinated: %d  \n\t steadyState: %d, maximumIndepValue: %f\n activationCount: %ld \n correctCount: %ld, predictiveAccuracy: %f avgRewardStrength: %f\nEffector: %d, correct: %d, hyp strength: %f",
	 ([[self getActiveOwnerList] getCount] 
	  + [[self getSuspendedOwnerList] getCount])
	 ,[predictorList getCount], [self getDependentValue],
	 [self getIndependentValue],
	 groupNumber, copy,
	 number,  
	 [self getSuspended],
	 subordinated,steadyState,[self getActualMaxIndependent],
	 ownActivationCount,ownCorrectCount,
	 [self getDependentAccuracy], rewardStrength, position,
	 correct, hypStrength);

 printf("\n this trend:");
    [trendForThis printThisTrendOn];
    
    printf("comparewithinput: ");
    [trend printOn];


  // if (!copy)
    {
      [inputList forEach: M(printOn)];
      if ([self findSimilarInputNode] != nil) {
	printf("\n\t First input  ratio: %f", [[self findSimilarInputNode] 
						getAbsIndependentValue]);
  //		 * [[self findSimilarInputNode] getIndependentSpecificity]);
      }
      else {
	  printf("\n Warning: no similar input node");
      }      
    }           
    fflush(stdout);
    return self;
}

@end








