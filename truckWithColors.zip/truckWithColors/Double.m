#import "Double.h"

@implementation Double

+createBegin: aZone;
{
   return [super createBegin: aZone];
}

-setValue: (double) aDouble
{
  value = aDouble;
   return self;
}

-(double) getValue
{
   return value; 
}

-createEnd
{
  return [super createEnd];
}

-buildObjects
{
  return self;
}

@end

