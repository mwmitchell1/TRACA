// Agent application. Copyright (C) 1996 Matthew Mitchell.


// The Agent Model swarm encapsulates all the objects used in the
// simulated agent itself (but not the user interface objects)


// Agent.h imports all the include files that make up the agent
#import "Node.h"
#import "Effector.h"
#import "DetectorNode.h"
#import "NaryNode.h"
#import "UnaryNode.h"
#import "boolean.h"
#import "TerminalNode.h"
#import "TemporalNode.h"
#import "TerminalGroup.h"
#import <space.h>
#import <gui.h>
#import <activity.h>
#import <collections.h>
#import <stdio.h>
#import <strings.h>
#import <random.h>
#import <objectbase.h>
#import <objectbase/Swarm.h>

@interface AgentModelSwarm : Swarm {

  int tempCount;
  int random;
  int counter;

  int activeCount;
// Temporary variable used in select effector.

// Parameters:
  boolean debug;
  boolean trackActions;
  boolean trackRules;

  float Qreturn;
  float interest;
  int randomEffectorRate;
  int maxPredictorCount;
  int storedRate;
  int narySupressionRate;
  int previousAction;
  int objectToProbe;

  // used to prevent creation of more than one temporal chain in each cycle 
  boolean createTemporalOk;  

  boolean test;
  int unusedChainRemoval;
  boolean learning;
  boolean explore;
  boolean useStrength;
  boolean follow;

  boolean useTemporal;
  boolean useNary;
  boolean endOfTrial;
  boolean selectBest;
  boolean useNegative;
  boolean removeSuspended;
  boolean deterministicSelect;
  boolean passPredictors;
  boolean useAverageForReward;
  boolean useAverageForAccuracy;
  boolean suspendLastCorrect;
  int activationThreshold;
  int lookaheadDistance;
  int lookaheadTimes;
  int temporalActivationThreshold;

  double exploreNegativeValue;
  double learningRate;
  double variance;
  double extendThreshold;
  double negativeExtendThreshold;
  double discountRate;
  double temporalExtendAccuracy;
  double threshold;
  double improvementFactor;
  double temporalImprovementFactor;
  float initialQvalue;
  float performanceFactor;
  
  float noiseTolerance;
  float coxStuartSignificance;
  int coxStuartCaseCount;
  int temporalCoxStuartCaseCount;

  boolean someEffectorSupported;  
  boolean copyValues;

  long temporalActive;
  long terminalActive;
  long naryActive;

  long nodeCount;
  long nextNodeNumber;

  long unaryNodeCount;
  long naryNodeCount;
  long terminalNodeCount;
  long temporalNodeCount;
  long nodeGroupCount;

  long unaryCreated;
  long groupsCreated;
  long naryCreated;
  long temporalCreated;
  long terminalCreated;

  int subordinatedCount;
  int nextTreeNumber;

  int effectorCount;
  int detectorCount;
  int gridXSize;
  int gridYSize;
  int activeGroupCount;

  double removalFactor;

  id modelActions;
  id modelActionSchedule;

  int addedActiveGroups;
  int removedGroups;

  id detectorArray;                                // List of detectorNodes
  id effectorArray;
  id observer;
  id newConnectionsList;

  id dropList;

  id newInputList;
  id oldInputList;
  id activeList;
  id predictorList;
  id extendList;
  id lastExtendList;
  id temporalPredictorList;
  id passivePredictorList;
 
  id groupList;
  id nodeList;			 	          // list of all the Nodes
  id terminalNodeList;
  id temporalNodeList;
  id terminalGroupList;
  id <Grid2d> grid;				  // objects representing

  id selectedEffector;

  id inputString;
  double reward;

 // the following are used for effector selection

  double supportSum;
  double selectionNumber; 
  double stableNaryNodeCount;

  int numberDetectorsActive;		
  boolean positiveSupport;
  boolean finiteProblem;

}

+createBegin: (id) aZone;	
-setDetectorCount: (int) anInt;
-setEffectorCount: (int) anInt;	
-setObserver: (id) anObserver;     
-(id) getObserver;
-createEnd;	
-getNodeList;
-getTerminalNodeList;		
-getTemporalNodeList;		
-addNode: (id) aNode;
-getDetectorArray;
-getEffectorArray;
-(id <Grid2d>) getGrid;			         // model swarm. These methods
                                                 // allow the model swarm to
						 // be observed.
    // the detector input string and reward  
-setDetectorInput: (id) aString Reward: (double) aReward;  
-buildObjects;
-buildActions;
-detectorMatch;
-connectPredictorList;
-connect;
-deActivate;
-resetActiveSupress;
-clearPredictorList;
-detectorMatch;
-match;
-selectEffector;
-getEffector;
-setEffector: (id) anEffector;
-preFire;
-fire;
-move;
-reset;
-lookahead;
-activateIn: (id) swarmContext;
-(double) getReward;
-calculateRewardShare;
-(int) getNextTreeNumber;
-(int) getTreeCount;
-(long) getNextNodeNumber: (id) aNode;
-(long) getNodeCount;
-(long) getUnaryNodeCount;
-(long) getNaryNodeCount;
-addNodeGroup;
-(long) getNodeGroupCount;
-(void) removeNode: (id) aNode;
-removeFromList: (id) aNode;
-removeTerminalGroup: (id) aGroup;
-addTerminalGroup: (id) aGroup;
-(long) getGroupsCreated;
-(long) getNaryCreatedCount;
-(long) getTemporalCreated;
-(long) getTemporalNodeCount;
-(long) getTerminalCreated;
-(long) getTerminalNodeCount;
-(int) getActivationThreshold;
-removeGroup;
-addActive: (id) aNode;
-removeActive: (id) aNode;
-(int) getActiveCount;
-(int) getTerminalActive;
-(int) getTemporalActive;
-(int) getNaryActive;
-(double) getSupportSum;
-(double) getSelectionNumber;
-addSubordinated;
-removeSubordinated;
-(int) getSubordinatedCount;
-getSelectedEffector;
-(int) getRandom;
-getNewInputList;
- (boolean) getTest;
- (boolean) getLearning;
- (boolean) getClassify;
- (double) getLearningRate;
-(boolean) getExplore;
-(boolean) getUseStrength;
-setEndOfTrial: (boolean) aBoolean;
-setRandomEffectorRate: (int) anInt;
-(boolean) getEndOfTrial;
-(boolean) getCopyValues;
-(boolean) getUseAverageForReward;
-(int) getUnusedChainRemoval;
-(int) getNarySupressionRate;
-(int) getMaxPredictorCount;
-(boolean) getUseAverageForAccuracy;
-(double) getImprovementFactor;
-(double) getTemporalImprovementFactor;
-(double) getRemovalFactor;
-(int) getGroupCount;
-(float) getInitialQvalue;
-(float) getPerformanceFactor;
-(float) getCoxStuartSignificance;
-(int) getCoxStuartCaseCount;
-(int) getTemporalCoxStuartCaseCount;
-setSomeEffectorSupported: (boolean) aBoolean;
-setTest: (boolean) aBoolean;
-setLearning: (boolean) aBoolean;
-setRemoveSuspended: (boolean) aBoolean;
-setUseStrength: (boolean) aBoolean;
-setDeterministicSelect: (boolean) aBoolean;
-(boolean) getDeterministicSelect;
-(int) getLastAction;
-(int) getPreviousAction;
-(long) getUnaryCreatedCount;
-addActiveGroup;
-(int) getUnsuspendedGroups;
-(int) getAddedActiveGroups;
-(int) getRemovedGroups;
-(int) getActiveGroupCount;
-getDropList;
-getGroupList;
-getPredictorList;
-getExtendList;
-getLastExtendList;
-(double)getExtendThreshold;
-(double) getNegativeExtendThreshold;
-(boolean) getTrackRules;
-setTrackRules: (boolean) aBool;
-(double) getDiscountRate;
-(boolean) getFiniteProblem;
-(double) getTemporalExtendAccuracy;
-(double) getThreshold;
-getTemporalPredictorList;
-(boolean) getSuspendLastCorrect;
-(int) getTemporalActivationThreshold;
-(boolean) getDebug;
-(boolean) getTrackActions;
-setTrackActions: (boolean) aBool;
-(int) getEffectorCount;
-setDebug: (boolean) aBool; 
-(boolean) getSelectBest;
-setSelectBest: (boolean) aBoolean;
-setExploreNegativeValue: (double) value;
-(double) getExploreNegativeValue;
-(boolean) getCreateTemporalOk;
-(float) getNoiseTolerance;
-(boolean) getUseNegative;
-setObjectToProbe: (int) toProbe;
-(int) getObjectToProbe;
-setCreateTemporalOk: (boolean) aBoolean;
-stop;
-printOn;
-printAsRule;
-(id) lookUpEffectorName: (int) effector;
-(id) lookUpInputName: (int) nodeNumber;
-setFollow: (boolean) aBool;
-(boolean) getFollow;
-setReturnStrength: (double *) aReturn;
-probeNode;
-probeGroup;
-(float) getQreturn;
-setVariance: (double) aFloat;
-(double) getVariance;
-setInterest: (float) aFloat;
-(float) getInterest;
-setPositiveSupport: (boolean) aBoolean;
-(boolean) getPositiveSupport;
-(double) getLearningRate;
-hypPreFire;
-hypDeActivate;
-hypResetActiveSupress;
-hypFire;
@end









