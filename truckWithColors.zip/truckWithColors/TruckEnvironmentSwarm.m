// this is a swarm port of McCallum's NYC driving task.

#import "EnvironmentSwarm.h"
#import "Cell.h"
#import <collections.h>
#define __USE_FIXED_PROTOTYPES__   // for gcc headers
#include <stdio.h>
#include <strings.h>
#import "NYDConstants.h"
#import "Nyd_sm.h"

#define STRLENGTH 24

@implementation EnvironmentSwarm

+createBegin: (id) aZone
{
   EnvironmentSwarm * obj;
   id <ProbeMap> probeMap;
 
   obj = [super createBegin: aZone];
   obj->reward=0;
   obj->bumpPenalty = 0;
   obj->enumerative = 1;

   obj->gridXSize=5;
   obj->gridYSize=5;

   obj->on=1;
   obj->correctCount=0;
   obj->incorrectCount=0;
   obj->predictionCount=0;
   obj->inputString = [String create: aZone];
   obj->lastInputString = [String create: aZone];
 
   obj->agentXpos=0;
   obj->agentYpos=0; 
   obj->rewardXpos=0;
   obj->rewardYpos=0;
   
   obj->problemFile = [String create: aZone];

   probeMap = [EmptyProbeMap createBegin: aZone];
   [probeMap setProbedClass: [self class]];
   probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameter
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridXSize"
         			     inClass: [self class]]];
   [probeMap addProbe: [probeLibrary getProbeForVariable: "gridYSize"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentXpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [probeLibrary getProbeForVariable: "agentYpos"
 				     inClass: [self class]]];  
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "printOn"
	 		     inClass: [self class]]
			setHideResult: 1]];
   [probeMap addProbe: [[probeLibrary getProbeForMessage: "resetAgentPosition"
			     inClass: [self class]]
			setHideResult: 1]];
   [probeLibrary setProbeMap: probeMap For: [self class]];

   return obj;
}

-setString: (char *) aString
{
   [inputString setC: aString];
   return self;
}

-setAgent: (id) anAgent
{
   agentModel = anAgent;
   return self;
}

-createEnd
{
   return [super createEnd];
}

-buildObjects {

  [super buildObjects];

  
  // [self loadFile];
  gridXSize = 5;
  gridYSize = 5;

  grid = [Grid2d createBegin: [self getZone]];
  [grid setSizeX: gridXSize Y: gridYSize];
  grid = [grid createEnd];

  [self setUpDisplay];

  // Now build NTD world, then agent sensory model.

  nydConstants = [NYDConstants createBegin: [self getZone]];
  [nydConstants  loadConstantsFromFile: "constants.dat"];
  [nydConstants updateCalculatedValues];
  nydConstants = [nydConstants createEnd];

  nydSm = [Nyd_sm createBegin: [self getZone]];
  [nydSm nyd_sm_init: nydConstants];
  nydSm = [nydSm createEnd];
  [nydSm setAgentModel: agentModel];

  [nydSm writeDescription]; // initial call

  return self;
}

-getNydConstants {
  return nydConstants;
}

-setUpDisplay 
{

  int x, y;

  cellCount =  (gridXSize * gridYSize);

  printf("\n cell count: %d", cellCount);
  cellArray = [Array create: [self getZone] setCount: cellCount];
  
  for (x = 0; x < gridXSize; x++) 
    for (y = 0; y < gridYSize; y++)
      { 
	Cell * cell;
	
	// Create the cell, set the creation time variables
	cell = [Cell createBegin: [self getZone]];
	[cell setGrid: grid];
	[cell setX: x Y: y];
	[cell setModel: self];
	cell = [cell createEnd];
	
	[cell buildObjects];
	
	[cellArray atOffset: (y + x * gridYSize) put: cell];
	printf("\n creating cell x: %d y: %d location: %d", x, y,
	       (y + x * gridYSize));
      }
  
  outputfp = fopen("agent.out","w");
  if (outputfp == NULL)
    printf("\n WARNING:  output file not opened");   
  fflush(stdout);
  
  return self;
}


-buildActions {

  [super buildActions];

  return self;
}

-activateIn: (id) swarmContext {

  [super activateIn: swarmContext];

  return [self getSwarmActivity];
}


-getCellArray
{
   return cellArray;
}

-update
{ 
 //  must get the position of the selected action from the agent, then update
 //  environment accordingly.   A new input string is then passed 
 //  to the agent along with the reward from the last action.

   int vector[100];
   int x=0;

   [inputString setC: ""];

   // the position of a particular dimension's value in the percept
   // vector is given by the dimension of that percept.
   // Some percepts may be disabled.
 
   // Even though there may be 2 color dimensions (road + truck)
   // these share the same vector position (i.e are treated as one).

   // The highest value any dimension can have is 3, so all 
   // dimensions allowed values from 0 to 3.
   // Some dimensions may be excluded based on selections in
   // constants file.  Working out which dimension is which
   // requires manual investigated for the default values we have
   // the following:
   // 1. distanceDimension
   // 2. distanceTwoDimensions
   // 3. sideDimension 
   // 4. objectDimension
   // 5. directionDimension
   // 6. speedDimension
   // 7. hearHorn
   // 8. canSeeColor 

   [nydSm nyd_sm_get_percept_vector:  vector];

   if (enumerative) {
     for (x = 0; x < [nydConstants getNumberPerceptualDimensions]; x++) {
       [self convertEnumFrom: vector[x] 
	     to: inputString length: 3];
     }
   }
   else {
     for (x = 0; x < [nydConstants getNumberPerceptualDimensions]; x++) {
       [self convertFrom: vector[x]
	     to: inputString length: 3];
     }	 
   }
   return self;
}

-step
{
   if (on == 1)  // first input
   {
       on = 0;
       reward = 0;
       [self update];
   }
   else
       [self answer];
   if ([agentModel getDebug]) {
     printf("\n--------------------------------------------------------");
     printf("\n ENVIRONMENT: Input String is :%s", [inputString getC]);     
   }
   [agentModel setDetectorInput: inputString Reward: reward];
   [lastInputString setC: [inputString getC]];
   return self;    
}

-answer
{

   effectorAction = [agentModel getLastAction]; 

   [nydSm nyd_sm_perform_action: effectorAction];

   reward = 0;    
   reward = [nydSm nyd_sm_reward];
       
   if ([agentModel getUseStrength])
       predictionCount++;
 
   if ([agentModel getDebug])
     printf("\n\t\t ENVIRONMENT: Action Selected received reward %f", reward);
   
   if (reward > 0)
   {
      if ([agentModel getUseStrength])
         correctCount++;
      if ([agentModel getDebug])
	printf("\n\t\t              Goal achieved");
      if ([agentModel getTest])
          reward = 0;
   }
   else
   {
      incorrectCount++;
      if ([agentModel getDebug])
	printf("\n\t\t ENVIRONMENT: No Goal Achieved");
   }

  [self update];

  [agentModel setDetectorInput: inputString Reward: reward];

  if (![agentModel getExplore])
    {
      if ([agentModel getDebug])
	fprintf(outputfp,"Total moves: %d, Times goal achieved: %d", 
		predictionCount, correctCount);
    }

  [nydSm writeDescription];

  return self;
}


// Coverts directly to binary representation

-(void) convertFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "000000000000000"; 
    char temp1[STRLENGTH] = "";

    if (anInt >= 128)
    {
        temp[7] = '1';
        anInt = anInt - 128;
    }

    if (anInt >= 64)
    {
        temp[6] = '1';
        anInt = anInt - 64;
    }  

    if (anInt >= 32)
    {
        temp[5] = '1';
        anInt = anInt - 32;
    }
    
    if (anInt >= 16)
    {
        temp[4] = '1';
        anInt = anInt - 16;
    }

    if (anInt >= 8)
    {
        temp[3] = '1';
        anInt = anInt - 8;
    }

    if (anInt >= 4)
    {
        temp[2] = '1';
        anInt = anInt - 4;
    }

    if (anInt >= 2)
    {
        temp[1] = '1';
        anInt = anInt - 2;
    }
     
    if (anInt == 1)
    {
        temp[0] = '1';
    }
    else
      if (anInt > 0)    
	printf("\nWarning - 
                   EnvironmentSwarm::convertInt unable to convert integer");
    
    strncat(temp1,temp,length);
    [aString catC: temp1];
}    


// Converts to enumerative representation

-(void) convertEnumFrom: (int) anInt to: (id) aString length: (int) length
{ 
    char temp[STRLENGTH] = "000000000000000"; 
    char temp1[STRLENGTH] = "";

    temp[anInt - 1] = '1';

    strncat(temp1,temp,length);
    [aString catC: temp1];
}    

-getGrid
{
  return grid;
}

-getString
{
   return inputString;
}

-(float) getPredictiveAccuracy
{
  float tempPredictionCount=0;
  float tempCorrectCount = 0;
  float accuracy=0;

  if (predictionCount > 0)
  {
     tempPredictionCount = predictionCount;
     tempCorrectCount = correctCount; 
     accuracy = ((100.0/tempPredictionCount) * tempCorrectCount);
  }
  if ([agentModel getDebug])
    printf("\n predictionCount, %d, correctCount, %d, accuracy: %f",
                   predictionCount, correctCount, accuracy);
  return accuracy;
}

-(int) getIncorrectCount
{
   return incorrectCount;
}

-printOn
{
   printf("\n Environment String: %s", [inputString getC]);
   return self;
}


-resetAgentPosition
{

  /*
  int x = 0;

  [[positionArray atOffset: agentPosition] setOccupied: False];

  if (relocatePosition == 0) {
    agentPosition = [uniformIntRand getIntegerWithMin: 0 
				    withMax: ([resetList getCount] - 1)];
    temp = [resetList atOffset: agentPosition];
    x = 0;
    for(x = 0; [positionArray atOffset: x] != temp; x++)
	  ;
    agentPosition = x;
  }
  else
    agentPosition =  (relocatePosition - 1);

  [[positionArray atOffset: agentPosition] setOccupied: True];

  on = 1;
  */
  return self;
}

-setProblem: (char *) fileName epochs: (int) epochs
{
  [problemFile setC: fileName];
  return self;
}

-timeOut {
  // not required
  return self;
}

@end






















