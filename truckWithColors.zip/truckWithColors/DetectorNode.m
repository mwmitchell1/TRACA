#import "DetectorNode.h"
#import "AgentModelSwarm.h"
#import "UnaryNode.h"
#import "NodeGroup.h"
#import <simtools.h>

@implementation DetectorNode

//  Note: the family must be set to some integer > 0, in the createBegin stage 
//  Also X and Y coordinates need to be set, this is not checked for in 
//  createEnd.


+createBegin: (id) aZone
{
   DetectorNode * obj;
        
   obj = [super createBegin: aZone]; 
   return obj;
}

-createEnd
{	
   if (family <= 0)
      [InvalidCombination raiseEvent: "Family not set for detector node"];

   return self;
}

-buildObjects
{    
   [super buildObjects];
   return self;
}


-realDeactivate
{
    [super realDeactivate];
    return self;
}


-match: (boolean) aBoolean
{
   // Pass this message to owners who will update predictive strength 
   // if boolean is True, and reward strength based on the reward. 
   // Predictive nodes call connect to make connections based on correctness  
   // or incorrectness or predictors

 
  realActive = aBoolean;
  matched = aBoolean;

//  Calculate Reward

  if ([[self getProxyOwnerList] getCount] > 0)
      [[self getProxyOwnerList] forEach: M(match:) :(void *) aBoolean];

  if (proxyGroup != nil) { 
     if (aBoolean)                        // Don't these messages to group
                                       // they are handled by proxy
     { 

//  If a predictor was correct it gets sent a message which will update 
//  its predictive strength.  If the predictor was an active predictor
//  it will then ask the detector node for its share of the reward.
//  (Which incidently  is calculated above).

         [activePredictorList forEach: M(correct)];
         [passivePredictorList forEach: M(correct)];
         [suspendedPredictorList forEach: M(correct)];
     }
     else
     {
         [activePredictorList forEach: M(incorrect)];
         [passivePredictorList forEach: M(incorrect)];
         [suspendedPredictorList forEach: M(incorrect)];
     }
  }
  return self;
}

-(int) getFamily
{
   return family;
}


-createGroup
{
    id aNodeGroup;
   
    aNodeGroup = [NodeGroup createBegin: [agentModel getZone]];
    [aNodeGroup setAgentModel: agentModel];
    [aNodeGroup setNodeNumber: [self getFamily]];
    aNodeGroup = [aNodeGroup createEnd];
    [aNodeGroup buildObjects];
    [agentModel addNodeGroup];
    [agentModel addNode: aNodeGroup];          
    [aNodeGroup create: self]; 

    nodeGroup = aNodeGroup;
 
    return self;
}

-getProxyOwnerList
{
    return proxyOwnerList;
} 

-(boolean) setFamily: (int) aFamily
{
    if (aFamily < 1)
	return False;
    family = aFamily;
    return True;
}

-isDetector
{ 
   return self;
}

-drawSelfOn: (Raster *) aRaster
{
  //   [aRaster drawPointX: x Y: y Color: color];
   return self;
}

-printOn
{
   printf("\ndetector node family: %d. number: %ld, \n Unary connections: %d",
                   family, nodeNumber,
                ([[self getActiveOwnerList] getCount]
		 + [[self getSuspendedOwnerList] getCount]));
   return self;
}


-hypMatch: (boolean) aBoolean
{
   // Pass this message to owners who will update predictive strength 
   // if boolean is True, and reward strength based on the reward. 
   // Predictive nodes call connect to make connections based on correctness  
   // or incorrectness or predictors

   hypActive = aBoolean;
   hypMatched = aBoolean;

   if ([[self getActiveOwnerList] getCount] > 0)
       [[self getActiveOwnerList] forEach: M(hypMatch:) :(void *) aBoolean];

   if ([suspendedOwnerList getCount] > 0)
       [suspendedOwnerList forEach: M(hypMatch:) :(void *) aBoolean];

   if ([[self getProxyOwnerList] getCount] > 0)
       [[self getProxyOwnerList] forEach: M(hypMatch:) :(void *) aBoolean];

   return self;
}

-(boolean) hypDeactivate
{
   [super hypDeactivate];
   return True;
}

@end









