#import "Node.h"
#import "boolean.h"
#import <random.h>

@interface DetectorNode  : Node
{
	int family;
}

+createBegin: (id) aZone;
-(boolean) setFamily: (int) aFamily;
-createEnd;
-buildObjects;
-realDeactivate;
-match: (boolean) aBoolean;
-(int) getFamily;
-isDetector;
-match: (boolean) aBoolean;
-drawSelfOn: (Raster *) aRaster;
-createGroup;
-printOn;
-hypMatch: (boolean) aBoolean;
-(boolean) hypDeactivate;
@end





































