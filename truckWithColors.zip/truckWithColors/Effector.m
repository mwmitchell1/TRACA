#import "Effector.h"
#import "AgentModelSwarm.h"

@implementation Effector

+createBegin: (id) aZone
{
    Effector * obj;

    obj = [super createBegin: aZone];
    obj->supported=False;
    obj->support=0;
    obj->selected=False;
    obj->proportion = 0;

    return obj;
}

-createEnd
{
	return [super createEnd];
}

-buildObjects
{

    supporterList = [List create: [self getZone]];

    support = 0;    
    effectiveSupport = 0;
    predictiveSupport = 0.0;

    cumulativeSupport = 0;
    predictiveSupporterCount = 0;

    negativeSupporterCount = 0;
    positiveSupporterCount = 0;
    negativeSupport = 0;
    positiveSupport = 0;
    highestNegativeSupporter = nil;
      
    return self;
}

-reset
{

 	supported = False;
        selected = False;

        perfect = 0.0;  
        support = 0.0;
        effectiveSupport = 0.0;
        predictiveSupport = 0.0;
        cumulativeSupport = 0.0;
        predictiveSupporterCount = 0.0;
        negativeSupporterCount = 0.0;
        positiveSupporterCount = 0.0;
	negativeSupport = 0.0;
	positiveSupport = 0.0;
	highestNegativeSupporter = nil;
	highestSupporter = nil;

	return self;
}

-setPosition: (int) aPosition
{
   position = aPosition;
   return self;
}

-setAgentModel: (id) aModel
{
   agentModel = aModel;
   return self;
}

-(int) getPosition
{
  return position;
}

-(void) setSupport: (double) aNumber
{
	support = aNumber;
}

-(void) incrementSupport: (double) aNumber
{
	support = support + aNumber;
}

-(boolean) addSupporter: (Node *) aNode
{
	if (aNode == nil)
		return False;
	[supporterList addLast: aNode];
	return True;
}

-(boolean) removeSupporter: (Node *) aNode
{
	if (aNode == nil)
		return False;
	[supporterList remove: aNode];
	return True;
}

-addPredictiveSupport: (double) aDouble node: (id) supporter
{

// These two should be mutually exclusive

  if (aDouble != 0.0) {
    [agentModel setSomeEffectorSupported: True];
    predictiveSupporterCount++;
  }

  if (aDouble > 0.0) {
    positiveSupport = positiveSupport + aDouble;
    positiveSupporterCount++;
    
  } else {
    if (aDouble < 0.0) {
      negativeSupport = negativeSupport + aDouble;
      negativeSupporterCount++;
      
    }
  }
  
  if ([agentModel getDebug])    
    printf("\n effector %d positive support: %f, negative support %f,\nsupporters: %d pvecount: %d, nveCount: %d", position,
	   positiveSupport, negativeSupport, 
	   predictiveSupporterCount, positiveSupporterCount,
	   negativeSupporterCount);
  
  return self;
}

-addStrengthSupport: (double) aDouble
{
    if (aDouble > support)
        support = aDouble;
 
   return self;
}  
 
-calculateEffectiveSupport
{
   // This calculates the effective support which is 
   // the support once the predictive strength has been
   // taken into account.


  // C42 - divide by number of predictors

  if ([agentModel getDebug]) {
    printf("\n ------- Effective support before divide: %f, predictors: %d",
	   effectiveSupport, predictiveSupporterCount);
    fflush(stdout);
  }

  if (predictiveSupporterCount > 0 && ![agentModel getSelectBest]) {
    if (positiveSupporterCount > 0 && negativeSupporterCount > 0) {
      effectiveSupport = (positiveSupport / (float) positiveSupporterCount) +
     	(negativeSupport / (float) negativeSupporterCount);
    }
    else {
      if (negativeSupporterCount > 0)
	effectiveSupport = negativeSupport / (float) negativeSupporterCount;
      else
	effectiveSupport = positiveSupport / (float) positiveSupporterCount;
    }
  }
  else {
    if ([agentModel getUseNegative]) {
      effectiveSupport = positiveSupport + negativeSupport;
    }
  }
 
  if ([agentModel getDebug]) {
    printf("\n ------- Effective support after divide: %f, predictiveSupport: %f, positive: %d", effectiveSupport, predictiveSupport,
	   (effectiveSupport > 0));
    fflush(stdout);
  }

  if (effectiveSupport > 0) {
    [agentModel setPositiveSupport: True];
  }

  return self;
}
    
// work out total negative strengths - if any zero strengths may want to 
// assign a small strength in calculateeffectivesupport 

-calculateSum: (double *) supportSum
{
  
  if ([agentModel getDebug])
    printf("\n Calculate sum: %f", *supportSum);

  if ((effectiveSupport * -1.0) < [agentModel getVariance]) {
    if ([agentModel getDebug])
      printf("Effective support is zero, exploreValue is: %f", 
	     [agentModel getExploreNegativeValue]);
    effectiveSupport = -1 * [agentModel getExploreNegativeValue]; 
  }
   
  *supportSum = *supportSum + effectiveSupport;

  return self;
}

// Work our proportion of overall strength (will be b/w 0 - 1.0).

-calculateProportion: (double *) supportSum
{
  
  if ([agentModel getDebug])
    printf("\n Calculate sum: %f", *supportSum);

  if (*supportSum != 0)
    proportion = effectiveSupport / *supportSum;

  return self;
}


-setCumulativeSupport: (double *) supportSum
{
  // Note that effective suppport is used to select effectors, not support
  // C42     [self calculateEffectiveSupport];
  
  if ([agentModel getDebug])
    printf("\n support sum: %f", *supportSum);

  if ([agentModel getPositiveSupport]) {
    if ((effectiveSupport - [agentModel getVariance]) <= 0) {
      if ([agentModel getDebug])
	printf("Effective support is zero, exploreValue is: %f", 
	       [agentModel getExploreNegativeValue]);
      effectiveSupport = [agentModel getExploreNegativeValue]; // a small value
    }
    *supportSum = *supportSum + effectiveSupport;
  } else {
    if ([agentModel getDebug])
      printf("proportion: %f ", proportion);
    if (proportion != 0) // sanity check
      *supportSum = *supportSum + (1.0 / proportion); 
  }
	 
  if ([agentModel getDebug])
    printf("\n Effector %d efectiveSupport: %f, supportsum: %f",
	   position, effectiveSupport, *supportSum);
  
  cumulativeSupport = *supportSum;

  // If their is negative and positive support - first sort is necessary
  // on effectiveSupport if negative effectors are given a zero value
  // otherwise, if negative values only, sort on cumulativeSupport.

  return self;
}

// This needs to be sorted based on
// the cumulative support as above 
// as it moves through each effector in turn

-checkCumulativeSupport
{
    double normCumSupport;

 // Normalised cumulativeSupport

    normCumSupport = cumulativeSupport / [agentModel getSupportSum];    

    if ([agentModel getDebug])          
      printf("Effector checking is: %d, norm: %f", position, normCumSupport);

    if ((normCumSupport >= [agentModel getSelectionNumber])
	&& ([agentModel getEffector] == nil)) 
    {
        [agentModel setEffector: self];
        if ([agentModel getDebug])
           printf("Effector Selected is: %d", position);
    }              
    return self;
}
         
-selectBestPredictiveEffector: (id) anId max: (double *) max
{
    if (effectiveSupport > *max)
    {
      if ([agentModel getDebug]) {
	printf("Effector: %d, max: %f effsupp: %f", 
	       position, *max, effectiveSupport);
	fflush(stdout);
      }
      [agentModel setEffector: self];
      anId = self;
      *max = effectiveSupport;
    }
    if ([agentModel getDebug]) {
      printf("Effector: %d, returning", position);
      fflush(stdout);
    }
    return self;
}
   
-selectBestRewardEffector: (id) anId max: (double *) max
{
    if (support > *max)
    {
       [agentModel setEffector: self];
       anId = self;
       *max = support;
    }
    return self;
}            

-(float) getEffectiveSupport
{
   return effectiveSupport;
}

-(double) getSupport;
{
	return support;
}

-(void) setSupported: (boolean) aBoolean
{
	supported = aBoolean;
}
-(boolean) getSupported
{
	return supported;
}

-(boolean) setX: (int) newX Y: (int) newY
{
	int maxX, maxY;

	maxX = [[self getGrid] getSizeX];
	maxY = [[self getGrid] getSizeY];

	if ( newX >= maxX || newY >= maxY)
		return False;
	x = newX;
	y = newY;
	return True;
}

-setGrid: (id) aGrid
{
	grid = aGrid;
	return self;
}

-getGrid
{
	return grid;
}

-drawSelfOn: (id <Raster>) aRaster
{
	[aRaster drawPointX: x Y: y Color: color];	
	return self;
}

-(void) setSelected: (boolean) aBoolean
{
  selected = aBoolean;
}

-(boolean) getSelected
{
  return selected;
} 

-(double) getAbs: (double) aDouble 
{
  if (aDouble < 0)
    return (aDouble * -1);
  else
    return aDouble;
}

// May 6 2002
// initially this is the effectiveSupport
// but once the first sort is done (which is only needed if their
// is positive and negative supporters) it is cumulativesupport.

-(float) getSortStrength
{
     return effectiveSupport;   
}

-printOn
{
	printf("\nEffector Node position: %d Active:%d, effectivesupport: %f,\n \n support: %f, predictiveSupport: %f ", position, selected,
                   effectiveSupport, support, predictiveSupport);
	return self;
}

-printTrack
{
  if (predictiveSupporterCount > 0) {
    printf("\nEffector: %d support: %f", position, effectiveSupport);
    /*
    if (![agentModel getUseNegative])
            printf("\nEffector: %d support: %f, group: %d %f node: %d time: %d", position,
	   effectiveSupport, [[highestSupporter getGroup] getNodeNumber],
	   predictiveSupport,
		   [highestSupporter getNodeNumber], getCurrentTime());
    else
     
      if ((highestNegativeSupporter != nil)
	&&  (highestSupporter != nil))
    printf("\nEffector: %d support: %f, +ve group: %d %f -ve group: %d %f", position,
	   effectiveSupport, [[highestSupporter getGroup] getNodeNumber],
	   positiveSupport,
	   [[highestNegativeSupporter getGroup] getNodeNumber],
	   negativeSupport);
    else {
      if (highestSupporter != nil) {
	printf("\nEffector: %d support: %f, +ve group: %d %f -ve group: nil 0", position,
	   effectiveSupport, [[highestSupporter getGroup] getNodeNumber],
	       positiveSupport);
      } else 
	if (highestNegativeSupporter != nil)
	  printf("\nEffector: %d support: %f, +ve group: nil 0 -ve group: %d %f", position,
		 effectiveSupport, 
		 [[highestNegativeSupporter getGroup] getNodeNumber],
		 negativeSupport);
    }
    */
  }
  else
    printf("\n Effector: %d not supported.", position);

  return self;
}

@end









